import { Input } from '../ui/input'
import { formatDate } from '../../utils/date-format'
import type { RequisitionDocument } from '../../types'

interface FormMetaProps {
  document: RequisitionDocument
  isEditing: boolean
  onChange: (field: keyof RequisitionDocument, value: any) => void
}

export function FormMeta({ document, isEditing, onChange }: FormMetaProps) {
  return (
    <div className="grid grid-cols-4 gap-4 mb-6 p-4 bg-slate-50 rounded-lg">
      <div>
        <label className="text-xs font-semibold text-slate-600">Rec. No.</label>
        {isEditing ? (
          <Input
            value={document.recNo}
            onChange={(e) => onChange('recNo', e.target.value)}
            className="mt-1"
            size={20}
          />
        ) : (
          <p className="mt-1 text-sm font-medium">{document.recNo}</p>
        )}
      </div>

      <div>
        <label className="text-xs font-semibold text-slate-600">Date</label>
        <p className="mt-1 text-sm font-medium">{formatDate(document.date)}</p>
      </div>

      <div>
        <label className="text-xs font-semibold text-slate-600">Page No.</label>
        {isEditing ? (
          <Input
            value={document.pageNo}
            onChange={(e) => onChange('pageNo', e.target.value)}
            className="mt-1"
          />
        ) : (
          <p className="mt-1 text-sm font-medium">{document.pageNo}</p>
        )}
      </div>

      <div>
        <label className="text-xs font-semibold text-slate-600">From</label>
        <p className="mt-1 text-sm font-medium">{document.fromTeam}</p>
      </div>

      <div>
        <label className="text-xs font-semibold text-slate-600">To</label>
        <p className="mt-1 text-sm font-medium">{document.toTeam}</p>
      </div>
    </div>
  )
}
