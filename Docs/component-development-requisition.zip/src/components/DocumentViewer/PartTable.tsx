import { Button } from '../ui/button'
import { Input } from '../ui/input'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../ui/table'
import { formatDate } from '../../utils/date-format'
import { Plus, X } from 'lucide-react'
import type { Part, RequisitionDocument } from '../../types'

interface PartTableProps {
  document: RequisitionDocument
  isEditing: boolean
  onPartChange: (index: number, field: keyof Part, value: any) => void
  onAddPart: () => void
  onRemovePart: (index: number) => void
}

export function PartTable({
  document,
  isEditing,
  onPartChange,
  onAddPart,
  onRemovePart,
}: PartTableProps) {
  return (
    <div className="mb-6">
      <div className="flex justify-between items-center mb-3">
        <h3 className="font-semibold text-sm">Parts Required</h3>
        {isEditing && (
          <Button size="sm" variant="outline" onClick={onAddPart}>
            <Plus className="h-4 w-4 mr-1" />
            Add Part
          </Button>
        )}
      </div>

      <div className="rounded-lg border overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-slate-50">
              <TableHead className="w-12">S.No.</TableHead>
              <TableHead>Part No.</TableHead>
              <TableHead>Rev.</TableHead>
              <TableHead>Part Name</TableHead>
              <TableHead>Qty.</TableHead>
              <TableHead>Required Date</TableHead>
              <TableHead>Committed Date</TableHead>
              <TableHead>Actual Completion</TableHead>
              {isEditing && <TableHead className="w-10"></TableHead>}
            </TableRow>
          </TableHeader>
          <TableBody>
            {document.parts.map((part, idx) => (
              <TableRow key={idx}>
                <TableCell className="text-sm">{part.sNo}</TableCell>
                <TableCell>
                  {isEditing ? (
                    <Input
                      size={15}
                      value={part.partNo}
                      onChange={(e) => onPartChange(idx, 'partNo', e.target.value)}
                    />
                  ) : (
                    <span className="text-sm">{part.partNo}</span>
                  )}
                </TableCell>
                <TableCell>
                  {isEditing ? (
                    <Input
                      size={8}
                      value={part.rev}
                      onChange={(e) => onPartChange(idx, 'rev', e.target.value)}
                    />
                  ) : (
                    <span className="text-sm">{part.rev}</span>
                  )}
                </TableCell>
                <TableCell className="max-w-xs">
                  {isEditing ? (
                    <Input
                      value={part.partName}
                      onChange={(e) => onPartChange(idx, 'partName', e.target.value)}
                    />
                  ) : (
                    <span className="text-sm">{part.partName}</span>
                  )}
                </TableCell>
                <TableCell>
                  {isEditing ? (
                    <Input
                      type="number"
                      size={8}
                      value={part.qty}
                      onChange={(e) => onPartChange(idx, 'qty', parseInt(e.target.value) || 0)}
                    />
                  ) : (
                    <span className="text-sm">{part.qty}</span>
                  )}
                </TableCell>
                <TableCell className="text-xs text-slate-500">
                  {formatDate(part.requiredDate)}
                </TableCell>
                <TableCell className="text-xs text-slate-500">
                  {formatDate(part.committedDate)}
                </TableCell>
                <TableCell className="text-xs text-slate-500">
                  {formatDate(part.actualCompletionDate)}
                </TableCell>
                {isEditing && (
                  <TableCell>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onRemovePart(idx)}
                      disabled={document.parts.length === 1}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </TableCell>
                )}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
