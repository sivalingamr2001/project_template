import type { RequisitionDocument, Part } from '../../types'

export interface DocumentViewerProps {
  document: RequisitionDocument | null
  isNew: boolean
  onClose: () => void
  onSave: (doc: RequisitionDocument) => void
}

export interface FormState {
  document: RequisitionDocument
  isEditing: boolean
}
