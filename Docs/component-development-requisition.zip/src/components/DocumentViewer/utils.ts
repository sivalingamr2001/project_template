import type { RequisitionDocument } from '../../types'

const generateRecNo = (): string => {
  return `REC-${new Date().getFullYear()}-${Math.floor(Math.random() * 10000)
    .toString()
    .padStart(4, '0')}`
}

export const createNewDocument = (): RequisitionDocument => ({
  recNo: generateRecNo(),
  date: new Date(),
  pageNo: '1',
  fromTeam: 'D&D Team',
  toTeam: 'Materials-D&D',
  productNo: '',
  productRev: '',
  projectNo: '',
  productName: '',
  purpose: 'new-product-validation',
  monthlyQty: 0,
  parts: [{ sNo: 1, partNo: '', rev: '', partName: '', qty: 0, requiredDate: null, committedDate: null, actualCompletionDate: null }],
})

export const mockAutoPopulate = (): RequisitionDocument => ({
  recNo: 'REC-2024-AUTO',
  date: new Date(),
  pageNo: '1',
  fromTeam: 'D&D Team',
  toTeam: 'Materials-D&D',
  productNo: 'PRD-AUTO-001',
  productRev: '1.0',
  projectNo: 'PROJ-2024-AUTO',
  productName: 'Advanced Smart Device',
  purpose: 'new-product-validation',
  monthlyQty: 5000,
  parts: [
    {
      sNo: 1,
      partNo: 'PART-CPU-001',
      rev: 'A',
      partName: 'High-Performance MCU',
      qty: 5000,
      requiredDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      committedDate: new Date(Date.now() + 25 * 24 * 60 * 60 * 1000),
      actualCompletionDate: null,
    },
    {
      sNo: 2,
      partNo: 'PART-SENS-001',
      rev: 'B',
      partName: 'Temperature & Humidity Sensor',
      qty: 5000,
      requiredDate: new Date(Date.now() + 28 * 24 * 60 * 60 * 1000),
      committedDate: new Date(Date.now() + 26 * 24 * 60 * 60 * 1000),
      actualCompletionDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    },
  ],
})
