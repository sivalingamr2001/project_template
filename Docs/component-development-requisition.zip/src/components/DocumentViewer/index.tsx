import { useState, useEffect } from 'react'
import { FormHeader } from './FormHeader'
import { FormMeta } from './FormMeta'
import { ProductInfo } from './ProductInfo'
import { PartTable } from './PartTable'
import { Signatures } from './Signatures'
import { mockAutoPopulate, createNewDocument } from './utils'
import type { RequisitionDocument, Part } from '../../types'
import type { DocumentViewerProps } from './types'

export function DocumentViewer({
  document: initialDoc,
  isNew,
  onClose,
  onSave,
}: DocumentViewerProps) {
  const [document, setDocument] = useState<RequisitionDocument>(
    initialDoc || createNewDocument(),
  )
  const [isEditing, setIsEditing] = useState(isNew)

  useEffect(() => {
    if (initialDoc) setDocument(initialDoc)
  }, [initialDoc])

  const handleFieldChange = (field: keyof RequisitionDocument, value: any) => {
    setDocument((prev) => ({ ...prev, [field]: value }))
  }

  const handlePartChange = (index: number, field: keyof Part, value: any) => {
    setDocument((prev) => ({
      ...prev,
      parts: prev.parts.map((p, i) => (i === index ? { ...p, [field]: value } : p)),
    }))
  }

  const handleAddPart = () => {
    setDocument((prev) => ({
      ...prev,
      parts: [
        ...prev.parts,
        {
          sNo: prev.parts.length + 1,
          partNo: '',
          rev: '',
          partName: '',
          qty: 0,
          requiredDate: null,
          committedDate: null,
          actualCompletionDate: null,
        },
      ],
    }))
  }

  const handleRemovePart = (index: number) => {
    if (document.parts.length === 1) return
    setDocument((prev) => ({
      ...prev,
      parts: prev.parts.filter((_, i) => i !== index),
    }))
  }

  const handleAutoPopulate = () => {
    setDocument(mockAutoPopulate())
  }

  const handleSave = () => {
    onSave(document)
    setIsEditing(false)
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-start justify-center p-4 overflow-auto">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-6xl mt-4 mb-4">
        <div className="p-8">
          <FormHeader
            document={document}
            isEditing={isEditing}
            onClose={onClose}
            onAutoPopulate={handleAutoPopulate}
            onToggleEdit={() => setIsEditing(!isEditing)}
            onSave={handleSave}
          />

          <FormMeta document={document} isEditing={isEditing} onChange={handleFieldChange} />
          <ProductInfo document={document} isEditing={isEditing} onChange={handleFieldChange} />
          <PartTable
            document={document}
            isEditing={isEditing}
            onPartChange={handlePartChange}
            onAddPart={handleAddPart}
            onRemovePart={handleRemovePart}
          />
          <Signatures document={document} isEditing={isEditing} onChange={handleFieldChange} />

          <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200 text-sm text-blue-800">
            <strong>MOQ Warning:</strong> Minimum order quantity applies to all parts. Please
            verify quantities with your supplier before submission.
          </div>
        </div>
      </div>
    </div>
  )
}
