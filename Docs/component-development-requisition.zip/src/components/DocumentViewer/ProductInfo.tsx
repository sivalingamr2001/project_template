import { Input } from '../ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../ui/select'
import type { RequisitionDocument } from '../../types'

interface ProductInfoProps {
  document: RequisitionDocument
  isEditing: boolean
  onChange: (field: keyof RequisitionDocument, value: any) => void
}

export function ProductInfo({ document, isEditing, onChange }: ProductInfoProps) {
  return (
    <div className="grid grid-cols-2 gap-4 mb-6 p-4 bg-white rounded-lg border">
      <div>
        <label className="text-xs font-semibold">Product No.</label>
        {isEditing ? (
          <Input
            value={document.productNo}
            onChange={(e) => onChange('productNo', e.target.value)}
            className="mt-1"
            placeholder="PRD-001"
          />
        ) : (
          <p className="mt-1 text-sm font-medium">{document.productNo || '-'}</p>
        )}
      </div>

      <div>
        <label className="text-xs font-semibold">Rev.</label>
        {isEditing ? (
          <Input
            value={document.productRev}
            onChange={(e) => onChange('productRev', e.target.value)}
            className="mt-1"
            placeholder="1.0"
          />
        ) : (
          <p className="mt-1 text-sm font-medium">{document.productRev || '-'}</p>
        )}
      </div>

      <div>
        <label className="text-xs font-semibold">Project No.</label>
        {isEditing ? (
          <Input
            value={document.projectNo}
            onChange={(e) => onChange('projectNo', e.target.value)}
            className="mt-1"
            placeholder="PROJ-2024"
          />
        ) : (
          <p className="mt-1 text-sm font-medium">{document.projectNo || '-'}</p>
        )}
      </div>

      <div>
        <label className="text-xs font-semibold">Product Name</label>
        {isEditing ? (
          <Input
            value={document.productName}
            onChange={(e) => onChange('productName', e.target.value)}
            className="mt-1"
            placeholder="Product Name"
          />
        ) : (
          <p className="mt-1 text-sm font-medium">{document.productName || '-'}</p>
        )}
      </div>

      <div>
        <label className="text-xs font-semibold">Purpose</label>
        {isEditing ? (
          <Select value={document.purpose} onValueChange={(v: any) => onChange('purpose', v)}>
            <SelectTrigger className="mt-1">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="new-product-validation">New Product Validation</SelectItem>
              <SelectItem value="sales">Sales</SelectItem>
            </SelectContent>
          </Select>
        ) : (
          <p className="mt-1 text-sm font-medium">
            {document.purpose === 'new-product-validation'
              ? 'New Product Validation'
              : 'Sales'}
          </p>
        )}
      </div>

      <div>
        <label className="text-xs font-semibold">Monthly Qty</label>
        {isEditing ? (
          <Input
            type="number"
            value={document.monthlyQty}
            onChange={(e) => onChange('monthlyQty', parseInt(e.target.value) || 0)}
            className="mt-1"
            placeholder="0"
          />
        ) : (
          <p className="mt-1 text-sm font-medium">{document.monthlyQty}</p>
        )}
      </div>
    </div>
  )
}
