import { Button } from '../ui/button'
import { X } from 'lucide-react'
import type { RequisitionDocument } from '../../types'

interface FormHeaderProps {
  document: RequisitionDocument
  isEditing: boolean
  onClose: () => void
  onAutoPopulate: () => void
  onToggleEdit: () => void
  onSave: () => void
}

export function FormHeader({
  document,
  isEditing,
  onClose,
  onAutoPopulate,
  onToggleEdit,
  onSave,
}: FormHeaderProps) {
  return (
    <div className="flex justify-between items-start mb-6 pb-4 border-b">
      <div>
        <h2 className="text-2xl font-bold">JANATICS - REQUISITION FOR COMPONENT DEVELOPMENT</h2>
        <p className="text-sm text-slate-500 mt-1">Form No: F/D&D/21 | Issue No: 4.2</p>
      </div>
      <div className="flex gap-2">
        <Button variant="outline" size="sm" onClick={onAutoPopulate}>
          Fetch & Auto-Populate
        </Button>
        {isEditing ? (
          <>
            <Button size="sm" onClick={onSave}>
              Save
            </Button>
            <Button variant="outline" size="sm" onClick={onToggleEdit}>
              Cancel
            </Button>
          </>
        ) : (
          <Button variant="outline" size="sm" onClick={onToggleEdit}>
            Edit
          </Button>
        )}
        <Button variant="ghost" size="sm" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}
