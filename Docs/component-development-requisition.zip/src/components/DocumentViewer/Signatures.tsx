import { Input } from '../ui/input'
import { formatDateTime } from '../../utils/date-format'
import type { RequisitionDocument } from '../../types'

interface SignaturesProps {
  document: RequisitionDocument
  isEditing: boolean
  onChange: (field: keyof RequisitionDocument, value: any) => void
}

const signatureFields = [
  { key: 'preparedBy', label: 'Prepared By' },
  { key: 'checkedBy', label: 'Checked By' },
  { key: 'approvedBy', label: 'Approved By' },
  { key: 'receivedBy', label: 'Received By' },
] as const

export function Signatures({ document, isEditing, onChange }: SignaturesProps) {
  return (
    <div className="p-4 bg-white rounded-lg border">
      <h3 className="font-semibold text-sm mb-4">Workflow & Signatures</h3>
      <div className="grid grid-cols-4 gap-4">
        {signatureFields.map(({ key, label }) => (
          <div key={key}>
            <label className="text-xs font-semibold">{label}</label>
            {isEditing ? (
              <Input
                value={document[`${key}` as keyof RequisitionDocument] as string || ''}
                onChange={(e) => onChange(`${key}` as keyof RequisitionDocument, e.target.value)}
                className="mt-1 text-xs"
                placeholder="Name"
              />
            ) : (
              <p className="mt-1 text-xs font-medium">
                {(document[`${key}` as keyof RequisitionDocument] as string) || '-'}
              </p>
            )}
            <p className="text-xs text-slate-400 mt-1">
              {formatDateTime(document[`${key}Date` as keyof RequisitionDocument] as Date)}
            </p>
          </div>
        ))}
      </div>
    </div>
  )
}
