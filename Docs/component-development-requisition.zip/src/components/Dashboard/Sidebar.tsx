import { Button } from '../ui/button'
import { LogOut } from 'lucide-react'

interface SidebarProps {
  user: { email: string; name: string }
  onLogout: () => void
}

export function Sidebar({ user, onLogout }: SidebarProps) {
  return (
    <div className="w-64 bg-slate-900 text-white p-6 flex flex-col">
      <div className="mb-8">
        <h1 className="text-2xl font-bold">JANATICS</h1>
        <p className="text-slate-400 text-xs mt-1">Requisition System</p>
      </div>

      <nav className="flex-1 space-y-2">
        <div className="text-slate-400 text-sm font-medium mb-4">Menu</div>
        <div className="px-3 py-2 rounded-lg bg-slate-800">Documents</div>
      </nav>

      <div className="border-t border-slate-700 pt-4">
        <div className="text-sm mb-4">
          <p className="text-slate-400">Logged in as</p>
          <p className="font-medium">{user.name}</p>
          <p className="text-slate-400 text-xs">{user.email}</p>
        </div>
        <Button
          variant="outline"
          className="w-full justify-start"
          onClick={onLogout}
        >
          <LogOut className="mr-2 h-4 w-4" />
          Logout
        </Button>
      </div>
    </div>
  )
}
