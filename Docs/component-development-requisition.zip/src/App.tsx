import { useState } from 'react'
import { Login } from './components/Login'
import { Dashboard } from './components/Dashboard'
import { DocumentViewer } from './components/DocumentViewer'
import { mockUser } from './utils/mock-data'
import type { RequisitionDocument } from './types'

export function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [selectedDocument, setSelectedDocument] = useState<RequisitionDocument | null>(null)
  const [isCreatingNew, setIsCreatingNew] = useState(false)

  const handleLogin = (email: string) => {
    setIsLoggedIn(true)
  }

  const handleLogout = () => {
    setIsLoggedIn(false)
    setSelectedDocument(null)
    setIsCreatingNew(false)
  }

  const handleSelectDocument = (doc: RequisitionDocument) => {
    setSelectedDocument(doc)
    setIsCreatingNew(false)
  }

  const handleCreateNew = () => {
    setSelectedDocument(null)
    setIsCreatingNew(true)
  }

  const handleSaveDocument = (doc: RequisitionDocument) => {
    setSelectedDocument(null)
    setIsCreatingNew(false)
  }

  const handleCloseViewer = () => {
    setSelectedDocument(null)
    setIsCreatingNew(false)
  }

  if (!isLoggedIn) {
    return <Login onLogin={handleLogin} />
  }

  return (
    <div>
      <Dashboard
        user={mockUser}
        onLogout={handleLogout}
        onSelectDocument={handleSelectDocument}
        onCreateNew={handleCreateNew}
      />

      {(selectedDocument || isCreatingNew) && (
        <DocumentViewer
          document={selectedDocument}
          isNew={isCreatingNew}
          onClose={handleCloseViewer}
          onSave={handleSaveDocument}
        />
      )}
    </div>
  )
}
