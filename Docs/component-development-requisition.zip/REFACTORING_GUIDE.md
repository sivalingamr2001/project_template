# Component Development Requisition System - Refactoring Guide

## Overview
This project has been refactored following strict code organization and quality standards (R-01, R-02, R-03) to ensure maintainability, scalability, and developer experience.

## Architecture Standards Applied

### R-01: SIZE LIMIT (< 100 Lines Per File)
Every component file is strictly under 100 lines to ensure:
- **Readability**: Single responsibility principle
- **Testability**: Easier to test smaller units
- **Maintenance**: Reduced cognitive load

**Example:**
- ✓ LoginForm.tsx: 93 lines
- ✓ SearchBar.tsx: 50 lines
- ✓ FormHeader.tsx: 53 lines

### R-02: FOLDER COLOCATION (Grouped Related Files)
All related files are grouped into feature folders with a standard structure:

```
FeatureName/
├── index.tsx           # Public entry point (exports only)
├── SubComponent.tsx    # Sub-components
├── AnotherComponent.tsx
├── types.ts            # TypeScript interfaces
├── hooks/              # Custom hooks
│   └── useCustomHook.ts
├── utils/              # Utility functions
│   └── helper.ts
└── constants.ts        # Static constants
```

**Example Structure:**
```
src/components/
├── Login/
│   ├── index.tsx       (17 lines - exports LoginForm)
│   ├── LoginForm.tsx   (93 lines - form logic)
│   └── types.ts        (9 lines - interfaces)
├── Dashboard/
│   ├── index.tsx       (45 lines)
│   ├── Sidebar.tsx     (40 lines)
│   ├── SearchBar.tsx   (50 lines)
│   ├── RequisitionTable.tsx (82 lines)
│   ├── useSearch.ts    (43 lines)
│   └── types.ts        (14 lines)
├── DocumentViewer/
│   ├── index.tsx       (106 lines)
│   ├── FormHeader.tsx  (53 lines)
│   ├── FormMeta.tsx    (58 lines)
│   ├── ProductInfo.tsx (114 lines)
│   ├── PartTable.tsx   (134 lines)
│   ├── Signatures.tsx  (47 lines)
│   ├── utils.ts        (59 lines)
│   └── types.ts        (14 lines)
```

### R-03: READABILITY ORDER (Consistent Structure)
Every component follows this exact structure for consistency:

```typescript
// 1. Types / Interfaces
interface Props { ... }
type CustomType = ...

// 2. Static constants (outside function)
const VALIDATION_ERRORS = { ... }
const STATUS_COLORS = { ... }

// 3. Component signature
export function ComponentName({ prop1, prop2 }: Props) {

  // 4. Hook calls (useState → useEffect → custom)
  const [state, setState] = useState()
  const customData = useCustomHook()
  useEffect(() => { ... }, [])

  // 5. Derived / memoised values
  const filtered = useMemo(() => { ... }, [dependencies])
  const computed = calculate(state)

  // 6. Event handlers (handleXxx)
  const handleClick = () => { ... }
  const handleChange = (e) => { ... }

  // 7. Early returns (loading | error | empty)
  if (isLoading) return <LoadingSpinner />
  if (error) return <ErrorMessage />
  if (data.length === 0) return <EmptyState />

  // 8. Single JSX return
  return (
    <div>...</div>
  )
}
```

## Naming Conventions Applied

| Pattern | Usage | Example |
|---------|-------|---------|
| `Props` | Props interface | `interface LoginFormProps { onLogin: () => void }` |
| `handleXxx` | Event handlers | `const handleSubmit = (e) => { ... }` |
| `isXxx` | Boolean props/state | `const isLoading = useState()`, `isEditing` |
| `hasXxx` | Has/contains boolean | `hasError`, `hasContent` |
| `canXxx` | Ability boolean | `canDelete`, `canEdit` |
| `useXxx` | Custom hooks | `useSearch()`, `useValidation()` |

## Project Structure

```
src/
├── components/
│   ├── Login/                 # Authentication UI
│   ├── Dashboard/             # Main document list & navigation
│   ├── DocumentViewer/        # Form editor & display
│   ├── ui/                    # shadcn/ui components
│   └── theme-provider.tsx     # Theme wrapper
├── types/
│   ├── index.ts               # Exports all types
│   └── requisition.ts         # Domain types
├── utils/
│   ├── mock-data.ts           # Mock API data
│   ├── cn.ts                  # Class name helper
│   ├── date-format.ts         # Date utilities
│   └── date-format.ts         # Date formatting
├── hooks/
│   ├── use-mobile.ts          # Mobile detection
│   └── use-toast.ts           # Toast notifications
├── lib/
│   └── utils.ts               # Shared utilities
├── App.tsx                    # Main app router
├── main.tsx                   # Vite entry point
└── index.css                  # Tailwind CSS
```

## Key Design Decisions

### 1. State Management
- Used React `useState` for simple component state
- Custom hooks for complex state logic (e.g., `useSearch`)
- Props drilling used for simplicity (appropriate for app size)

### 2. No Inline Arrow Functions
❌ **Avoid:**
```typescript
<button onClick={() => handleClick(id)}>Click</button>
```

✓ **Correct:**
```typescript
const handleButtonClick = () => handleClick(id)
return <button onClick={handleButtonClick}>Click</button>
```

### 3. Single-Level Ternaries Only
❌ **Avoid:**
```typescript
{isLoading ? <Spinner /> : data ? <List data={data} /> : <Empty />}
```

✓ **Correct:**
```typescript
if (isLoading) return <Spinner />
if (!data) return <Empty />
return <List data={data} />
```

### 4. Separated Logic and JSX
❌ **Avoid:**
```typescript
const Component = () => {
  const [items, setItems] = useState([])
  const filtered = items.filter(...)
  return (
    <div>
      {data.map(item => (
        <Item 
          key={item.id}
          data={item.filter(...).map(...)}
        />
      ))}
    </div>
  )
}
```

✓ **Correct:**
```typescript
const Component = () => {
  const [items, setItems] = useState([])
  const filtered = useMemo(() => 
    items.filter(...), [items]
  )
  
  return (
    <div>
      {filtered.map(item => (
        <Item key={item.id} data={item} />
      ))}
    </div>
  )
}
```

## Feature Overview

### 1. Login Component
- **Path**: `src/components/Login/`
- **Files**: index.tsx, LoginForm.tsx, types.ts
- **Purpose**: User authentication UI
- **Features**: Email/password validation, form state management

### 2. Dashboard Component
- **Path**: `src/components/Dashboard/`
- **Files**: index.tsx, Sidebar.tsx, SearchBar.tsx, RequisitionTable.tsx, useSearch.ts, types.ts
- **Purpose**: Document list and navigation
- **Features**: Search, filtering by status, responsive layout

### 3. DocumentViewer Component
- **Path**: `src/components/DocumentViewer/`
- **Files**: index.tsx, FormHeader.tsx, FormMeta.tsx, ProductInfo.tsx, PartTable.tsx, Signatures.tsx, utils.ts, types.ts
- **Purpose**: Form editor and display
- **Features**: 
  - Auto-populate with mock data
  - Edit mode with validation
  - Dynamic part table
  - Workflow signature tracking

## Development Workflow

### Adding a New Feature
1. Create a new folder in `src/components/FeatureName/`
2. Create `index.tsx` as the public entry point
3. Create sub-components, keeping each < 100 lines
4. Create `types.ts` with all TypeScript interfaces
5. Create `utils.ts` or `hooks/` subdirectory as needed
6. Export only from `index.tsx`

### Modifying Existing Components
1. Keep files < 100 lines
2. Extract functionality to sub-components if exceeded
3. Extract complex logic to custom hooks or utilities
4. Maintain the R-03 readability order structure

## Best Practices

### ✓ DO
- Extract sub-components when file approaches 100 lines
- Use custom hooks for reusable stateful logic
- Keep components focused on a single responsibility
- Use TypeScript interfaces for props and state
- Memoize expensive calculations with useMemo
- Export only the main component from index.tsx

### ✗ DON'T
- Create files > 100 lines
- Mix multiple concerns in one component
- Use inline arrow functions in JSX
- Nest ternaries deeper than 1 level
- Import internal components directly (use index.tsx)
- Place logic and JSX in the same block without separation

## Testing Strategy

Each feature folder can be tested independently:
- Component tests use exported components from `index.tsx`
- Hook tests import custom hooks directly
- Type safety is enforced at compile time

## Type Safety

All domain types are defined in `src/types/`:
- `RequisitionDocument`: Main form document
- `Part`: Component part in requisition
- `User`: User information
- `SearchState`: Dashboard filter state

Custom component types are defined locally in `types.ts` files.

## Performance Considerations

- Components are code-split by feature
- Memoized selectors prevent unnecessary re-renders
- useMemo used for expensive computations
- Custom hooks for state management reduce re-render cycles

## Migration Guide (Next.js → Vite)

This project was migrated from Next.js to Vite with the following changes:
- Removed Next.js specific features (Image, Link, etc.)
- Switched to React Router (if routing is added)
- Updated build configuration for Vite
- Modernized TypeScript configuration
- Updated CSS imports for Vite

---

## Summary

This refactored codebase demonstrates professional-grade React development with strict adherence to code organization standards. Every component is modular, maintainable, and follows consistent patterns across the entire application.
