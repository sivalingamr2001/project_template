import oracledb from 'oracledb';
import { getConnection } from '../db/pool';
import { SALES_DATA_SQL, SALES_SUMMARY_SQL } from '../db/queries';

export interface SalesFilter {
  fromDate?: string;
  toDate?: string;
  region?: string;
}

export interface SaleRecord {
  OU_NAME: string;
  YR: string;
  SALE_VAL: number;
}

export interface SummaryRecord {
  OU_NAME: string;
  YR: string;
  PEND_ORD_VAL: number;
}

export interface SalesResult {
  filters: {
    fromDate: string;
    toDate: string;
    region: string | null;
  };
  sales: SaleRecord[];
  summary: SummaryRecord[];
}

const FETCH_ARRAY_SIZE = 200;
const PREFETCH_ROWS = 201;

export async function fetchSales(filter: SalesFilter): Promise<SalesResult> {
  const conn = await getConnection();

  try {
    const fromDate = filter.fromDate ?? '2025-04-01';
    const toDate = filter.toDate ?? new Date().toISOString().slice(0, 10);
    const region = filter.region?.trim() ? filter.region.trim() : null;

    if (fromDate > toDate) {
      const error = new Error('fromDate must be less than or equal to toDate');
      Object.assign(error, { statusCode: 400 });
      throw error;
    }

    const binds = {
      fromDate,
      toDate,
      region,
    };

    const [dataResult, summaryResult] = await Promise.all([
      conn.execute<SaleRecord>(SALES_DATA_SQL, binds, {
        outFormat: oracledb.OUT_FORMAT_OBJECT,
        fetchArraySize: FETCH_ARRAY_SIZE,
        prefetchRows: PREFETCH_ROWS,
      }),
      conn.execute<SummaryRecord>(SALES_SUMMARY_SQL, binds, {
        outFormat: oracledb.OUT_FORMAT_OBJECT,
        fetchArraySize: FETCH_ARRAY_SIZE,
        prefetchRows: PREFETCH_ROWS,
      }),
    ]);

    return {
      filters: {
        fromDate,
        toDate,
        region,
      },
      sales: dataResult.rows ?? [],
      summary: summaryResult.rows ?? [],
    };
  } finally {
    await conn.close();
  }
}
