import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { fetchSales } from '../services/sales.service';

const querySchema = {
  type: 'object',
  properties: {
    fromDate: { type: 'string', pattern: '^\\d{4}-\\d{2}-\\d{2}$' },
    toDate: { type: 'string', pattern: '^\\d{4}-\\d{2}-\\d{2}$' },
    region: { type: 'string', maxLength: 100 },
  },
  additionalProperties: false,
};

const responseSchema = {
  200: {
    type: 'object',
    properties: {
      success: { type: 'boolean' },
      filters: {
        type: 'object',
        properties: {
          fromDate: { type: 'string' },
          toDate: { type: 'string' },
          region: { type: ['string', 'null'] },
        },
      },
      sales: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            OU_NAME: { type: 'string' },
            YR: { type: 'string' },
            SALE_VAL: { type: 'number' },
          },
          required: ['OU_NAME', 'YR', 'SALE_VAL'],
        },
      },
      summary: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            OU_NAME: { type: 'string' },
            YR: { type: 'string' },
            PEND_ORD_VAL: { type: 'number' },
          },
          required: ['OU_NAME', 'YR', 'PEND_ORD_VAL'],
        },
      },
    },
    required: ['success', 'filters', 'sales', 'summary'],
  },
};

interface SalesQuery {
  fromDate?: string;
  toDate?: string;
  region?: string;
}

export async function salesRoutes(app: FastifyInstance): Promise<void> {
  app.get<{ Querystring: SalesQuery }>(
    '/sales',
    {
      schema: {
        querystring: querySchema,
        response:    responseSchema,
      },
    },
    async (req: FastifyRequest<{ Querystring: SalesQuery }>, reply: FastifyReply) => {
      const result = await fetchSales(req.query);
      return reply.send({ success: true, ...result });
    }
  );
}
