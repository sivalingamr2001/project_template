import { buildApp } from './app';

let isShuttingDown = false;

async function start(): Promise<void> {
  const app = await buildApp();

    const shutdown = async (signal: string): Promise<void> => {
      if (isShuttingDown) return;
      isShuttingDown = true;
      app.log.info({ signal }, 'Shutdown signal received');

      try {
        await app.close();
        app.log.info('Graceful shutdown complete');
        process.exit(0);
      } catch (err) {
        app.log.error({ err }, 'Error during shutdown');
        process.exit(1);
      }
  };

  process.on('SIGTERM', () => {
    void shutdown('SIGTERM');
  });
  process.on('SIGINT', () => {
    void shutdown('SIGINT');
  });
  process.on('uncaughtException', (err) => {
    app.log.fatal({ err }, 'Uncaught exception');
    void shutdown('uncaughtException');
  });
  process.on('unhandledRejection', (reason) => {
    app.log.fatal({ reason }, 'Unhandled rejection');
    void shutdown('unhandledRejection');
  });

  try {
    await app.listen({
      port: app.config.PORT,
      host: app.config.HOST,
    });
  } catch (err) {
    app.log.fatal({ err }, 'Failed to start server');
    process.exit(1);
  }
}

void start();
