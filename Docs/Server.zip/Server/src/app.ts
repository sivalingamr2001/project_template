import Fastify, { FastifyInstance, FastifyError } from 'fastify';
import cors from '@fastify/cors';
import { registerEnv } from './config/env';
import { closePool, initPool } from './db/pool';
import { salesRoutes } from './routes/sales.route';
import { healthRoutes } from './routes/health.route';

export async function buildApp(): Promise<FastifyInstance> {
  const app = Fastify({
    logger: {
      level: process.env.NODE_ENV === 'production' ? 'info' : 'debug',
      serializers: {
        req(req) {
          return { method: req.method, url: req.url };
        },
      },
    },
    trustProxy: true,
    ajv: {
      customOptions: {
        coerceTypes: 'array',
        useDefaults: true,
        removeAdditional: true,
      },
    },
  });

  await registerEnv(app);

  await app.register(cors, {
    origin: true,
    credentials: true,
  });

  await initPool(app.config);
  app.log.info('Oracle connection pool ready');

  app.addHook('onClose', async () => {
    await closePool();
  });

  app.setErrorHandler((err: FastifyError, _req, reply) => {
    const status = err.statusCode ?? 500;
    app.log.error({ err }, 'Request error caught by global handler');

    reply.status(status).send({
      success: false,
      error: status >= 500 ? 'Internal server error' : err.message,
    });
  });

  await app.register(healthRoutes);
  await app.register(salesRoutes, { prefix: '/api' });

  return app;
}
