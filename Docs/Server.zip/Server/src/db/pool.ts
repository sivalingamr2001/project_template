import oracledb from 'oracledb';
import { Env } from '../config/env';

let pool: oracledb.Pool | null = null;
let oracleClientInitialized = false;

export async function initPool(config: Env): Promise<void> {
  if (pool) {
    return;
  }

  oracledb.fetchAsString = [oracledb.CLOB];
  oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT;

  // Use Thick mode only when an Oracle client path is explicitly configured.
  if (config.DB_CLIENT_DIR && !oracleClientInitialized) {
    oracledb.initOracleClient({ libDir: config.DB_CLIENT_DIR });
    oracleClientInitialized = true;
  }

  pool = await oracledb.createPool({
    user: config.DB_USER,
    password: config.DB_PASSWORD,
    connectString: config.DB_CONNECT_STRING,
    poolMin: config.DB_POOL_MIN,
    poolMax: config.DB_POOL_MAX,
    poolIncrement: config.DB_POOL_INCREMENT,
    poolTimeout: config.DB_POOL_TIMEOUT,
    queueTimeout: 10_000,
    enableStatistics: false,
  });
}

export async function getConnection(): Promise<oracledb.Connection> {
  if (!pool) throw new Error('Pool not initialised');
  return pool.getConnection();
}

export async function closePool(): Promise<void> {
  if (pool) {
    await pool.close(10);
    pool = null;
  }
}
