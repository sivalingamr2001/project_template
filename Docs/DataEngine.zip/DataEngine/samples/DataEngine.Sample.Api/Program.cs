using System.Data;
using System.Text.Json;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using MySqlConnector;

var builder = WebApplication.CreateBuilder(args);

// ─────────────────────────────────────────────────────────────────────────────
// 1. FIX: MySqlConnector uses "User" not "Username" keyword.
//    We patch the connection strings at startup before anything opens a connection.
// ─────────────────────────────────────────────────────────────────────────────
static string FixConnectionString(string? cs)
{
    if (string.IsNullOrWhiteSpace(cs)) return string.Empty;
    // Replace "Username=" with "User=" (case-insensitive)
    return System.Text.RegularExpressions.Regex.Replace(
        cs, @"(?i)username\s*=", "User=");
}

var rawDefault    = builder.Configuration.GetConnectionString("DefaultConnection");
var rawReporting  = builder.Configuration.GetConnectionString("ReportingConnection");
var defaultCs     = FixConnectionString(rawDefault);
var reportingCs   = FixConnectionString(rawReporting);

// Override in-memory so the rest of the app picks up the fixed strings
builder.Configuration["ConnectionStrings:DefaultConnection"]   = defaultCs;
builder.Configuration["ConnectionStrings:ReportingConnection"] = reportingCs;

// ─────────────────────────────────────────────────────────────────────────────
// 2. Swagger / OpenAPI
// ─────────────────────────────────────────────────────────────────────────────
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new()
    {
        Title       = "DataEngine Demo API",
        Version     = "v1",
        Description = """
            Live demonstration of DataEngine — a metadata-driven, plug-and-play
            .NET 8 backend framework.

            ✅ No entity classes
            ✅ No migrations
            ✅ No EF Core
            ✅ Full CRUD driven by INFORMATION_SCHEMA
            ✅ Transactions, bulk ops, stored procedures
            ✅ Runtime schema validation & caching
            """
    });
});

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", builder =>
    {
        builder.AllowAnyOrigin()
               .AllowAnyMethod()
               .AllowAnyHeader();
    });
});

// ─────────────────────────────────────────────────────────────────────────────
// 3. DataEngine registration
//    Uses the fixed connection strings already written to IConfiguration.
// ─────────────────────────────────────────────────────────────────────────────
// NOTE: Replace these with your real AddDataEngine() from the framework.
//       For this standalone demo we wire a lightweight in-process version
//       using raw Dapper + ADO.NET that mirrors the DataEngine API exactly.
//
//  When the full DataEngine NuGet is installed, replace the block below with:
//  ┌─────────────────────────────────────────────────────┐
//  │  builder.Services                                   │
//  │      .AddDataEngine(builder.Configuration)          │
//  │      .WithAudit()                                   │
//  │      .WithDatabase("reporting","ReportingConnection")│
//  └─────────────────────────────────────────────────────┘

builder.Services.AddSingleton<IDemoDataEngine>(sp =>
    new DemoDataEngine(defaultCs, reportingCs,
        sp.GetRequiredService<ILogger<DemoDataEngine>>()));

var app = builder.Build();

// ─────────────────────────────────────────────────────────────────────────────
// 4. AUTO-CREATE MASTER TABLES on startup
//    Creates DataEngine_TestDB + demo tables + all 3 optional extension tables
//    Safe to run on every boot — uses CREATE TABLE IF NOT EXISTS throughout.
// ─────────────────────────────────────────────────────────────────────────────
await AutoCreateDatabaseAndTablesAsync(defaultCs, app.Logger);

// ─────────────────────────────────────────────────────────────────────────────
// 5. Middleware
// ─────────────────────────────────────────────────────────────────────────────
app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/v1/swagger.json", "DataEngine Demo v1");
    c.RoutePrefix = string.Empty; // Swagger at root
    c.DocumentTitle = "DataEngine Demo API";
});

app.UseCors("AllowAll");

// ═════════════════════════════════════════════════════════════════════════════
//
//  API ENDPOINTS — every capability DataEngine exposes
//
// ═════════════════════════════════════════════════════════════════════════════

// ─────────────────────────────────────────────────────────────────────────────
// GROUP A: SCHEMA INSPECTION
// ─────────────────────────────────────────────────────────────────────────────

var schemaGroup = app.MapGroup("/api/schema")
    .WithTags("A — Schema Inspection");

/// <summary>List all tables in the database from INFORMATION_SCHEMA.</summary>
schemaGroup.MapGet("/tables", async (IDemoDataEngine engine) =>
{
    var tables = await engine.ListTablesAsync();
    return Results.Ok(new
    {
        description = "All tables discovered from INFORMATION_SCHEMA. " +
                      "DataEngine uses this to validate every table/column reference at runtime.",
        tables
    });
})
.WithName("ListTables")
.WithSummary("List all tables")
.WithDescription("Reads INFORMATION_SCHEMA.TABLES. DataEngine caches this on startup.");

/// <summary>Inspect full column metadata for a table.</summary>
schemaGroup.MapGet("/tables/{tableName}", async (IDemoDataEngine engine, string tableName) =>
{
    var schema = await engine.GetTableSchemaAsync(tableName);
    if (schema is null)
        return Results.NotFound(new { error = $"Table '{tableName}' not found." });

    return Results.Ok(new
    {
        description = "Column metadata loaded from INFORMATION_SCHEMA. " +
                      "DataEngine validates every column name in every request against this.",
        schema
    });
})
.WithName("GetTableSchema")
.WithSummary("Get table schema")
.WithDescription("Returns columns, data types, nullability, primary keys, auto-increment flags.");

/// <summary>Manually invalidate + reload the schema cache.</summary>
schemaGroup.MapPost("/cache/invalidate", async (IDemoDataEngine engine) =>
{
    await engine.InvalidateSchemaCacheAsync();
    return Results.Ok(new
    {
        message = "Schema cache invalidated and reloaded.",
        description = "Call this after ALTER TABLE, CREATE TABLE, or DROP TABLE " +
                      "to force DataEngine to re-read INFORMATION_SCHEMA."
    });
})
.WithName("InvalidateSchemaCache")
.WithSummary("Invalidate schema cache");

// ─────────────────────────────────────────────────────────────────────────────
// GROUP B: DYNAMIC QUERY (READ)
// ─────────────────────────────────────────────────────────────────────────────

var queryGroup = app.MapGroup("/api/query")
    .WithTags("B — Dynamic Query (Read)");

/// <summary>
/// Dynamic SELECT with filtering, sorting, pagination, projections.
/// This is DataEngine's core read capability.
/// </summary>
queryGroup.MapPost("/{tableName}", async (
    IDemoDataEngine engine,
    string tableName,
    [FromBody] QueryRequest request) =>
{
    var result = await engine.QueryAsync(tableName, request);
    return Results.Ok(result);
})
.WithName("DynamicQuery")
.WithSummary("Dynamic SELECT — filter, sort, paginate, project")
.WithDescription("""
    DataEngine's primary read operation. Supply:
    - columns: which columns to SELECT (null = all)
    - filters: WHERE clauses (Equals/Like/In/Between/IsNull etc.)
    - sort: ORDER BY
    - pagination: LIMIT + OFFSET
    - includeCount: run a COUNT(*) alongside the data query

    All table names and column names are validated against the schema cache.
    All values are parameterized — zero injection risk.
    """)
.WithOpenApi(op =>
{
    op.RequestBody.Description = """
        Sample — get active products in 'cylinders' category, sorted by price:
        {
          "columns": ["id", "sku", "name", "price", "stock"],
          "filters": [
            { "column": "category", "operator": "Equals", "value": "cylinders" },
            { "column": "is_active", "operator": "Equals", "value": 1, "logic": "And" }
          ],
          "sort": [{ "column": "price", "direction": "Ascending" }],
          "pagination": { "page": 1, "pageSize": 10 },
          "includeCount": true
        }
        """;
    return op;
});

// ─────────────────────────────────────────────────────────────────────────────
// GROUP C: SINGLE-ROW WRITES
// ─────────────────────────────────────────────────────────────────────────────

var writeGroup = app.MapGroup("/api/write")
    .WithTags("C — Single-Row Writes");

/// <summary>INSERT a single row dynamically.</summary>
writeGroup.MapPost("/{tableName}/insert", async (
    IDemoDataEngine engine,
    string tableName,
    [FromBody] InsertRequest request) =>
{
    var result = await engine.InsertAsync(tableName, request);
    return result.Success
        ? Results.Created($"/api/query/{tableName}", result)
        : Results.UnprocessableEntity(result);
})
.WithName("DynamicInsert")
.WithSummary("INSERT a single row")
.WithDescription("""
    DataEngine validates every column against the schema before building SQL.
    Auto-increment columns are automatically excluded from the INSERT — you never
    need to know or care which column is the PK.

    Sample request for 'products' table:
    {
      "values": {
        "sku": "CYL-050",
        "name": "Pneumatic Cylinder 50mm",
        "price": 1850.00,
        "stock": 75,
        "category": "cylinders",
        "is_active": 1
      },
      "executedBy": "admin",
      "correlationId": "req-abc-123"
    }
    """);

/// <summary>UPDATE rows matching filter clauses.</summary>
writeGroup.MapPut("/{tableName}/update", async (
    IDemoDataEngine engine,
    string tableName,
    [FromBody] UpdateRequest request) =>
{
    var result = await engine.UpdateAsync(tableName, request);
    return result.Success
        ? Results.Ok(result)
        : Results.UnprocessableEntity(result);
})
.WithName("DynamicUpdate")
.WithSummary("UPDATE rows matching filters")
.WithDescription("""
    Filters are REQUIRED. DataEngine refuses UPDATE with no WHERE clause by design.

    Sample — mark a product inactive:
    {
      "values": { "is_active": 0 },
      "filters": [{ "column": "sku", "operator": "Equals", "value": "CYL-050" }],
      "executedBy": "admin"
    }
    """);

/// <summary>DELETE rows matching filter clauses.</summary>
writeGroup.MapDelete("/{tableName}/delete", async (
    IDemoDataEngine engine,
    string tableName,
    [FromBody] DeleteRequest request) =>
{
    var result = await engine.DeleteAsync(tableName, request);
    return result.Success
        ? Results.Ok(result)
        : Results.UnprocessableEntity(result);
})
.WithName("DynamicDelete")
.WithSummary("DELETE rows matching filters")
.WithDescription("""
    Filters are REQUIRED. DataEngine refuses DELETE with no WHERE clause by design.

    Sample — delete a specific product:
    {
      "filters": [{ "column": "sku", "operator": "Equals", "value": "CYL-050" }],
      "executedBy": "admin"
    }
    """);

// ─────────────────────────────────────────────────────────────────────────────
// GROUP D: BULK OPERATIONS
// ─────────────────────────────────────────────────────────────────────────────

var bulkGroup = app.MapGroup("/api/bulk")
    .WithTags("D — Bulk Operations");

/// <summary>INSERT multiple rows in configurable batches.</summary>
bulkGroup.MapPost("/{tableName}/insert", async (
    IDemoDataEngine engine,
    string tableName,
    [FromBody] BulkInsertRequest request) =>
{
    var result = await engine.BulkInsertAsync(tableName, request);
    return Results.Ok(result);
})
.WithName("BulkInsert")
.WithSummary("Bulk INSERT — multiple rows in batches")
.WithDescription("""
    Splits large row sets into batches (default 500 rows/batch).
    Each batch executes in its own transaction.

    Sample — insert 3 products:
    {
      "rows": [
        { "sku": "VLV-010", "name": "Solenoid Valve 10mm", "price": 720.00, "stock": 200, "category": "valves", "is_active": 1 },
        { "sku": "VLV-020", "name": "Solenoid Valve 20mm", "price": 980.00, "stock": 150, "category": "valves", "is_active": 1 },
        { "sku": "FLT-010", "name": "Air Filter 10 micron", "price": 350.00, "stock": 400, "category": "filters", "is_active": 1 }
      ],
      "batchSize": 500,
      "onConflict": "Ignore"
    }
    """);

// ─────────────────────────────────────────────────────────────────────────────
// GROUP E: TRANSACTIONS
// ─────────────────────────────────────────────────────────────────────────────

var txGroup = app.MapGroup("/api/transaction")
    .WithTags("E — Multi-Operation Transactions");

/// <summary>Execute multiple operations atomically.</summary>
txGroup.MapPost("/execute", async (
    IDemoDataEngine engine,
    [FromBody] TransactionRequest request) =>
{
    var result = await engine.ExecuteTransactionAsync(request);
    return result.Success
        ? Results.Ok(result)
        : Results.UnprocessableEntity(result);
})
.WithName("ExecuteTransaction")
.WithSummary("Execute multiple operations atomically")
.WithDescription("""
    All operations succeed together or all roll back together.
    Operations are sorted by their 'order' field before execution.

    Sample — create an order and decrement stock atomically:
    {
      "operations": [
        {
          "order": 1,
          "type": "Insert",
          "table": "orders",
          "values": { "product_id": 1, "quantity": 5, "status": "pending", "customer_name": "Acme Corp", "total_amount": 7500.00 }
        },
        {
          "order": 2,
          "type": "Update",
          "table": "products",
          "values": { "stock": 95 },
          "filters": [{ "column": "id", "operator": "Equals", "value": 1 }]
        }
      ],
      "executedBy": "order-service",
      "correlationId": "order-xyz-789"
    }
    """);

// ─────────────────────────────────────────────────────────────────────────────
// GROUP F: STORED PROCEDURES
// ─────────────────────────────────────────────────────────────────────────────

var procGroup = app.MapGroup("/api/procedure")
    .WithTags("F — Stored Procedures");

/// <summary>Execute a stored procedure (read or write).</summary>
procGroup.MapPost("/execute", async (
    IDemoDataEngine engine,
    [FromBody] ProcedureRequest request) =>
{
    var result = await engine.ExecuteProcedureAsync(request);
    return result.Success
        ? Results.Ok(result)
        : Results.UnprocessableEntity(result);
})
.WithName("ExecuteProcedure")
.WithSummary("Execute a stored procedure")
.WithDescription("""
    Read procedures use Dapper (supports multiple result sets).
    Write procedures use ADO.NET (full transaction control + OUTPUT params).

    Sample — call sp_get_products_by_category (read):
    {
      "procedureName": "sp_get_products_by_category",
      "type": "Read",
      "parameters": [
        { "name": "p_category", "value": "cylinders", "direction": "Input" }
      ]
    }

    Sample — call sp_update_stock (write with OUTPUT param):
    {
      "procedureName": "sp_update_stock",
      "type": "Write",
      "parameters": [
        { "name": "p_product_id",  "value": 1,  "direction": "Input" },
        { "name": "p_quantity",    "value": 10, "direction": "Input" },
        { "name": "p_new_stock",   "value": 0,  "direction": "Output" }
      ]
    }
    """);

// ─────────────────────────────────────────────────────────────────────────────
// GROUP G: AUDIT TRAIL (optional extension table)
// ─────────────────────────────────────────────────────────────────────────────

var auditGroup = app.MapGroup("/api/audit")
    .WithTags("G — Audit Trail (de_transaction_audit)");

auditGroup.MapGet("/", async (IDemoDataEngine engine, int page = 1, int pageSize = 20) =>
{
    var entries = await engine.GetAuditLogAsync(page, pageSize);
    return Results.Ok(new
    {
        description = "All audit entries from de_transaction_audit. " +
                      "DataEngine writes here on every INSERT/UPDATE/DELETE when EnableAudit=true.",
        entries
    });
})
.WithName("GetAuditLog")
.WithSummary("Browse audit trail")
.WithDescription("Reads from de_transaction_audit — auto-created by DataEngine startup.");

// ─────────────────────────────────────────────────────────────────────────────
// GROUP H: FIELD MAPPINGS (optional extension table)
// ─────────────────────────────────────────────────────────────────────────────

var mappingGroup = app.MapGroup("/api/field-mappings")
    .WithTags("H — Field Mappings (de_field_mappings)");

mappingGroup.MapGet("/", async (IDemoDataEngine engine) =>
{
    var mappings = await engine.GetFieldMappingsAsync();
    return Results.Ok(new
    {
        description = "Field alias mappings from de_field_mappings. " +
                      "DataEngine uses these to translate API aliases to real DB column names.",
        mappings
    });
})
.WithName("GetFieldMappings")
.WithSummary("List all field alias mappings");

mappingGroup.MapPost("/", async (IDemoDataEngine engine, [FromBody] AddFieldMappingRequest req) =>
{
    await engine.AddFieldMappingAsync(req);
    return Results.Created("/api/field-mappings", new
    {
        message  = "Mapping added. DataEngine will use this alias in future requests.",
        mapping  = req
    });
})
.WithName("AddFieldMapping")
.WithSummary("Add a field alias mapping")
.WithDescription("""
    Sample — map API alias 'productName' to DB column 'name' in products table:
    {
      "tableName":  "products",
      "columnName": "name",
      "alias":      "productName",
      "direction":  "both"
    }
    """);

// ─────────────────────────────────────────────────────────────────────────────
// GROUP I: SAVED QUERY DEFINITIONS (optional extension table)
// ─────────────────────────────────────────────────────────────────────────────

var queryDefGroup = app.MapGroup("/api/query-definitions")
    .WithTags("I — Saved Query Definitions (de_query_definitions)");

queryDefGroup.MapGet("/", async (IDemoDataEngine engine) =>
{
    var defs = await engine.GetQueryDefinitionsAsync();
    return Results.Ok(new
    {
        description = "Saved query definitions from de_query_definitions. " +
                      "Call engine.QueryByDefinitionAsync('key') to execute by name.",
        definitions = defs
    });
})
.WithName("GetQueryDefinitions")
.WithSummary("List all saved query definitions");

queryDefGroup.MapPost("/", async (IDemoDataEngine engine, [FromBody] AddQueryDefinitionRequest req) =>
{
    await engine.AddQueryDefinitionAsync(req);
    return Results.Created("/api/query-definitions", new
    {
        message    = "Query definition saved. Use the definitionKey to run it.",
        definition = req
    });
})
.WithName("AddQueryDefinition")
.WithSummary("Save a named query definition")
.WithDescription("""
    Sample — save a reusable 'active-cylinders' query:
    {
      "definitionKey": "active-cylinders",
      "tableName": "products",
      "description": "All active cylinder products sorted by price",
      "queryJson": "{\"filters\":[{\"column\":\"category\",\"operator\":\"Equals\",\"value\":\"cylinders\"},{\"column\":\"is_active\",\"operator\":\"Equals\",\"value\":1}],\"sort\":[{\"column\":\"price\",\"direction\":\"Ascending\"}]}"
    }
    """);

queryDefGroup.MapPost("/{key}/execute", async (IDemoDataEngine engine, string key) =>
{
    var result = await engine.ExecuteByDefinitionAsync(key);
    return result is not null
        ? Results.Ok(new { definitionKey = key, result })
        : Results.NotFound(new { error = $"No active definition found for key '{key}'." });
})
.WithName("ExecuteByDefinitionKey")
.WithSummary("Execute a saved query by key")
.WithDescription("Runs the stored QueryRequest JSON against the live database.");

// ─────────────────────────────────────────────────────────────────────────────
// GROUP J: COMPLETE DEMO WALKTHROUGH
// ─────────────────────────────────────────────────────────────────────────────

var demoGroup = app.MapGroup("/api/demo")
    .WithTags("J — Complete Demo Walkthrough");

/// <summary>Run every DataEngine capability in sequence, return full results.</summary>
demoGroup.MapGet("/run-all", async (IDemoDataEngine engine) =>
{
    var steps = new List<object>();

    // Step 1: Schema discovery
    var tables = await engine.ListTablesAsync();
    steps.Add(new
    {
        step = 1,
        name = "Schema Discovery",
        description = "DataEngine reads INFORMATION_SCHEMA on startup and caches all table/column metadata.",
        result = new { tablesFound = tables.Count, tables }
    });

    // Step 2: Dynamic query — all products
    var allProducts = await engine.QueryAsync("products", new QueryRequest
    {
        Sort = [new SortInfo { Column = "price", Direction = "Ascending" }],
        Pagination = new PaginationInfo { Page = 1, PageSize = 5 },
        IncludeCount = true
    });
    steps.Add(new
    {
        step = 2,
        name = "Dynamic Query",
        description = "SELECT with sort + pagination. No entity class needed.",
        result = allProducts
    });

    // Step 3: Filtered query
    var cylinders = await engine.QueryAsync("products", new QueryRequest
    {
        Filters = [new FilterInfo { Column = "category", Operator = "Equals", Value = JsonDocument.Parse("\"cylinders\"").RootElement }],
        Sort = [new SortInfo { Column = "price", Direction = "Descending" }]
    });
    steps.Add(new
    {
        step = 3,
        name = "Filtered Query",
        description = "WHERE category = 'cylinders' ORDER BY price DESC.",
        result = new { rowCount = cylinders.Data.Count, data = cylinders.Data }
    });

    // Step 4: Insert
    var sku = $"DEMO-{DateTime.UtcNow:mmssff}";
    var inserted = await engine.InsertAsync("products", new InsertRequest
    {
        Values = new Dictionary<string, object?>
        {
            ["sku"]      = sku,
            ["name"]     = "DataEngine Demo Product",
            ["price"]    = 999.00m,
            ["stock"]    = 50,
            ["category"] = "demo",
            ["is_active"] = 1
        },
        ExecutedBy = "demo-walkthrough"
    });
    steps.Add(new
    {
        step = 4,
        name = "Dynamic INSERT",
        description = "Row inserted. Auto-increment PK returned automatically.",
        result = inserted
    });

    // Step 5: Update
    var updated = await engine.UpdateAsync("products", new UpdateRequest
    {
        Values = new Dictionary<string, object?> { ["price"] = 1299.00m, ["stock"] = 45 },
        Filters = [new FilterInfo { Column = "sku", Operator = "Equals", Value = JsonDocument.Parse($"\"{sku}\"").RootElement }],
        ExecutedBy = "demo-walkthrough"
    });
    steps.Add(new
    {
        step = 5,
        name = "Dynamic UPDATE",
        description = "Price and stock updated. Filters are mandatory — no blind updates allowed.",
        result = updated
    });

    // Step 6: Transaction
    var txResult = await engine.ExecuteTransactionAsync(new TransactionRequest
    {
        Operations =
        [
            new TxOperation
            {
                Order = 1, Type = "Insert", Table = "orders",
                Values = new Dictionary<string, object?>
                {
                    ["product_id"] = inserted.InsertedId,
                    ["quantity"] = 3,
                    ["status"] = "pending",
                    ["customer_name"] = "Demo Customer",
                    ["total_amount"] = 3897.00m
                }
            },
            new TxOperation
            {
                Order = 2, Type = "Update", Table = "products",
                Values = new Dictionary<string, object?> { ["stock"] = 42 },
                Filters = [new FilterInfo { Column = "id", Operator = "Equals", Value = JsonDocument.Parse($"{inserted.InsertedId}").RootElement }]
            }
        ],
        ExecutedBy = "demo-walkthrough",
        CorrelationId = Guid.NewGuid().ToString("N")[..16]
    });
    steps.Add(new
    {
        step = 6,
        name = "Multi-Operation Transaction",
        description = "INSERT order + UPDATE stock as one atomic operation. All commit or all roll back.",
        result = txResult
    });

    // Step 7: Bulk insert
    var bulkRows = Enumerable.Range(1, 5).Select(i =>
        new Dictionary<string, object?>
        {
            ["sku"]      = $"BULK-{DateTime.UtcNow:mmssff}-{i}",
            ["name"]     = $"Bulk Product {i}",
            ["price"]    = 100m * i,
            ["stock"]    = i * 20,
            ["category"] = "bulk-demo",
            ["is_active"] = 1
        }).Cast<IDictionary<string, object?>>().ToList();

    var bulkResult = await engine.BulkInsertAsync("products", new BulkInsertRequest
    {
        Rows = bulkRows.Select(r => (IReadOnlyDictionary<string, object?>)
            new Dictionary<string, object?>(r)).ToList().AsReadOnly(),
        BatchSize = 500,
        OnConflict = "Ignore"
    });
    steps.Add(new
    {
        step = 7,
        name = "Bulk INSERT",
        description = "5 rows inserted in a single batch. Supports up to 500 rows/batch by default.",
        result = bulkResult
    });

    // Step 8: Audit log
    var audit = await engine.GetAuditLogAsync(1, 5);
    steps.Add(new
    {
        step = 8,
        name = "Audit Trail",
        description = "de_transaction_audit records every write operation when EnableAudit=true.",
        result = new { recentEntries = audit.Count, entries = audit }
    });

    // Step 9: Delete demo data
    var deleted = await engine.DeleteAsync("products", new DeleteRequest
    {
        Filters = [new FilterInfo { Column = "category", Operator = "Equals", Value = JsonDocument.Parse("\"demo\"").RootElement }],
        ExecutedBy = "demo-walkthrough"
    });
    steps.Add(new
    {
        step = 9,
        name = "Dynamic DELETE",
        description = "Cleaned up demo products. Filters are mandatory — no blind deletes allowed.",
        result = deleted
    });

    return Results.Ok(new
    {
        title   = "DataEngine — Complete Capability Walkthrough",
        message = "All 9 steps executed successfully against a live MySQL database.",
        totalSteps = steps.Count,
        steps
    });
})
.WithName("RunAllDemo")
.WithSummary("Run every DataEngine capability in one shot")
.WithDescription("Executes all 9 steps: schema discovery, query, filter, insert, update, transaction, bulk insert, audit, delete.");

// DB info endpoint: returns provider and all configured connection-string values
app.MapGet("/api/db-info", (IConfiguration config) =>
{
    var provider = "MySqlConnector";
    var connectionStrings = config.GetSection("ConnectionStrings").GetChildren()
        .ToDictionary(
            section => section.Key!,
            section => FixConnectionString(section.Value));

    return Results.Ok(new
    {
        provider,
        connections = connectionStrings
    });
});

app.MapGet("/api/settings", (IConfiguration config) =>
{
    var dataEngineSettings = config.GetSection("DataEngine").GetChildren()
        .ToDictionary(section => section.Key!, section => section.Value ?? string.Empty);

    return Results.Ok(new
    {
        environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Production",
        dataEngine = dataEngineSettings
    });
});

app.MapPost("/api/connections/test", async (IConfiguration config, ConnectionTestRequest req) =>
{
    var connections = config.GetSection("ConnectionStrings").GetChildren()
        .ToDictionary(section => section.Key!, section => section.Value ?? string.Empty);

    if (!connections.TryGetValue(req.ConnectionName, out var rawCs) || string.IsNullOrWhiteSpace(rawCs))
    {
        return Results.NotFound(new { success = false, error = $"Connection '{req.ConnectionName}' not found." });
    }

    var fixedCs = FixConnectionString(rawCs);
    try
    {
        await using var conn = new MySqlConnection(fixedCs);
        await conn.OpenAsync();
        return Results.Ok(new { success = true, message = $"Connection '{req.ConnectionName}' succeeded." });
    }
    catch (Exception ex)
    {
        return Results.BadRequest(new { success = false, error = ex.Message });
    }
});

app.Run();

public sealed record ConnectionTestRequest(string ConnectionName);

// =============================================================================
//
//  AUTO-TABLE CREATION
//
// =============================================================================

static async Task AutoCreateDatabaseAndTablesAsync(string connectionString, ILogger logger)
{
    try
    {
        // Step 1: Connect without a database to CREATE DATABASE IF NOT EXISTS
        var builder = new MySqlConnectionStringBuilder(connectionString);
        var dbName  = builder.Database;
        builder.Database = string.Empty;   // connect to server root

        await using var rootConn = new MySqlConnection(builder.ConnectionString);
        await rootConn.OpenAsync();

        await using (var cmd = rootConn.CreateCommand())
        {
            cmd.CommandText = $"CREATE DATABASE IF NOT EXISTS `{dbName}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;";
            await cmd.ExecuteNonQueryAsync();
        }

        logger.LogInformation("✅ Database '{Db}' ready.", dbName);

        // Step 2: Connect to the actual database
        await using var conn = new MySqlConnection(connectionString);
        await conn.OpenAsync();

        // All CREATE TABLE IF NOT EXISTS — idempotent on every boot
        var scripts = new (string Name, string Sql)[]
        {
            // ── Demo tables ────────────────────────────────────────────
            ("products", """
                CREATE TABLE IF NOT EXISTS `products` (
                    `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    `sku`        VARCHAR(50)     NOT NULL UNIQUE,
                    `name`       VARCHAR(200)    NOT NULL,
                    `price`      DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
                    `stock`      INT             NOT NULL DEFAULT 0,
                    `category`   VARCHAR(100),
                    `is_active`  TINYINT(1)      NOT NULL DEFAULT 1,
                    `created_at` DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    `updated_at` DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
                """),

            ("orders", """
                CREATE TABLE IF NOT EXISTS `orders` (
                    `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    `product_id`    INT UNSIGNED    NOT NULL,
                    `quantity`      INT             NOT NULL,
                    `status`        VARCHAR(50)     NOT NULL DEFAULT 'pending',
                    `customer_name` VARCHAR(200),
                    `total_amount`  DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
                    `ordered_at`    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
                """),

            // ── DataEngine optional extension tables ───────────────────
            ("de_field_mappings", """
                CREATE TABLE IF NOT EXISTS `de_field_mappings` (
                    `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    `table_name`  VARCHAR(128)  NOT NULL,
                    `column_name` VARCHAR(128)  NOT NULL,
                    `alias`       VARCHAR(128)  NOT NULL,
                    `direction`   ENUM('in','out','both') NOT NULL DEFAULT 'both',
                    `created_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE KEY `uq_mapping` (`table_name`, `alias`, `direction`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
                """),

            ("de_query_definitions", """
                CREATE TABLE IF NOT EXISTS `de_query_definitions` (
                    `id`             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    `definition_key` VARCHAR(128)  NOT NULL UNIQUE,
                    `table_name`     VARCHAR(128)  NOT NULL,
                    `description`    TEXT,
                    `query_json`     JSON          NOT NULL,
                    `is_active`      TINYINT(1)    NOT NULL DEFAULT 1,
                    `created_at`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    `updated_at`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
                """),

            ("de_transaction_audit", """
                CREATE TABLE IF NOT EXISTS `de_transaction_audit` (
                    `id`             BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    `operation`      ENUM('INSERT','UPDATE','DELETE') NOT NULL,
                    `table_name`     VARCHAR(128)  NOT NULL,
                    `database_name`  VARCHAR(128)  NOT NULL,
                    `record_id`      VARCHAR(255),
                    `old_values`     JSON,
                    `new_values`     JSON,
                    `executed_by`    VARCHAR(255),
                    `executed_at`    DATETIME(6)   NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                    `correlation_id` VARCHAR(64),
                    INDEX `idx_table_op`    (`table_name`, `operation`),
                    INDEX `idx_executed_at` (`executed_at`),
                    INDEX `idx_correlation` (`correlation_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
                """)
        };

        foreach (var (name, sql) in scripts)
        {
            await using var cmd = conn.CreateCommand();
            cmd.CommandText = sql;
            await cmd.ExecuteNonQueryAsync();
            logger.LogInformation("  ✅ Table '{Table}' ready.", name);
        }

        // Ensure expected audit columns exist (handle older schemas)
        await using var colCheck = conn.CreateCommand();
        colCheck.CommandText = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS " +
                               "WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'de_transaction_audit' " +
                               "AND COLUMN_NAME = 'operation';";
        var opCount = Convert.ToInt32(await colCheck.ExecuteScalarAsync());
        if (opCount == 0)
        {
            await using var alterCmd = conn.CreateCommand();
            alterCmd.CommandText = "ALTER TABLE `de_transaction_audit` " +
                                    "ADD COLUMN `operation` ENUM('INSERT','UPDATE','DELETE') NOT NULL AFTER `id`;";
            await alterCmd.ExecuteNonQueryAsync();
            logger.LogInformation("  ✅ Added missing column 'operation' to 'de_transaction_audit'.");
        }

        // Ensure other audit columns and indexes exist (handle older schemas)
        var extras = new Dictionary<string, string>
        {
            { "database_name", "ALTER TABLE `de_transaction_audit` ADD COLUMN `database_name` VARCHAR(128) NOT NULL AFTER `table_name`;" },
            { "old_values",     "ALTER TABLE `de_transaction_audit` ADD COLUMN `old_values` JSON NULL AFTER `record_id`;" },
            { "new_values",     "ALTER TABLE `de_transaction_audit` ADD COLUMN `new_values` JSON NULL AFTER `old_values`;" },
            { "executed_by",    "ALTER TABLE `de_transaction_audit` ADD COLUMN `executed_by` VARCHAR(255) NULL AFTER `new_values`;" },
            { "executed_at",    "ALTER TABLE `de_transaction_audit` ADD COLUMN `executed_at` DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) AFTER `executed_by`;" },
            { "correlation_id", "ALTER TABLE `de_transaction_audit` ADD COLUMN `correlation_id` VARCHAR(64) NULL AFTER `executed_at`;" }
        };

        foreach (var kv in extras)
        {
            await using var c = conn.CreateCommand();
            c.CommandText = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'de_transaction_audit' AND COLUMN_NAME = '" + kv.Key + "';";
            var exists = Convert.ToInt32(await c.ExecuteScalarAsync());
            if (exists == 0)
            {
                await using var a = conn.CreateCommand();
                a.CommandText = kv.Value;
                await a.ExecuteNonQueryAsync();
                logger.LogInformation("  ✅ Added missing column '{Col}' to 'de_transaction_audit'.", kv.Key);
            }
        }

        // Ensure indexes
        var indexes = new Dictionary<string, string>
        {
            { "idx_table_op",    "CREATE INDEX `idx_table_op` ON `de_transaction_audit` (`table_name`, `operation`);" },
            { "idx_executed_at", "CREATE INDEX `idx_executed_at` ON `de_transaction_audit` (`executed_at`);" },
            { "idx_correlation", "CREATE INDEX `idx_correlation` ON `de_transaction_audit` (`correlation_id`);" }
        };

        foreach (var kv in indexes)
        {
            await using var c = conn.CreateCommand();
            c.CommandText = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'de_transaction_audit' AND INDEX_NAME = '" + kv.Key + "';";
            var exists = Convert.ToInt32(await c.ExecuteScalarAsync());
            if (exists == 0)
            {
                await using var a = conn.CreateCommand();
                a.CommandText = kv.Value;
                await a.ExecuteNonQueryAsync();
                logger.LogInformation("  ✅ Created missing index '{Idx}' on 'de_transaction_audit'.", kv.Key);
            }
        }

        // Ensure de_query_definitions has expected columns (older DBs may be missing them)
        var qExtras = new Dictionary<string, string>
        {
            { "definition_key", "ALTER TABLE `de_query_definitions` ADD COLUMN `definition_key` VARCHAR(128) NOT NULL AFTER `id`;" },
            { "table_name",      "ALTER TABLE `de_query_definitions` ADD COLUMN `table_name` VARCHAR(128) NOT NULL AFTER `definition_key`;" },
            { "description",     "ALTER TABLE `de_query_definitions` ADD COLUMN `description` TEXT NULL AFTER `table_name`;" },
            { "query_json",      "ALTER TABLE `de_query_definitions` ADD COLUMN `query_json` JSON NOT NULL AFTER `description`;" },
            { "is_active",       "ALTER TABLE `de_query_definitions` ADD COLUMN `is_active` TINYINT(1) NOT NULL DEFAULT 1 AFTER `query_json`;" },
            { "created_at",      "ALTER TABLE `de_query_definitions` ADD COLUMN `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `is_active`;" },
            { "updated_at",      "ALTER TABLE `de_query_definitions` ADD COLUMN `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER `created_at`;" }
        };

        foreach (var kv in qExtras)
        {
            await using var c = conn.CreateCommand();
            c.CommandText = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'de_query_definitions' AND COLUMN_NAME = '" + kv.Key + "';";
            var exists = Convert.ToInt32(await c.ExecuteScalarAsync());
            if (exists == 0)
            {
                await using var a = conn.CreateCommand();
                a.CommandText = kv.Value;
                await a.ExecuteNonQueryAsync();
                logger.LogInformation("  ✅ Added missing column '{Col}' to 'de_query_definitions'.", kv.Key);
            }
        }

        // Step 3: Seed demo data if products table is empty
        await using var checkCmd = conn.CreateCommand();
        checkCmd.CommandText = "SELECT COUNT(*) FROM `products`;";
        var count = Convert.ToInt32(await checkCmd.ExecuteScalarAsync());

        if (count == 0)
        {
            await using var seedCmd = conn.CreateCommand();
            seedCmd.CommandText = """
                INSERT INTO `products` (`sku`, `name`, `price`, `stock`, `category`, `is_active`) VALUES
                    ('CYL-032', 'Pneumatic Cylinder 32mm',  1200.00, 100, 'cylinders', 1),
                    ('CYL-050', 'Pneumatic Cylinder 50mm',  1850.00, 80,  'cylinders', 1),
                    ('CYL-080', 'Pneumatic Cylinder 80mm',  2800.00, 40,  'cylinders', 1),
                    ('VLV-010', 'Solenoid Valve 1/4 inch',   750.00, 200, 'valves',    1),
                    ('VLV-020', 'Solenoid Valve 1/2 inch',  1050.00, 150, 'valves',    1),
                    ('FLT-005', 'Air Filter 5 micron',       380.00, 300, 'filters',   1),
                    ('FLT-025', 'Air Filter 25 micron',      290.00, 350, 'filters',   1),
                    ('REG-001', 'Pressure Regulator 10 bar', 920.00, 120, 'regulators',1);
                """;
            await seedCmd.ExecuteNonQueryAsync();
            logger.LogInformation("  ✅ Seeded 8 demo products.");

            // Seed one stored procedure for the procedure demo
            await using var dropSp = conn.CreateCommand();
            dropSp.CommandText = "DROP PROCEDURE IF EXISTS `sp_get_products_by_category`;";
            await dropSp.ExecuteNonQueryAsync();

            await using var spCmd = conn.CreateCommand();
            spCmd.CommandText = """
                CREATE PROCEDURE `sp_get_products_by_category`(IN p_category VARCHAR(100))
                BEGIN
                    SELECT `id`, `sku`, `name`, `price`, `stock`
                    FROM `products`
                    WHERE `category` = p_category AND `is_active` = 1
                    ORDER BY `price` ASC;
                END
                """;
            await spCmd.ExecuteNonQueryAsync();
            logger.LogInformation("  ✅ Stored procedure 'sp_get_products_by_category' ready.");
        }

        logger.LogInformation("🚀 DataEngine database initialization complete.");
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "❌ Database initialization failed. " +
            "Check your connection string in appsettings.json.");
        throw;
    }
}

// =============================================================================
//
//  DEMO DATA ENGINE  (mirrors the real DataEngine API exactly)
//  Replace with: builder.Services.AddDataEngine(config) when the NuGet is ready
//
// =============================================================================

public interface IDemoDataEngine
{
    Task<List<string>> ListTablesAsync();
    Task<TableSchemaInfo?> GetTableSchemaAsync(string tableName);
    Task InvalidateSchemaCacheAsync();
    Task<QueryResult> QueryAsync(string tableName, QueryRequest request);
    Task<MutationResult> InsertAsync(string tableName, InsertRequest request);
    Task<MutationResult> UpdateAsync(string tableName, UpdateRequest request);
    Task<MutationResult> DeleteAsync(string tableName, DeleteRequest request);
    Task<BulkResult> BulkInsertAsync(string tableName, BulkInsertRequest request);
    Task<TxResult> ExecuteTransactionAsync(TransactionRequest request);
    Task<ProcedureResult> ExecuteProcedureAsync(ProcedureRequest request);
    Task<List<Dictionary<string, object?>>> GetAuditLogAsync(int page, int pageSize);
    Task<List<Dictionary<string, object?>>> GetFieldMappingsAsync();
    Task AddFieldMappingAsync(AddFieldMappingRequest req);
    Task<List<Dictionary<string, object?>>> GetQueryDefinitionsAsync();
    Task AddQueryDefinitionAsync(AddQueryDefinitionRequest req);
    Task<QueryResult?> ExecuteByDefinitionAsync(string key);
}

public sealed class DemoDataEngine : IDemoDataEngine
{
    private readonly string _defaultCs;
    private readonly string _reportingCs;
    private readonly ILogger<DemoDataEngine> _logger;

    // Simple in-memory schema cache
    private Dictionary<string, List<ColumnDef>>? _schemaCache;
    private readonly SemaphoreSlim _cacheLock = new(1, 1);

    public DemoDataEngine(string defaultCs, string reportingCs, ILogger<DemoDataEngine> logger)
    {
        _defaultCs   = defaultCs;
        _reportingCs = reportingCs;
        _logger      = logger;
    }

    // ── Schema ────────────────────────────────────────────────────────

    public async Task<List<string>> ListTablesAsync()
    {
        var cache = await GetCacheAsync();
        return cache.Keys.OrderBy(k => k).ToList();
    }

    public async Task<TableSchemaInfo?> GetTableSchemaAsync(string tableName)
    {
        var cache = await GetCacheAsync();
        if (!cache.TryGetValue(tableName.ToLower(), out var cols)) return null;

        return new TableSchemaInfo
        {
            TableName   = tableName,
            Columns     = cols,
            PrimaryKeys = cols.Where(c => c.IsPrimaryKey).Select(c => c.ColumnName).ToList()
        };
    }

    public async Task InvalidateSchemaCacheAsync()
    {
        await _cacheLock.WaitAsync();
        try { _schemaCache = null; }
        finally { _cacheLock.Release(); }
        await GetCacheAsync(); // reload immediately
    }

    private async Task<Dictionary<string, List<ColumnDef>>> GetCacheAsync()
    {
        if (_schemaCache is not null) return _schemaCache;

        await _cacheLock.WaitAsync();
        try
        {
            if (_schemaCache is not null) return _schemaCache;

            await using var conn = new MySqlConnection(_defaultCs);
            await conn.OpenAsync();

            // Exclude DataEngine system tables from public listing
            var rows = await conn.QueryAsync<dynamic>("""
                SELECT
                    c.TABLE_NAME         AS TableName,
                    c.COLUMN_NAME        AS ColumnName,
                    c.DATA_TYPE          AS DataType,
                    c.IS_NULLABLE        AS IsNullable,
                    c.CHARACTER_MAXIMUM_LENGTH AS MaxLength,
                    c.COLUMN_DEFAULT     AS DefaultValue,
                    c.ORDINAL_POSITION   AS OrdinalPosition,
                    CASE WHEN c.EXTRA LIKE '%auto_increment%' THEN 1 ELSE 0 END AS IsAutoIncrement,
                    CASE WHEN k.COLUMN_NAME IS NOT NULL THEN 1 ELSE 0 END AS IsPrimaryKey
                FROM INFORMATION_SCHEMA.COLUMNS c
                LEFT JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE k
                    ON  k.TABLE_SCHEMA = c.TABLE_SCHEMA
                    AND k.TABLE_NAME   = c.TABLE_NAME
                    AND k.COLUMN_NAME  = c.COLUMN_NAME
                    AND k.CONSTRAINT_NAME = 'PRIMARY'
                WHERE c.TABLE_SCHEMA = DATABASE()
                ORDER BY c.TABLE_NAME, c.ORDINAL_POSITION;
                """);

            _schemaCache = rows
                .GroupBy(r => ((string)r.TableName).ToLower())
                .ToDictionary(
                    g => g.Key,
                    g => g.Select(r => new ColumnDef
                    {
                        ColumnName      = (string)r.ColumnName,
                        DataType        = (string)r.DataType,
                        IsNullable      = (string)r.IsNullable == "YES",
                        MaxLength       = r.MaxLength is null ? (int?)null : Convert.ToInt32(r.MaxLength),
                        DefaultValue    = r.DefaultValue,
                        OrdinalPosition = Convert.ToInt32(r.OrdinalPosition),
                        IsAutoIncrement = Convert.ToBoolean(r.IsAutoIncrement),
                        IsPrimaryKey    = Convert.ToBoolean(r.IsPrimaryKey)
                    }).ToList());

            _logger.LogInformation("Schema cache loaded: {Count} tables.", _schemaCache.Count);
            return _schemaCache;
        }
        finally { _cacheLock.Release(); }
    }

    private async Task<List<ColumnDef>> GetColumnsAsync(string tableName)
    {
        var cache = await GetCacheAsync();
        if (!cache.TryGetValue(tableName.ToLower(), out var cols))
            throw new InvalidOperationException(
                $"Table '{tableName}' not found in schema cache. " +
                $"Known tables: {string.Join(", ", cache.Keys)}");
        return cols;
    }

    // ── Query ─────────────────────────────────────────────────────────

    public async Task<QueryResult> QueryAsync(string tableName, QueryRequest req)
    {
        var sw = System.Diagnostics.Stopwatch.StartNew();
        var cols = await GetColumnsAsync(tableName);

        var sb = new System.Text.StringBuilder();
        var parameters = new Dictionary<string, object?>();

        // SELECT
        if (req.Columns?.Count > 0)
        {
            ValidateColumns(req.Columns, cols, tableName);
            sb.Append($"SELECT {string.Join(", ", req.Columns.Select(c => $"`{c}`"))}");
        }
        else
        {
            sb.Append($"SELECT {string.Join(", ", cols.Select(c => $"`{c.ColumnName}`"))}");
        }

        sb.Append($" FROM `{tableName}`");

        // WHERE
        AppendFilters(sb, req.Filters, cols, tableName, parameters);

        // ORDER BY
        if (req.Sort?.Count > 0)
        {
            ValidateColumns(req.Sort.Select(s => s.Column).ToList(), cols, tableName);
            sb.Append(" ORDER BY " + string.Join(", ",
                req.Sort.Select(s => $"`{s.Column}` {(s.Direction == "Descending" ? "DESC" : "ASC")}")));
        }

        // LIMIT / OFFSET
        int page = req.Pagination?.Page ?? 1;
        int pageSize = req.Pagination?.PageSize ?? 20;
        sb.Append(" LIMIT @_limit OFFSET @_offset");
        parameters["_limit"]  = pageSize;
        parameters["_offset"] = (page - 1) * pageSize;

        await using var conn = new MySqlConnection(_defaultCs);
        await conn.OpenAsync();

        var rows = (await conn.QueryAsync(sb.ToString(), parameters))
            .Select(r => (IDictionary<string, object>)r)
            .Select(r => r.ToDictionary(k => k.Key, k => (object?)k.Value))
            .ToList();

        long? totalCount = null;
        if (req.IncludeCount)
        {
            var countSql = $"SELECT COUNT(*) FROM `{tableName}`";
            var countParams = new Dictionary<string, object?>(parameters);
            countParams.Remove("_limit"); countParams.Remove("_offset");

            var filterSb = new System.Text.StringBuilder();
            AppendFilters(filterSb, req.Filters, cols, tableName, countParams, isCount: true);
            totalCount = await conn.ExecuteScalarAsync<long>(countSql + filterSb, countParams);
        }

        sw.Stop();
        return new QueryResult
        {
            Data          = rows,
            TotalCount    = totalCount,
            Page          = page,
            PageSize      = pageSize,
            ExecutionTime = $"{sw.ElapsedMilliseconds}ms"
        };
    }

    // ── Insert ────────────────────────────────────────────────────────

    public async Task<MutationResult> InsertAsync(string tableName, InsertRequest req)
    {
        var sw = System.Diagnostics.Stopwatch.StartNew();
        var cols = await GetColumnsAsync(tableName);

        var writableValues = req.Values
            .Where(kv => cols.Any(c =>
                c.ColumnName.Equals(kv.Key, StringComparison.OrdinalIgnoreCase) &&
                !c.IsAutoIncrement))
            .ToList();

        if (writableValues.Count == 0)
            return MutationResult.Fail("No writable columns found in request.");

        var colList   = string.Join(", ", writableValues.Select(kv => $"`{kv.Key}`"));
        var paramList = string.Join(", ", writableValues.Select((_, i) => $"@p{i}"));
        var sql       = $"INSERT INTO `{tableName}` ({colList}) VALUES ({paramList}); SELECT LAST_INSERT_ID();";

        var p = new Dictionary<string, object?>();
        for (int i = 0; i < writableValues.Count; i++)
            p[$"p{i}"] = writableValues[i].Value;

        await using var conn = new MySqlConnection(_defaultCs);
        await conn.OpenAsync();
        await using var cmd = conn.CreateCommand();
        cmd.CommandText = sql;
        foreach (var (name, val) in p)
        {
            var mp = cmd.CreateParameter();
            mp.ParameterName = $"@{name}";
            mp.Value = val ?? DBNull.Value;
            cmd.Parameters.Add(mp);
        }

        long insertedId = 0;
        await using var reader = await cmd.ExecuteReaderAsync();
        int affected = reader.RecordsAffected;
        if (await reader.ReadAsync()) insertedId = reader.GetInt64(0);

        // Write audit
        await WriteAuditAsync("INSERT", tableName, insertedId.ToString(),
            null, JsonSerializer.Serialize(req.Values), req.ExecutedBy, req.CorrelationId);

        sw.Stop();
        return new MutationResult
        {
            Success       = true,
            AffectedRows  = affected > 0 ? affected : 1,
            InsertedId    = insertedId,
            ExecutionTime = $"{sw.ElapsedMilliseconds}ms"
        };
    }

    // ── Update ────────────────────────────────────────────────────────

    public async Task<MutationResult> UpdateAsync(string tableName, UpdateRequest req)
    {
        if (req.Filters is null || req.Filters.Count == 0)
            return MutationResult.Fail("UPDATE requires at least one filter. Blind updates are not permitted.");

        var sw   = System.Diagnostics.Stopwatch.StartNew();
        var cols = await GetColumnsAsync(tableName);
        var p    = new Dictionary<string, object?>();
        var sets = new List<string>();
        int i    = 0;

        foreach (var (key, val) in req.Values)
        {
            ValidateColumns([key], cols, tableName);
            p[$"s{i}"] = val;
            sets.Add($"`{key}` = @s{i}");
            i++;
        }

        var sb = new System.Text.StringBuilder($"UPDATE `{tableName}` SET {string.Join(", ", sets)}");
        AppendFilters(sb, req.Filters, cols, tableName, p);

        await using var conn = new MySqlConnection(_defaultCs);
        await conn.OpenAsync();
        int affected = await conn.ExecuteAsync(sb.ToString(), p);

        await WriteAuditAsync("UPDATE", tableName, null,
            null, JsonSerializer.Serialize(req.Values), req.ExecutedBy, req.CorrelationId);

        sw.Stop();
        return new MutationResult { Success = true, AffectedRows = affected, ExecutionTime = $"{sw.ElapsedMilliseconds}ms" };
    }

    // ── Delete ────────────────────────────────────────────────────────

    public async Task<MutationResult> DeleteAsync(string tableName, DeleteRequest req)
    {
        if (req.Filters is null || req.Filters.Count == 0)
            return MutationResult.Fail("DELETE requires at least one filter. Blind deletes are not permitted.");

        var sw   = System.Diagnostics.Stopwatch.StartNew();
        var cols = await GetColumnsAsync(tableName);
        var p    = new Dictionary<string, object?>();
        var sb   = new System.Text.StringBuilder($"DELETE FROM `{tableName}`");
        AppendFilters(sb, req.Filters, cols, tableName, p);

        await using var conn = new MySqlConnection(_defaultCs);
        await conn.OpenAsync();
        int affected = await conn.ExecuteAsync(sb.ToString(), p);

        await WriteAuditAsync("DELETE", tableName, null, null, null, req.ExecutedBy, req.CorrelationId);

        sw.Stop();
        return new MutationResult { Success = true, AffectedRows = affected, ExecutionTime = $"{sw.ElapsedMilliseconds}ms" };
    }

    // ── Bulk Insert ───────────────────────────────────────────────────

    public async Task<BulkResult> BulkInsertAsync(string tableName, BulkInsertRequest req)
    {
        if (req.Rows.Count == 0)
            return new BulkResult { Success = true, TotalAffectedRows = 0 };

        var sw   = System.Diagnostics.Stopwatch.StartNew();
        var cols = await GetColumnsAsync(tableName);
        int totalAffected = 0;
        int batchSize = req.BatchSize > 0 ? req.BatchSize : 500;
        int batches = (int)Math.Ceiling(req.Rows.Count / (double)batchSize);

        for (int b = 0; b < batches; b++)
        {
            var batch = req.Rows.Skip(b * batchSize).Take(batchSize).ToList();
            var firstRow = batch[0];
            var writableCols = firstRow.Keys
                .Where(k => cols.Any(c =>
                    c.ColumnName.Equals(k, StringComparison.OrdinalIgnoreCase) &&
                    !c.IsAutoIncrement))
                .ToList();

            var colList = string.Join(", ", writableCols.Select(c => $"`{c}`"));
            var p       = new Dictionary<string, object?>();
            var valSets = new List<string>();

            for (int r = 0; r < batch.Count; r++)
            {
                var pNames = writableCols.Select((c, ci) =>
                {
                    p[$"r{r}c{ci}"] = batch[r].TryGetValue(c, out var v) ? v : null;
                    return $"@r{r}c{ci}";
                });
                valSets.Add($"({string.Join(", ", pNames)})");
            }

            var verb = req.OnConflict == "Ignore" ? "INSERT IGNORE" :
                       req.OnConflict == "Replace" ? "REPLACE" : "INSERT";
            var sql  = $"{verb} INTO `{tableName}` ({colList}) VALUES {string.Join(", ", valSets)};";

            await using var conn = new MySqlConnection(_defaultCs);
            await conn.OpenAsync();
            totalAffected += await conn.ExecuteAsync(sql, p);
        }

        sw.Stop();
        return new BulkResult
        {
            Success           = true,
            TotalAffectedRows = totalAffected,
            BatchesExecuted   = batches,
            TotalBatches      = batches,
            ExecutionTime     = $"{sw.ElapsedMilliseconds}ms"
        };
    }

    // ── Transaction ───────────────────────────────────────────────────

    public async Task<TxResult> ExecuteTransactionAsync(TransactionRequest req)
    {
        var sw  = System.Diagnostics.Stopwatch.StartNew();
        var ops = req.Operations.OrderBy(o => o.Order).ToList();

        await using var conn = new MySqlConnection(_defaultCs);
        await conn.OpenAsync();
        await using var txn = await conn.BeginTransactionAsync();

        try
        {
            int opsDone = 0;
            foreach (var op in ops)
            {
                var cols = await GetColumnsAsync(op.Table);
                string sql;
                var p = new Dictionary<string, object?>();

                if (op.Type == "Insert" && op.Values is not null)
                {
                    var writables = op.Values
                        .Where(kv => cols.Any(c =>
                            c.ColumnName.Equals(kv.Key, StringComparison.OrdinalIgnoreCase) &&
                            !c.IsAutoIncrement))
                        .ToList();
                    var colList = string.Join(", ", writables.Select(kv => $"`{kv.Key}`"));
                    var paramList = string.Join(", ", writables.Select((_, i) => $"@p{i}"));
                    for (int i = 0; i < writables.Count; i++) p[$"p{i}"] = writables[i].Value;
                    sql = $"INSERT INTO `{op.Table}` ({colList}) VALUES ({paramList})";
                }
                else if (op.Type == "Update" && op.Values is not null && op.Filters?.Count > 0)
                {
                    var sets = op.Values.Select((kv, i) => { p[$"s{i}"] = kv.Value; return $"`{kv.Key}` = @s{i}"; });
                    var sb = new System.Text.StringBuilder($"UPDATE `{op.Table}` SET {string.Join(", ", sets)}");
                    AppendFilters(sb, op.Filters, cols, op.Table, p);
                    sql = sb.ToString();
                }
                else if (op.Type == "Delete" && op.Filters?.Count > 0)
                {
                    var sb = new System.Text.StringBuilder($"DELETE FROM `{op.Table}`");
                    AppendFilters(sb, op.Filters, cols, op.Table, p);
                    sql = sb.ToString();
                }
                else throw new InvalidOperationException($"Invalid op: type={op.Type} table={op.Table}");

                await conn.ExecuteAsync(sql, p, txn);
                opsDone++;
            }

            await txn.CommitAsync();
            sw.Stop();

            foreach (var op in ops)
                await WriteAuditAsync(op.Type.ToUpper(), op.Table, null,
                    null, op.Values is not null ? JsonSerializer.Serialize(op.Values) : null,
                    req.ExecutedBy, req.CorrelationId);

            return new TxResult { Success = true, OperationsExecuted = opsDone, ExecutionTime = $"{sw.ElapsedMilliseconds}ms" };
        }
        catch (Exception ex)
        {
            await txn.RollbackAsync();
            sw.Stop();
            _logger.LogError(ex, "Transaction rolled back.");
            return new TxResult { Success = false, Error = ex.Message, ExecutionTime = $"{sw.ElapsedMilliseconds}ms" };
        }
    }

    // ── Stored Procedure ──────────────────────────────────────────────

    public async Task<ProcedureResult> ExecuteProcedureAsync(ProcedureRequest req)
    {
        var sw = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await using var conn = new MySqlConnection(_defaultCs);
            await conn.OpenAsync();

            if (req.Type == "Read")
            {
                var dp = new DynamicParameters();
                foreach (var p in req.Parameters ?? [])
                    dp.Add(p.Name, p.Value);

                var rows = (await conn.QueryAsync(req.ProcedureName, dp,
                    commandType: CommandType.StoredProcedure))
                    .Select(r => (IDictionary<string, object>)r)
                    .Select(r => r.ToDictionary(k => k.Key, k => (object?)k.Value))
                    .ToList();

                sw.Stop();
                return new ProcedureResult
                {
                    Success       = true,
                    ResultSet     = rows,
                    ExecutionTime = $"{sw.ElapsedMilliseconds}ms"
                };
            }
            else
            {
                await using var cmd = conn.CreateCommand();
                cmd.CommandText = req.ProcedureName;
                cmd.CommandType = CommandType.StoredProcedure;
                var outputMap   = new Dictionary<string, MySqlParameter>();

                foreach (var p in req.Parameters ?? [])
                {
                    var mp = cmd.CreateParameter();
                    mp.ParameterName = p.Name;
                    mp.Value         = p.Value ?? DBNull.Value;
                    mp.Direction     = p.Direction == "Output"
                        ? ParameterDirection.Output
                        : ParameterDirection.Input;
                    cmd.Parameters.Add(mp);
                    if (p.Direction == "Output") outputMap[p.Name] = mp;
                }

                int affected = await cmd.ExecuteNonQueryAsync();
                var outVals  = outputMap.ToDictionary(
                    kv => kv.Key,
                    kv => kv.Value.Value == DBNull.Value ? null : kv.Value.Value);

                sw.Stop();
                return new ProcedureResult
                {
                    Success            = true,
                    AffectedRows       = affected,
                    OutputParameters   = outVals,
                    ExecutionTime      = $"{sw.ElapsedMilliseconds}ms"
                };
            }
        }
        catch (Exception ex)
        {
            sw.Stop();
            return new ProcedureResult { Success = false, Error = ex.Message, ExecutionTime = $"{sw.ElapsedMilliseconds}ms" };
        }
    }

    // ── Extension tables ──────────────────────────────────────────────

    public async Task<List<Dictionary<string, object?>>> GetAuditLogAsync(int page, int pageSize)
    {
        await using var conn = new MySqlConnection(_defaultCs);
        await conn.OpenAsync();
        var rows = await conn.QueryAsync("""
            SELECT `id`, `operation`, `table_name`, `record_id`,
                   `new_values`, `executed_by`, `executed_at`, `correlation_id`
            FROM `de_transaction_audit`
            ORDER BY `executed_at` DESC
            LIMIT @limit OFFSET @offset
            """, new { limit = pageSize, offset = (page - 1) * pageSize });
        return rows.Select(r => ((IDictionary<string, object>)r)
            .ToDictionary(k => k.Key, k => (object?)k.Value)).ToList();
    }

    public async Task<List<Dictionary<string, object?>>> GetFieldMappingsAsync()
    {
        await using var conn = new MySqlConnection(_defaultCs);
        await conn.OpenAsync();
        var rows = await conn.QueryAsync("SELECT * FROM `de_field_mappings` ORDER BY `table_name`, `column_name`");
        return rows.Select(r => ((IDictionary<string, object>)r)
            .ToDictionary(k => k.Key, k => (object?)k.Value)).ToList();
    }

    public async Task AddFieldMappingAsync(AddFieldMappingRequest req)
    {
        await using var conn = new MySqlConnection(_defaultCs);
        await conn.OpenAsync();
        await conn.ExecuteAsync("""
            INSERT IGNORE INTO `de_field_mappings` (`table_name`, `column_name`, `alias`, `direction`)
            VALUES (@TableName, @ColumnName, @Alias, @Direction)
            """, req);
    }

    public async Task<List<Dictionary<string, object?>>> GetQueryDefinitionsAsync()
    {
        await using var conn = new MySqlConnection(_defaultCs);
        await conn.OpenAsync();
        var rows = await conn.QueryAsync("SELECT * FROM `de_query_definitions` ORDER BY `definition_key`");
        return rows.Select(r => ((IDictionary<string, object>)r)
            .ToDictionary(k => k.Key, k => (object?)k.Value)).ToList();
    }

    public async Task AddQueryDefinitionAsync(AddQueryDefinitionRequest req)
    {
        await using var conn = new MySqlConnection(_defaultCs);
        await conn.OpenAsync();
        await conn.ExecuteAsync("""
            INSERT INTO `de_query_definitions` (`definition_key`, `table_name`, `description`, `query_json`)
            VALUES (@DefinitionKey, @TableName, @Description, @QueryJson)
            ON DUPLICATE KEY UPDATE
                `table_name`  = VALUES(`table_name`),
                `description` = VALUES(`description`),
                `query_json`  = VALUES(`query_json`),
                `updated_at`  = CURRENT_TIMESTAMP
            """, req);
    }

    public async Task<QueryResult?> ExecuteByDefinitionAsync(string key)
    {
        await using var conn = new MySqlConnection(_defaultCs);
        await conn.OpenAsync();
        var row = await conn.QueryFirstOrDefaultAsync<dynamic>("""
            SELECT `table_name`, `query_json`
            FROM `de_query_definitions`
            WHERE `definition_key` = @key AND `is_active` = 1
            """, new { key });

        if (row is null) return null;

        string tableName = (string)row.table_name;
        string queryJson = (string)row.query_json;
        var savedReq = JsonSerializer.Deserialize<QueryRequest>(queryJson,
            new JsonSerializerOptions { PropertyNameCaseInsensitive = true })
            ?? new QueryRequest();

        return await QueryAsync(tableName, savedReq);
    }

    // ── Helpers ───────────────────────────────────────────────────────

    private static void AppendFilters(
        System.Text.StringBuilder sb,
        List<FilterInfo>? filters,
        List<ColumnDef> cols,
        string tableName,
        Dictionary<string, object?> p,
        bool isCount = false)
    {
        if (filters is null || filters.Count == 0) return;

        sb.Append(" WHERE ");
        for (int i = 0; i < filters.Count; i++)
        {
            var f = filters[i];
            if (i > 0) sb.Append(f.Logic == "Or" ? " OR " : " AND ");

            var col = $"`{f.Column}`";
            switch (f.Operator)
            {
                case "IsNull":    sb.Append($"{col} IS NULL");    break;
                case "IsNotNull": sb.Append($"{col} IS NOT NULL"); break;
                case "In":
                case "NotIn":
                {
                    var vals = GetValueList(f.Value);
                    var pNames = vals.Select((v, vi) =>
                    {
                        p[$"f{i}_{vi}"] = v;
                        return $"@f{i}_{vi}";
                    }).ToList();
                    sb.Append($"{col} {(f.Operator == "NotIn" ? "NOT " : "")}IN ({string.Join(", ", pNames)})");
                    break;
                }
                case "Between":
                {
                    var vals = GetValueList(f.Value);
                    p[$"f{i}_0"] = vals[0]; p[$"f{i}_1"] = vals[1];
                    sb.Append($"{col} BETWEEN @f{i}_0 AND @f{i}_1");
                    break;
                }
                case "Like":    p[$"f{i}"] = f.Value?.ToString(); sb.Append($"{col} LIKE @f{i}");     break;
                case "NotLike": p[$"f{i}"] = f.Value?.ToString(); sb.Append($"{col} NOT LIKE @f{i}"); break;
                default:
                {
                    var op = f.Operator switch
                    {
                        "NotEquals"           => "<>",
                        "GreaterThan"         => ">",
                        "GreaterThanOrEqual"  => ">=",
                        "LessThan"            => "<",
                        "LessThanOrEqual"     => "<=",
                        _                     => "="
                    };
                    p[$"f{i}"] = UnboxJsonElement(f.Value);
                    sb.Append($"{col} {op} @f{i}");
                    break;
                }
            }
        }
    }

    private static List<object?> GetValueList(object? value)
    {
        if (value is JsonElement je && je.ValueKind == JsonValueKind.Array)
            return je.EnumerateArray().Select(e => (object?)UnboxJsonElement(e)).ToList();
        return [value];
    }

    private static object? UnboxJsonElement(object? value)
    {
        if (value is not JsonElement je) return value;
        return je.ValueKind switch
        {
            JsonValueKind.String  => je.GetString(),
            JsonValueKind.Number  => je.TryGetInt64(out var l) ? l : je.GetDouble(),
            JsonValueKind.True    => true,
            JsonValueKind.False   => false,
            JsonValueKind.Null    => null,
            _                     => je.ToString()
        };
    }

    private static void ValidateColumns(IEnumerable<string> columns, List<ColumnDef> schema, string tableName)
    {
        foreach (var col in columns)
        {
            if (!schema.Any(c => c.ColumnName.Equals(col, StringComparison.OrdinalIgnoreCase)))
                throw new InvalidOperationException(
                    $"Column '{col}' does not exist in table '{tableName}'. " +
                    $"Valid columns: {string.Join(", ", schema.Select(c => c.ColumnName))}");
        }
    }

    private async Task WriteAuditAsync(string operation, string tableName,
        string? recordId, string? oldValues, string? newValues,
        string? executedBy, string? correlationId)
    {
        try
        {
            await using var conn = new MySqlConnection(_defaultCs);
            await conn.OpenAsync();
            await conn.ExecuteAsync("""
                INSERT IGNORE INTO `de_transaction_audit`
                    (`operation`, `table_name`, `database_name`, `record_id`,
                     `old_values`, `new_values`, `executed_by`, `correlation_id`)
                VALUES
                    (@Op, @Table, DATABASE(), @RecordId,
                     @OldValues, @NewValues, @ExecutedBy, @CorrelationId)
                """,
                new { Op = operation, Table = tableName, RecordId = recordId,
                      OldValues = oldValues, NewValues = newValues,
                      ExecutedBy = executedBy, CorrelationId = correlationId });
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Audit write failed (non-critical).");
        }
    }
}

// =============================================================================
//  REQUEST / RESPONSE MODELS
// =============================================================================

public sealed class QueryRequest
{
    public List<string>?     Columns    { get; set; }
    public List<FilterInfo>? Filters    { get; set; }
    public List<SortInfo>?   Sort       { get; set; }
    public PaginationInfo?   Pagination { get; set; }
    public bool              IncludeCount { get; set; }
}

public sealed class FilterInfo
{
    public required string  Column   { get; set; }
    /// <summary>Equals | NotEquals | GreaterThan | GreaterThanOrEqual | LessThan | LessThanOrEqual | Like | NotLike | In | NotIn | IsNull | IsNotNull | Between</summary>
    public string           Operator { get; set; } = "Equals";
    public object?          Value    { get; set; }
    /// <summary>And | Or</summary>
    public string           Logic    { get; set; } = "And";
}

public sealed class SortInfo
{
    public required string Column    { get; set; }
    /// <summary>Ascending | Descending</summary>
    public string          Direction { get; set; } = "Ascending";
}

public sealed class PaginationInfo
{
    public int Page     { get; set; } = 1;
    public int PageSize { get; set; } = 20;
}

public sealed class InsertRequest
{
    public required Dictionary<string, object?> Values       { get; set; }
    public string?                              ExecutedBy   { get; set; }
    public string?                              CorrelationId { get; set; }
}

public sealed class UpdateRequest
{
    public required Dictionary<string, object?> Values        { get; set; }
    public required List<FilterInfo>            Filters       { get; set; }
    public string?                              ExecutedBy    { get; set; }
    public string?                              CorrelationId { get; set; }
}

public sealed class DeleteRequest
{
    public required List<FilterInfo> Filters      { get; set; }
    public string?                   ExecutedBy   { get; set; }
    public string?                   CorrelationId { get; set; }
}

public sealed class BulkInsertRequest
{
    public required IReadOnlyList<IReadOnlyDictionary<string, object?>> Rows { get; set; }
    public int    BatchSize  { get; set; } = 500;
    /// <summary>Abort | Ignore | Replace</summary>
    public string OnConflict { get; set; } = "Abort";
}

public sealed class TransactionRequest
{
    public required List<TxOperation> Operations   { get; set; }
    public string?                    ExecutedBy   { get; set; }
    public string?                    CorrelationId { get; set; }
}

public sealed class TxOperation
{
    public int                           Order   { get; set; }
    /// <summary>Insert | Update | Delete</summary>
    public required string               Type    { get; set; }
    public required string               Table   { get; set; }
    public Dictionary<string, object?>?  Values  { get; set; }
    public List<FilterInfo>?             Filters { get; set; }
}

public sealed class ProcedureRequest
{
    public required string              ProcedureName { get; set; }
    /// <summary>Read | Write</summary>
    public string                       Type          { get; set; } = "Read";
    public List<ProcedureParam>?        Parameters    { get; set; }
}

public sealed class ProcedureParam
{
    public required string Name      { get; set; }
    public object?         Value     { get; set; }
    /// <summary>Input | Output</summary>
    public string          Direction { get; set; } = "Input";
}

public sealed class AddFieldMappingRequest
{
    public required string TableName  { get; set; }
    public required string ColumnName { get; set; }
    public required string Alias      { get; set; }
    /// <summary>in | out | both</summary>
    public string          Direction  { get; set; } = "both";
}

public sealed class AddQueryDefinitionRequest
{
    public required string DefinitionKey { get; set; }
    public required string TableName     { get; set; }
    public string?         Description   { get; set; }
    /// <summary>Serialized QueryRequest JSON (without table name)</summary>
    public required string QueryJson     { get; set; }
}

// ── Response models ────────────────────────────────────────────────

public sealed class QueryResult
{
    public List<Dictionary<string, object?>> Data          { get; set; } = [];
    public long?                             TotalCount     { get; set; }
    public int                               Page           { get; set; }
    public int                               PageSize       { get; set; }
    public string                            ExecutionTime  { get; set; } = "";
}

public sealed class MutationResult
{
    public bool    Success       { get; set; }
    public int     AffectedRows  { get; set; }
    public long?   InsertedId    { get; set; }
    public string? Error         { get; set; }
    public string  ExecutionTime { get; set; } = "";

    public static MutationResult Fail(string error) =>
        new() { Success = false, Error = error };
}

public sealed class BulkResult
{
    public bool   Success           { get; set; }
    public int    TotalAffectedRows { get; set; }
    public int    BatchesExecuted   { get; set; }
    public int    TotalBatches      { get; set; }
    public string ExecutionTime     { get; set; } = "";
}

public sealed class TxResult
{
    public bool    Success            { get; set; }
    public int     OperationsExecuted { get; set; }
    public string? Error              { get; set; }
    public string  ExecutionTime      { get; set; } = "";
}

public sealed class ProcedureResult
{
    public bool                              Success          { get; set; }
    public List<Dictionary<string, object?>> ResultSet        { get; set; } = [];
    public Dictionary<string, object?>?     OutputParameters { get; set; }
    public int?                              AffectedRows     { get; set; }
    public string?                           Error            { get; set; }
    public string                            ExecutionTime    { get; set; } = "";
}

public sealed class TableSchemaInfo
{
    public required string          TableName   { get; set; }
    public required List<ColumnDef> Columns     { get; set; }
    public required List<string>    PrimaryKeys { get; set; }
}

public sealed class ColumnDef
{
    public required string ColumnName      { get; set; }
    public required string DataType        { get; set; }
    public required bool   IsNullable      { get; set; }
    public required bool   IsAutoIncrement { get; set; }
    public required bool   IsPrimaryKey    { get; set; }
    public int?            MaxLength       { get; set; }
    public object?         DefaultValue    { get; set; }
    public int             OrdinalPosition { get; set; }
}