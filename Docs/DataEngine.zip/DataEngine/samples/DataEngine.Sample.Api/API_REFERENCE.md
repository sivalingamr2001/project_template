# DataEngine Sample API Reference

This document describes every sample API endpoint exposed by `DataEngine.Sample.Api` in `Program.cs`, including full request parameters and sample responses.

## Base URL

`/api`

All endpoints return JSON.

---

## A — Schema Inspection

### `GET /api/schema/tables`

Description: List all tables discovered from `INFORMATION_SCHEMA`.

Parameters: none

Sample response:

```json
{
  "description": "All tables discovered from INFORMATION_SCHEMA. DataEngine uses this to validate every table/column reference at runtime.",
  "tables": [
    "products",
    "orders",
    "de_transaction_audit",
    "de_field_mappings",
    "de_query_definitions"
  ]
}
```

---

### `GET /api/schema/tables/{tableName}`

Description: Inspect column metadata for a specific table.

Path parameters:
- `tableName` (string) — table name

Sample success response:

```json
{
  "description": "Column metadata loaded from INFORMATION_SCHEMA. DataEngine validates every column name in every request against this.",
  "schema": {
    "tableName": "products",
    "columns": [
      {
        "columnName": "id",
        "dataType": "INT",
        "isNullable": false,
        "isAutoIncrement": true,
        "isPrimaryKey": true,
        "maxLength": null,
        "defaultValue": null,
        "ordinalPosition": 1
      },
      {
        "columnName": "sku",
        "dataType": "VARCHAR",
        "isNullable": false,
        "isAutoIncrement": false,
        "isPrimaryKey": false,
        "maxLength": 50,
        "defaultValue": null,
        "ordinalPosition": 2
      }
    ],
    "primaryKeys": ["id"]
  }
}
```

Sample not found response:

```json
{
  "error": "Table 'unknown_table' not found."
}
```

---

### `POST /api/schema/cache/invalidate`

Description: Invalidate and reload the schema cache.

Parameters: none

Sample response:

```json
{
  "message": "Schema cache invalidated and reloaded.",
  "description": "Call this after ALTER TABLE, CREATE TABLE, or DROP TABLE to force DataEngine to re-read INFORMATION_SCHEMA."
}
```

---

## B — Dynamic Query (Read)

### `POST /api/query/{tableName}`

Description: Dynamic SELECT with filtering, sorting, pagination, and projection.

Path parameters:
- `tableName` (string) — table name to query

Request body model: `QueryRequest`

```json
{
  "columns": ["id", "sku", "name", "price", "stock"],
  "filters": [
    { "column": "category", "operator": "Equals", "value": "cylinders" },
    { "column": "is_active", "operator": "Equals", "value": 1, "logic": "And" }
  ],
  "sort": [
    { "column": "price", "direction": "Ascending" }
  ],
  "pagination": { "page": 1, "pageSize": 10 },
  "includeCount": true
}
```

`QueryRequest` fields:
- `columns` (array of strings, optional) — selected columns, use `null` or omit for all columns
- `filters` (array of `FilterInfo`, optional)
- `sort` (array of `SortInfo`, optional)
- `pagination` (object, optional)
- `includeCount` (boolean)

`FilterInfo` fields:
- `column` (string, required)
- `operator` (string, default `Equals`)
  - Supported values: `Equals`, `NotEquals`, `GreaterThan`, `GreaterThanOrEqual`, `LessThan`, `LessThanOrEqual`, `Like`, `NotLike`, `In`, `NotIn`, `IsNull`, `IsNotNull`, `Between`
- `value` (any)
- `logic` (string, default `And`) — `And` or `Or`

`SortInfo` fields:
- `column` (string, required)
- `direction` (string, default `Ascending`) — `Ascending` or `Descending`

`PaginationInfo` fields:
- `page` (integer, default `1`)
- `pageSize` (integer, default `20`)

Sample response:

```json
{
  "data": [
    { "id": 1, "sku": "CYL-001", "name": "Cylinder 20mm", "price": 120.00, "stock": 10 },
    { "id": 2, "sku": "CYL-002", "name": "Cylinder 25mm", "price": 140.00, "stock": 8 }
  ],
  "totalCount": 2,
  "page": 1,
  "pageSize": 10,
  "executionTime": "12ms"
}
```

---

## C — Single-Row Writes

### `POST /api/write/{tableName}/insert`

Description: Insert a single row dynamically.

Path parameters:
- `tableName` (string)

Request body model: `InsertRequest`

```json
{
  "values": {
    "sku": "CYL-050",
    "name": "Pneumatic Cylinder 50mm",
    "price": 1850.00,
    "stock": 75,
    "category": "cylinders",
    "is_active": 1
  },
  "executedBy": "admin",
  "correlationId": "req-abc-123"
}
```

Sample success response:

```json
{
  "success": true,
  "affectedRows": 1,
  "insertedId": 123,
  "executionTime": "18ms"
}
```

### `PUT /api/write/{tableName}/update`

Description: Update rows matching required filter clauses.

Path parameters:
- `tableName` (string)

Request body model: `UpdateRequest`

```json
{
  "values": { "is_active": 0 },
  "filters": [
    { "column": "sku", "operator": "Equals", "value": "CYL-050" }
  ],
  "executedBy": "admin"
}
```

Sample response:

```json
{
  "success": true,
  "affectedRows": 1,
  "insertedId": null,
  "executionTime": "14ms"
}
```

### `DELETE /api/write/{tableName}/delete`

Description: Delete rows matching required filter clauses.

Path parameters:
- `tableName` (string)

Request body model: `DeleteRequest`

```json
{
  "filters": [
    { "column": "sku", "operator": "Equals", "value": "CYL-050" }
  ],
  "executedBy": "admin"
}
```

Sample response:

```json
{
  "success": true,
  "affectedRows": 1,
  "insertedId": null,
  "executionTime": "11ms"
}
```

---

## D — Bulk Operations

### `POST /api/bulk/{tableName}/insert`

Description: Insert multiple rows in configurable batches.

Path parameters:
- `tableName` (string)

Request body model: `BulkInsertRequest`

```json
{
  "rows": [
    { "sku": "VLV-010", "name": "Solenoid Valve 10mm", "price": 720.00, "stock": 200, "category": "valves", "is_active": 1 },
    { "sku": "VLV-020", "name": "Solenoid Valve 20mm", "price": 980.00, "stock": 150, "category": "valves", "is_active": 1 },
    { "sku": "FLT-010", "name": "Air Filter 10 micron", "price": 350.00, "stock": 400, "category": "filters", "is_active": 1 }
  ],
  "batchSize": 500,
  "onConflict": "Ignore"
}
```

`BulkInsertRequest` fields:
- `rows` (array of object maps, required)
- `batchSize` (integer, default `500`)
- `onConflict` (string, default `Abort`) — supported values: `Abort`, `Ignore`, `Replace`

Sample response:

```json
{
  "success": true,
  "totalAffectedRows": 3,
  "batchesExecuted": 1,
  "totalBatches": 1,
  "executionTime": "35ms"
}
```

---

## E — Transactions

### `POST /api/transaction/execute`

Description: Execute multiple operations atomically.

Request body model: `TransactionRequest`

```json
{
  "operations": [
    {
      "order": 1,
      "type": "Insert",
      "table": "orders",
      "values": {
        "product_id": 1,
        "quantity": 5,
        "status": "pending",
        "customer_name": "Acme Corp",
        "total_amount": 7500.00
      }
    },
    {
      "order": 2,
      "type": "Update",
      "table": "products",
      "values": { "stock": 95 },
      "filters": [
        { "column": "id", "operator": "Equals", "value": 1 }
      ]
    }
  ],
  "executedBy": "order-service",
  "correlationId": "order-xyz-789"
}
```

`TransactionRequest` fields:
- `operations` (array of `TxOperation`, required)
- `executedBy` (string)
- `correlationId` (string)

`TxOperation` fields:
- `order` (integer)
- `type` (string, required) — `Insert`, `Update`, `Delete`
- `table` (string, required)
- `values` (object map, optional)
- `filters` (array of `FilterInfo`, optional)

Sample response:

```json
{
  "success": true,
  "operationsExecuted": 2,
  "error": null,
  "executionTime": "58ms"
}
```

---

## F — Stored Procedures

### `POST /api/procedure/execute`

Description: Execute a stored procedure for read or write.

Request body model: `ProcedureRequest`

```json
{
  "procedureName": "sp_get_products_by_category",
  "type": "Read",
  "parameters": [
    { "name": "p_category", "value": "cylinders", "direction": "Input" }
  ]
}
```

Alternative write procedure sample:

```json
{
  "procedureName": "sp_update_stock",
  "type": "Write",
  "parameters": [
    { "name": "p_product_id", "value": 1, "direction": "Input" },
    { "name": "p_quantity", "value": 10, "direction": "Input" },
    { "name": "p_new_stock", "value": 0, "direction": "Output" }
  ]
}
```

`ProcedureRequest` fields:
- `procedureName` (string, required)
- `type` (string, default `Read`) — `Read` or `Write`
- `parameters` (array of `ProcedureParam`)

`ProcedureParam` fields:
- `name` (string, required)
- `value` (any)
- `direction` (string, default `Input`) — `Input` or `Output`

Sample read response:

```json
{
  "success": true,
  "resultSet": [
    { "id": 1, "sku": "CYL-001", "name": "Cylinder 20mm", "category": "cylinders" }
  ],
  "outputParameters": null,
  "affectedRows": null,
  "error": null,
  "executionTime": "22ms"
}
```

Sample write response with output params:

```json
{
  "success": true,
  "resultSet": [],
  "outputParameters": { "p_new_stock": 95 },
  "affectedRows": 1,
  "error": null,
  "executionTime": "28ms"
}
```

---

## G — Audit Trail

### `GET /api/audit`

Description: Browse the audit trail stored in `de_transaction_audit`.

Query parameters:
- `page` (integer, default `1`)
- `pageSize` (integer, default `20`)

Sample response:

```json
{
  "description": "All audit entries from de_transaction_audit. DataEngine writes here on every INSERT/UPDATE/DELETE when EnableAudit=true.",
  "entries": [
    {
      "id": 101,
      "operation": "Insert",
      "table_name": "products",
      "database_name": "DataEngine_TestDB",
      "record_id": "123",
      "old_values": null,
      "new_values": "{...}",
      "executed_by": "admin",
      "correlation_id": "req-abc-123"
    }
  ]
}
```

---

## H — Field Mappings

### `GET /api/field-mappings`

Description: List field alias mappings from `de_field_mappings`.

Sample response:

```json
{
  "description": "Field alias mappings from de_field_mappings. DataEngine uses these to translate API aliases to real DB column names.",
  "mappings": [
    {
      "tableName": "products",
      "columnName": "name",
      "alias": "productName",
      "direction": "both"
    }
  ]
}
```

### `POST /api/field-mappings`

Description: Add a field alias mapping.

Request body model: `AddFieldMappingRequest`

```json
{
  "tableName": "products",
  "columnName": "name",
  "alias": "productName",
  "direction": "both"
}
```

Sample response:

```json
{
  "message": "Mapping added. DataEngine will use this alias in future requests.",
  "mapping": {
    "tableName": "products",
    "columnName": "name",
    "alias": "productName",
    "direction": "both"
  }
}
```

---

## I — Saved Query Definitions

### `GET /api/query-definitions`

Description: List all saved query definitions from `de_query_definitions`.

Sample response:

```json
{
  "description": "Saved query definitions from de_query_definitions. Call engine.QueryByDefinitionAsync('key') to execute by name.",
  "definitions": [
    {
      "definitionKey": "active-cylinders",
      "tableName": "products",
      "description": "All active cylinder products sorted by price",
      "queryJson": "{...}"
    }
  ]
}
```

### `POST /api/query-definitions`

Description: Save a reusable named query definition.

Request body model: `AddQueryDefinitionRequest`

```json
{
  "definitionKey": "active-cylinders",
  "tableName": "products",
  "description": "All active cylinder products sorted by price",
  "queryJson": "{\"filters\":[{\"column\":\"category\",\"operator\":\"Equals\",\"value\":\"cylinders\"},{\"column\":\"is_active\",\"operator\":\"Equals\",\"value\":1}],\"sort\":[{\"column\":\"price\",\"direction\":\"Ascending\"}]}"
}
```

Sample response:

```json
{
  "message": "Query definition saved. Use the definitionKey to run it.",
  "definition": {
    "definitionKey": "active-cylinders",
    "tableName": "products",
    "description": "All active cylinder products sorted by price",
    "queryJson": "{...}"
  }
}
```

### `POST /api/query-definitions/{key}/execute`

Description: Execute a saved query definition by key.

Path parameters:
- `key` (string)

Sample response success:

```json
{
  "definitionKey": "active-cylinders",
  "result": {
    "data": [
      { "id": 1, "sku": "CYL-001", "name": "Cylinder 20mm" }
    ],
    "totalCount": null,
    "page": 1,
    "pageSize": 20,
    "executionTime": "15ms"
  }
}
```

Sample not found response:

```json
{
  "error": "No active definition found for key 'missing-key'."
}
```

---

## J — Complete Demo Walkthrough

### `GET /api/demo/run-all`

Description: Run all DataEngine capabilities in sequence and return full results.

Sample response structure:

```json
{
  "title": "DataEngine — Complete Capability Walkthrough",
  "message": "All 9 steps executed successfully against a live MySQL database.",
  "totalSteps": 9,
  "steps": [
    {
      "step": 1,
      "name": "Schema Discovery",
      "description": "DataEngine reads INFORMATION_SCHEMA on startup and caches all table/column metadata.",
      "result": { "tablesFound": 5, "tables": ["products", "orders", "de_transaction_audit", "de_field_mappings", "de_query_definitions"] }
    },
    {
      "step": 2,
      "name": "Dynamic Query",
      "description": "SELECT with sort + pagination. No entity class needed.",
      "result": { "data": [ ... ], "totalCount": 5, "page": 1, "pageSize": 5, "executionTime": "..." }
    }
  ]
}
```

---

## Utility

### `GET /api/db-info`

Description: Return provider and configured connection string values.

Sample response:

```json
{
  "provider": "MySqlConnector",
  "connections": {
    "DefaultConnection": "Server=localhost;Database=DataEngine_TestDB;User=root;Password=...;",
    "ReportingConnection": "Server=localhost;Database=DataEngine_TestDB;User=root;Password=...;"
  }
}
```
