﻿using DynamicTransactionEngine.Core.Enums;
using DynamicTransactionEngine.Core.Models;
using DynamicTransactionEngine.Infrastructure.DependencyInjection;
using DynamicTransactionEngine.MySql;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using DynamicTransactionEngine.Application.Services;

var services = new ServiceCollection();
services.AddLogging(builder => builder.AddSimpleConsole());
services.AddDynamicTransactionEngine();
services.AddDynamicTransactionEngineMySql();

await using var provider = services.BuildServiceProvider().CreateAsyncScope();
var orchestrator = provider.ServiceProvider.GetRequiredService<TransactionOrchestrator>();

var request = new TransactionRequest
{
    EntityName = "Customer",
    Operation = TransactionOperation.Insert,
    Values = new Dictionary<string, object?>
    {
        ["Id"] = 1001,
        ["Name"] = "Access Portal User",
        ["UpdatedAtUtc"] = DateTime.UtcNow
    }
};

var result = await orchestrator.ExecuteAsync(request);
Console.WriteLine($"Success={result.Success}, Rows={result.RowsAffected}, Message={result.Message}");
