namespace DynamicTransactionEngine.Core.Contracts;

public sealed record QueryDefinition(string Sql, IReadOnlyDictionary<string, object?> Parameters);

public sealed record AuditEntry
{
    public required string EntityName { get; init; }
    public required string Operation { get; init; }
    public required string CorrelationId { get; init; }
    public IDictionary<string, object?> Data { get; init; } = new Dictionary<string, object?>();
    public DateTimeOffset TimestampUtc { get; init; } = DateTimeOffset.UtcNow;
}
