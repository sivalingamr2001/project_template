using DynamicTransactionEngine.Core.Contracts;
using DynamicTransactionEngine.Core.Models;

namespace DynamicTransactionEngine.Core.Interfaces;

public interface ITransactionProcessor
{
    Task<TransactionResult> ProcessAsync(TransactionContext context, CancellationToken cancellationToken = default);
}

public interface IQueryBuilder
{
    QueryDefinition Build(TransactionContext context, EntityMetadata metadata);
}

public interface IFieldMapperProvider
{
    Task<EntityMetadata> GetEntityMetadataAsync(string entityName, CancellationToken cancellationToken = default);
}

public interface IEntityValidator
{
    Task ValidateAsync(TransactionContext context, EntityMetadata metadata, CancellationToken cancellationToken = default);
}

public interface IForeignKeyValidator
{
    Task ValidateAsync(TransactionContext context, CancellationToken cancellationToken = default);
}

public interface IAuditService
{
    Task WriteAsync(AuditEntry entry, CancellationToken cancellationToken = default);
}

public interface ITransactionValidator
{
    Task ValidateAsync(TransactionContext context, CancellationToken cancellationToken = default);
}

public interface ISchemaProvider
{
    Task<bool> EntityExistsAsync(string entityName, CancellationToken cancellationToken = default);
}

public interface ITriggerService
{
    Task OnBeforeExecuteAsync(TransactionContext context, CancellationToken cancellationToken = default);
    Task OnAfterExecuteAsync(TransactionContext context, TransactionResult result, CancellationToken cancellationToken = default);
}

public interface IMetadataCacheService
{
    Task<EntityMetadata> GetOrCreateEntityMetadataAsync(string entityName, Func<CancellationToken, Task<EntityMetadata>> factory, CancellationToken cancellationToken = default);
}
