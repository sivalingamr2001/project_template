using DynamicTransactionEngine.Core.Enums;

namespace DynamicTransactionEngine.Core.Models;

public sealed record FieldMapper
{
    public int Id { get; init; }
    public string EntityName { get; init; } = string.Empty;
    public string ColumnName { get; init; } = string.Empty;
    public string DataType { get; init; } = "varchar";
    public FieldProperty Properties { get; init; } = FieldProperty.None;
    public DataClassification Classification { get; init; } = DataClassification.Public;
    public bool IsChildReference { get; init; }
}

public sealed record EntityMetadata
{
    public string EntityName { get; init; } = string.Empty;
    public string TableName { get; init; } = string.Empty;
    public IReadOnlyCollection<FieldMapper> Fields { get; init; } = [];
}

public sealed record ForeignKeyMetadata
{
    public string EntityName { get; init; } = string.Empty;
    public string ColumnName { get; init; } = string.Empty;
    public string ReferencedTable { get; init; } = string.Empty;
    public string ReferencedColumn { get; init; } = string.Empty;
    public CascadeRule Rule { get; init; } = CascadeRule.Restrict;
}

public sealed record TransactionRequest
{
    public required string EntityName { get; init; }
    public required TransactionOperation Operation { get; init; }
    public IDictionary<string, object?> Values { get; init; } = new Dictionary<string, object?>();
    public IList<TransactionRequest> Children { get; init; } = [];
    public string? CorrelationId { get; init; }
}

public sealed record TransactionResult
{
    public bool Success { get; init; }
    public int RowsAffected { get; init; }
    public string? Message { get; init; }
    public IDictionary<string, object?> Output { get; init; } = new Dictionary<string, object?>();
    public static TransactionResult Ok(int rowsAffected, string? message = null) =>
        new() { Success = true, RowsAffected = rowsAffected, Message = message };
}

public sealed record TransactionContext
{
    public required TransactionRequest Request { get; init; }
    public DateTimeOffset StartedAtUtc { get; init; } = DateTimeOffset.UtcNow;
    public string CorrelationId { get; init; } = Guid.NewGuid().ToString("N");
}
