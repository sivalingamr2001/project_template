namespace DynamicTransactionEngine.Core.Exceptions;

public class TransactionEngineException(string message) : Exception(message);

public sealed class EntityNotFoundException(string entityName)
    : TransactionEngineException($"Entity '{entityName}' was not found.");

public sealed class ForeignKeyViolationException(string message)
    : TransactionEngineException(message);

public sealed class EngineValidationException(string message)
    : TransactionEngineException(message);

public sealed class SqlInjectionAttemptException(string identifier)
    : TransactionEngineException($"Potential SQL injection attempt in identifier '{identifier}'.");
