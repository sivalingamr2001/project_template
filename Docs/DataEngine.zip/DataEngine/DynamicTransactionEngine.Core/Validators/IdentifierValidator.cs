using System.Text.RegularExpressions;
using DynamicTransactionEngine.Core.Exceptions;

namespace DynamicTransactionEngine.Core.Validators;

public static partial class IdentifierValidator
{
    [GeneratedRegex("^[a-zA-Z_][a-zA-Z0-9_]*$")]
    private static partial Regex IdentifierRegex();

    public static string EnsureValid(string identifier)
    {
        if (string.IsNullOrWhiteSpace(identifier) || !IdentifierRegex().IsMatch(identifier))
        {
            throw new SqlInjectionAttemptException(identifier);
        }

        return identifier;
    }
}
