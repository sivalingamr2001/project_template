using System;

namespace DynamicTransactionEngine.Core.Enums;

public enum TransactionOperation
{
    Insert = 1,
    Update = 2,
    Delete = 3
}

public enum CascadeRule
{
    NoAction = 0,
    Cascade = 1,
    SetNull = 2,
    Restrict = 3
}

[Flags]
public enum FieldProperty
{
    None = 0,
    Required = 1 << 0,
    PrimaryKey = 1 << 1,
    Identity = 1 << 2,
    ForeignKey = 1 << 3,
    ReadOnly = 1 << 4,
    AllowUpdate = 1 << 5,
    IgnoreOnInsert = 1 << 6,
    IgnoreOnUpdate = 1 << 7,
    SoftDeleteColumn = 1 << 8,
    Sensitive = 1 << 9
}

public enum DataClassification
{
    Public = 0,
    Internal = 1,
    Confidential = 2,
    Restricted = 3
}
