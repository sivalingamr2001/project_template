import { axiosInstance } from "./client";
import type { QueryResultResponse } from "./types";

export interface QueryRequest {
  columns?: string[];
  filters?: Array<Record<string, unknown>>;
  sort?: Array<Record<string, unknown>>;
  pagination?: { page: number; pageSize: number };
  includeCount?: boolean;
}

export async function queryTable(
  tableName: string,
  request: QueryRequest,
): Promise<QueryResultResponse> {
  const response = await axiosInstance.post<QueryResultResponse>(`/api/query/${encodeURIComponent(tableName)}`, request);
  return response.data;
}
