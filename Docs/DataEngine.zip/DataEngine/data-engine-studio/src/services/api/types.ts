export interface DbInfoResponse {
  provider: string;
  connections: Record<string, string>;
}

export interface ConnectionTestResponse {
  success: boolean;
  message?: string;
  error?: string;
}

export interface DataEngineSettingsResponse {
  environment: string;
  dataEngine: Record<string, string>;
}

export interface SchemaTableListResponse {
  description: string;
  tables: string[];
}

export interface ColumnInfo {
  columnName: string;
  dataType: string;
  isNullable: boolean;
  isAutoIncrement: boolean;
  isPrimaryKey: boolean;
  maxLength?: number | null;
  defaultValue?: string | null;
  ordinalPosition?: number;
}

export interface SchemaResponse {
  success: boolean;
  error?: string;
  tableName?: string;
  databaseName?: string;
  columns?: ColumnInfo[];
  primaryKeys?: string[];
  cachedAt?: string;
}

export interface TableSchemaResponse {
  description: string;
  schema: SchemaResponse;
}

export interface QueryResultResponse {
  data: Array<Record<string, unknown>>;
  totalCount?: number;
  page?: number;
  pageSize?: number;
  executionTime?: string;
  success?: boolean;
  error?: string;
}

export interface MutationResponse {
  success: boolean;
  affectedRows: number;
  insertedId?: number;
  insertedIds?: number[];
  error?: string;
  executionTime?: string;
}

export interface AuditEntry {
  id: string;
  operation: string;
  tableName: string;
  databaseName: string;
  recordId?: string;
  oldValues?: string;
  newValues?: string;
  executedBy?: string;
  executedAt: string;
  correlationId?: string;
}

export interface AuditLogResponse {
  description: string;
  entries: AuditEntry[];
}

export interface FieldMapping {
  tableName: string;
  columnName: string;
  alias: string;
  direction: "both" | "in" | "out";
}

export interface FieldMappingsResponse {
  description: string;
  mappings: FieldMapping[];
}

export interface AddFieldMappingRequest {
  tableName: string;
  columnName: string;
  alias: string;
  direction: "both" | "in" | "out";
}

export interface QueryDefinition {
  definitionKey: string;
  tableName: string;
  description?: string | null;
  queryJson: string;
  isActive?: boolean;
}

export interface QueryDefinitionsResponse {
  description: string;
  definitions: QueryDefinition[];
}

export interface AddQueryDefinitionRequest {
  definitionKey: string;
  tableName: string;
  description?: string;
  queryJson: string;
}

export interface QueryDefinitionExecuteResponse {
  definitionKey: string;
  result: QueryResultResponse;
}

export interface ProcedureParameter {
  name: string;
  value?: unknown;
  direction?: "Input" | "Output";
}

export interface ProcedureRequest {
  procedureName: string;
  type?: "Read" | "Write";
  parameters?: ProcedureParameter[];
}

export interface ProcedureResultResponse {
  success: boolean;
  resultSet?: Array<Record<string, unknown>>;
  outputParameters?: Record<string, unknown>;
  affectedRows?: number;
  error?: string;
  executionTime?: string;
}
