import { axiosInstance } from "./client";
import type { MutationResponse } from "./types";

export interface InsertPayload {
  values: Record<string, unknown>;
  executedBy?: string;
  correlationId?: string;
}

export interface UpdatePayload {
  values: Record<string, unknown>;
  filters: Array<Record<string, unknown>>;
  executedBy?: string;
  correlationId?: string;
}

export interface DeletePayload {
  filters: Array<Record<string, unknown>>;
  executedBy?: string;
  correlationId?: string;
}

export interface BulkInsertPayload {
  rows: Array<Record<string, unknown>>;
  batchSize?: number;
  onConflict?: "Abort" | "Ignore" | "Replace";
}

export async function insertRow(
  tableName: string,
  payload: InsertPayload,
): Promise<MutationResponse> {
  const response = await axiosInstance.post<MutationResponse>(`/api/write/${encodeURIComponent(tableName)}/insert`, payload);
  return response.data;
}

export async function updateRow(
  tableName: string,
  payload: UpdatePayload,
): Promise<MutationResponse> {
  const response = await axiosInstance.put<MutationResponse>(`/api/write/${encodeURIComponent(tableName)}/update`, payload);
  return response.data;
}

export async function deleteRow(
  tableName: string,
  payload: DeletePayload,
): Promise<MutationResponse> {
  const response = await axiosInstance.delete<MutationResponse>(`/api/write/${encodeURIComponent(tableName)}/delete`, {
    data: payload,
  });
  return response.data;
}

export async function bulkInsert(
  tableName: string,
  payload: BulkInsertPayload,
): Promise<MutationResponse> {
  const response = await axiosInstance.post<MutationResponse>(`/api/bulk/${encodeURIComponent(tableName)}/insert`, payload);
  return response.data;
}
