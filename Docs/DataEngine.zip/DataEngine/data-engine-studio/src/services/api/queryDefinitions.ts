import { axiosInstance } from "./client";
import type { AddQueryDefinitionRequest, QueryDefinitionsResponse, QueryDefinitionExecuteResponse } from "./types";

export async function listQueryDefinitions(): Promise<QueryDefinitionsResponse> {
  const response = await axiosInstance.get<QueryDefinitionsResponse>("/api/query-definitions");
  return response.data;
}

export async function saveQueryDefinition(
  payload: AddQueryDefinitionRequest,
): Promise<AddQueryDefinitionRequest> {
  const response = await axiosInstance.post<AddQueryDefinitionRequest>("/api/query-definitions", payload);
  return response.data;
}

export async function executeQueryDefinition(
  definitionKey: string,
): Promise<QueryDefinitionExecuteResponse> {
  const response = await axiosInstance.post<QueryDefinitionExecuteResponse>(`/api/query-definitions/${encodeURIComponent(definitionKey)}/execute`);
  return response.data;
}
