import { axiosInstance } from "./client";
import type { ConnectionTestResponse, DbInfoResponse } from "./types";

export async function getDbInfo(): Promise<DbInfoResponse> {
  const response = await axiosInstance.get<DbInfoResponse>("/api/db-info");
  return response.data;
}

export async function testConnection(connectionName: string): Promise<ConnectionTestResponse> {
  const response = await axiosInstance.post<ConnectionTestResponse>("/api/connections/test", {
    connectionName,
  });
  return response.data;
}
