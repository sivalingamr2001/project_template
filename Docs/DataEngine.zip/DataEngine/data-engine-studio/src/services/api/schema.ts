import { axiosInstance } from "./client";
import type { SchemaTableListResponse, TableSchemaResponse } from "./types";

export async function listTables(): Promise<SchemaTableListResponse> {
  const response = await axiosInstance.get<SchemaTableListResponse>("/api/schema/tables");
  return response.data;
}

export async function getTableSchema(tableName: string): Promise<TableSchemaResponse> {
  const response = await axiosInstance.get<TableSchemaResponse>(`/api/schema/tables/${encodeURIComponent(tableName)}`);
  return response.data;
}

export async function invalidateSchemaCache(): Promise<{ message: string }> {
  const response = await axiosInstance.post<{ message: string }>("/api/schema/cache/invalidate");
  return response.data;
}
