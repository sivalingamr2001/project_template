import { axiosInstance } from "./client";
import type { DataEngineSettingsResponse, FieldMappingsResponse, AddFieldMappingRequest } from "./types";

export async function getSettings(): Promise<DataEngineSettingsResponse> {
  const response = await axiosInstance.get<DataEngineSettingsResponse>("/api/settings");
  return response.data;
}

export async function getFieldMappings(): Promise<FieldMappingsResponse> {
  const response = await axiosInstance.get<FieldMappingsResponse>("/api/field-mappings");
  return response.data;
}

export async function addFieldMapping(
  payload: AddFieldMappingRequest,
): Promise<AddFieldMappingRequest> {
  const response = await axiosInstance.post<AddFieldMappingRequest>("/api/field-mappings", payload);
  return response.data;
}
