import axios, { type AxiosInstance } from "axios";
import { getApiBaseUrl } from "@/lib/utils";

export const createAxiosInstance = (): AxiosInstance => {
  const baseURL = getApiBaseUrl();
  return axios.create({
    baseURL,
    timeout: 30_000,
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },
  });
};

export const axiosInstance = createAxiosInstance();
