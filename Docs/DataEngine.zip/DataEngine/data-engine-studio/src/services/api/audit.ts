import { axiosInstance } from "./client";
import type { AuditLogResponse } from "./types";

export async function getAuditLog(page = 1, pageSize = 20): Promise<AuditLogResponse> {
  const response = await axiosInstance.get<AuditLogResponse>("/api/audit", {
    params: {
      page,
      pageSize,
    },
  });
  return response.data;
}
