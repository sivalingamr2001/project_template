import { axiosInstance } from "./client";
import type { ProcedureRequest, ProcedureResultResponse } from "./types";

export async function executeProcedure(
  request: ProcedureRequest,
): Promise<ProcedureResultResponse> {
  const response = await axiosInstance.post<ProcedureResultResponse>("/api/procedure/execute", request);
  return response.data;
}
