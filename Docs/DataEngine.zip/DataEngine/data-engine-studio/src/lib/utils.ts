import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}


export function getApiBaseUrl() {
  const baseUrl = import.meta.env.VITE_API_BASE_URL || import.meta.env.VITE_BASE_API_URL || '/api';
  return baseUrl.endsWith('/') ? baseUrl.slice(0, -1) : baseUrl;
}