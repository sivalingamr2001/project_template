import { useEffect, useState } from 'react'
import { Plus, Trash2, CheckCircle2, AlertCircle } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { getDbInfo, testConnection } from '@/services/api/connections'

interface ConnectionItem {
  name: string
  connectionString: string
  status: string
  lastSync: string
}

export default function Connections() {
  const [connections, setConnections] = useState<ConnectionItem[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [testResult, setTestResult] = useState<string | null>(null)

  useEffect(() => {
    const loadConnections = async () => {
      try {
        const info = await getDbInfo()
        setConnections(
          Object.entries(info.connections).map(([name, connectionString]) => ({
            name,
            connectionString,
            status: 'connected',
            lastSync: 'N/A',
          })),
        )
      } catch (err) {
        setError('Unable to load connections from the backend.')
      } finally {
        setIsLoading(false)
      }
    }

    loadConnections()
  }, [])

  const handleTestConnection = async (name: string) => {
    setTestResult(null)
    try {
      const result = await testConnection(name)
      setTestResult(result.success ? result.message ?? 'Connection succeeded.' : result.error ?? 'Connection failed.')
    } catch (error) {
      setTestResult('Connection test failed.')
    }
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="border-b border-border p-6 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Connections</h1>
          <p className="text-muted-foreground">Manage database connections and schema caches.</p>
        </div>
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          New Connection
        </Button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-6">
        {isLoading ? (
          <div className="text-sm text-muted-foreground">Loading connections...</div>
        ) : error ? (
          <div className="text-sm text-destructive">{error}</div>
        ) : (
          <div className="grid gap-4">
            {connections.map((conn) => (
              <Card key={conn.name} className="hover:border-primary/50 transition-colors">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-3">
                        <h3 className="text-lg font-semibold text-foreground">{conn.name}</h3>
                        <span className="inline-flex items-center gap-1 text-xs font-medium text-green-600 bg-green-50 px-2 py-1 rounded">
                          <CheckCircle2 className="w-3 h-3" />
                          Connected
                        </span>
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <p className="text-muted-foreground">Connection</p>
                          <p className="font-medium text-foreground truncate">{conn.name}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Provider</p>
                          <p className="font-medium text-foreground text-xs">MySQL</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Status</p>
                          <p className="font-medium text-foreground">{conn.status}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Last Sync</p>
                          <p className="font-medium text-foreground text-xs">{conn.lastSync}</p>
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-2 ml-4">
                      <Button variant="outline" size="sm" onClick={() => handleTestConnection(conn.name)}>
                        Test
                      </Button>
                      <Button variant="outline" size="sm">
                        Edit
                      </Button>
                      <Button variant="ghost" size="sm" className="text-destructive">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
        {testResult ? (
          <div className="mt-4 rounded-lg border border-border bg-secondary p-4 text-sm text-foreground">
            {testResult}
          </div>
        ) : null}
      </div>
    </div>
  )
}
