import { useState } from 'react'
import { Play, RotateCcw, Search } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { motion } from 'framer-motion'

interface Procedure {
  name: string
  parameters: { name: string; type: string; required: boolean }[]
}

export default function ProcedureStudio() {
  const [selectedProcedure, setSelectedProcedure] = useState('sp_GetUsers')
  const [isExecuting, setIsExecuting] = useState(false)
  const [results, setResults] = useState<any[]>([])
  const [executionTime, setExecutionTime] = useState(0)

  const procedures: Record<string, Procedure> = {
    sp_GetUsers: {
      name: 'sp_GetUsers',
      parameters: [
        { name: 'status', type: 'VARCHAR(50)', required: false },
        { name: 'limit', type: 'INT', required: false },
      ],
    },
    sp_InsertOrder: {
      name: 'sp_InsertOrder',
      parameters: [
        { name: 'user_id', type: 'INT', required: true },
        { name: 'total_amount', type: 'DECIMAL(10,2)', required: true },
        { name: 'order_date', type: 'DATETIME', required: false },
      ],
    },
    sp_SyncData: {
      name: 'sp_SyncData',
      parameters: [
        { name: 'sync_date', type: 'DATETIME', required: true },
        { name: 'force_sync', type: 'BIT', required: false },
      ],
    },
  }

  const procedure = procedures[selectedProcedure]
  const [paramValues, setParamValues] = useState<Record<string, string>>(
    procedure.parameters.reduce((acc, p) => ({ ...acc, [p.name]: '' }), {})
  )

  const handleExecute = async () => {
    setIsExecuting(true)
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setResults([
      { id: 1, name: 'John Doe', email: 'john@example.com', status: 'Active' },
      { id: 2, name: 'Jane Smith', email: 'jane@example.com', status: 'Active' },
      { id: 3, name: 'Bob Johnson', email: 'bob@example.com', status: 'Inactive' },
    ])
    setExecutionTime(342)
    setIsExecuting(false)
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="border-b border-border p-6 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Procedure Studio</h1>
          <p className="text-muted-foreground">Execute stored procedures and view results with detailed metrics.</p>
        </div>
        <motion.div whileTap={{ scale: 0.95 }}>
          <Button onClick={handleExecute} disabled={isExecuting}>
            <Play className="w-4 h-4 mr-2" />
            {isExecuting ? 'Executing...' : 'Execute'}
          </Button>
        </motion.div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-hidden flex gap-4 p-4">
        {/* Procedure Selector & Parameters */}
        <div className="flex-1 flex flex-col min-h-0">
          <Card className="flex-1 flex flex-col">
            <CardHeader className="pb-3 border-b border-border">
              <CardTitle className="text-sm">Procedure & Parameters</CardTitle>
            </CardHeader>
            <CardContent className="flex-1 overflow-auto space-y-4 p-4">
              <div>
                <label className="text-xs font-medium text-muted-foreground block mb-2">Select Procedure</label>
                <select
                  value={selectedProcedure}
                  onChange={(e) => setSelectedProcedure(e.target.value)}
                  className="w-full px-3 py-2 rounded-md border border-input bg-background text-foreground text-sm"
                >
                  {Object.keys(procedures).map((name) => (
                    <option key={name} value={name}>
                      {name}
                    </option>
                  ))}
                </select>
              </div>

              {procedure && (
                <div className="space-y-3">
                  <label className="text-xs font-medium text-muted-foreground block">Parameters</label>
                  {procedure.parameters.length === 0 ? (
                    <p className="text-xs text-muted-foreground">No parameters required</p>
                  ) : (
                    <div className="space-y-2">
                      {procedure.parameters.map((param) => (
                        <motion.div
                          key={param.name}
                          initial={{ opacity: 0, y: -10 }}
                          animate={{ opacity: 1, y: 0 }}
                        >
                          <label className="text-xs text-muted-foreground block mb-1">
                            {param.name} {param.required ? '*' : '(optional)'}
                          </label>
                          <input
                            type="text"
                            placeholder={`Enter ${param.type}`}
                            value={paramValues[param.name] || ''}
                            onChange={(e) =>
                              setParamValues({ ...paramValues, [param.name]: e.target.value })
                            }
                            className="w-full px-2 py-1 rounded border border-border bg-background text-xs"
                          />
                        </motion.div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Results */}
        <div className="flex-1 flex flex-col min-h-0">
          <Tabs defaultValue="results" className="flex-1 flex flex-col">
            <TabsList className="w-full justify-start border-b rounded-none bg-transparent">
              <TabsTrigger value="results">Results ({results.length})</TabsTrigger>
              <TabsTrigger value="metrics">Metrics</TabsTrigger>
              <TabsTrigger value="info">Procedure Info</TabsTrigger>
            </TabsList>

            <TabsContent value="results" className="flex-1 overflow-auto">
              <div className="p-4">
                {results.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <p className="text-sm">Execute procedure to see results</p>
                  </div>
                ) : (
                  <div className="border border-border rounded-lg overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead className="bg-secondary border-b border-border">
                        <tr>
                          {Object.keys(results[0] || {}).map((key) => (
                            <th key={key} className="px-4 py-2 text-left font-medium">
                              {key}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {results.map((row, idx) => (
                          <tr key={idx} className="border-b border-border hover:bg-secondary/50">
                            {Object.values(row).map((value, colIdx) => (
                              <td key={colIdx} className="px-4 py-2">
                                {String(value)}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="metrics" className="flex-1 overflow-auto">
              <div className="p-4 space-y-3">
                <div className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                  <span className="text-sm font-medium">Rows Returned</span>
                  <span className="text-lg font-bold">{results.length}</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                  <span className="text-sm font-medium">Execution Time</span>
                  <span className="text-lg font-bold">{executionTime}ms</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                  <span className="text-sm font-medium">Status</span>
                  <span className="text-lg font-bold text-green-600">Success</span>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="info" className="flex-1 overflow-auto">
              <div className="p-4 space-y-3">
                <div>
                  <p className="text-xs text-muted-foreground">Procedure Name</p>
                  <p className="font-medium">{selectedProcedure}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Parameters</p>
                  <p className="font-medium">{procedure?.parameters.length || 0}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Return Type</p>
                  <p className="font-medium">Dataset</p>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
