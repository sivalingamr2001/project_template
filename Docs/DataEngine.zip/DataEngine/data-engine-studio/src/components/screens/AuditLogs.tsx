import { useState } from 'react'
import { Search, Download, Calendar } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { motion } from 'framer-motion'

interface AuditLog {
  id: number
  action: 'CREATE' | 'UPDATE' | 'DELETE'
  table: string
  timestamp: string
  user: string
  recordId?: number
  before?: Record<string, any>
  after?: Record<string, any>
}

const auditLogs: AuditLog[] = [
  {
    id: 1,
    action: 'CREATE',
    table: 'users',
    timestamp: '2024-05-30 14:30:00',
    user: 'admin@example.com',
    recordId: 123,
    after: { id: 123, name: 'Alice Johnson', email: 'alice@example.com', status: 'Active' },
  },
  {
    id: 2,
    action: 'UPDATE',
    table: 'users',
    timestamp: '2024-05-30 13:15:00',
    user: 'admin@example.com',
    recordId: 45,
    before: { id: 45, name: 'Bob Smith', email: 'bob@example.com', status: 'Active' },
    after: { id: 45, name: 'Bob Smith', email: 'bob.smith@example.com', status: 'Active' },
  },
  {
    id: 3,
    action: 'DELETE',
    table: 'orders',
    timestamp: '2024-05-29 10:45:00',
    user: 'dev@example.com',
    recordId: 789,
    before: { id: 789, user_id: 12, total: 450.00, status: 'Cancelled' },
  },
  {
    id: 4,
    action: 'UPDATE',
    table: 'products',
    timestamp: '2024-05-28 16:20:00',
    user: 'manager@example.com',
    recordId: 56,
    before: { id: 56, name: 'Laptop', price: 999.99 },
    after: { id: 56, name: 'Laptop Pro', price: 1299.99 },
  },
]

export default function AuditLogs() {
  const [searchTerm, setSearchTerm] = useState('')
  const [actionFilter, setActionFilter] = useState('all')
  const [selectedLog, setSelectedLog] = useState<AuditLog | null>(null)

  const filteredLogs = auditLogs.filter((log) => {
    const matchesSearch =
      log.table.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.user.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesAction = actionFilter === 'all' || log.action === actionFilter
    return matchesSearch && matchesAction
  })

  const getActionColor = (action: string) => {
    switch (action) {
      case 'CREATE':
        return 'bg-green-600'
      case 'UPDATE':
        return 'bg-blue-600'
      case 'DELETE':
        return 'bg-red-600'
      default:
        return 'bg-gray-600'
    }
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="border-b border-border p-6 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Audit Logs</h1>
          <p className="text-muted-foreground">Track all database changes with detailed before/after payloads.</p>
        </div>
        <Button variant="outline">
          <Download className="w-4 h-4 mr-2" />
          Export CSV
        </Button>
      </div>

      {/* Filters */}
      <div className="border-b border-border px-6 py-3 flex items-center gap-3 bg-secondary/30">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search by table or user..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-3 py-2 rounded-md border border-input bg-background text-foreground placeholder-muted-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>
        <select
          value={actionFilter}
          onChange={(e) => setActionFilter(e.target.value)}
          className="px-3 py-2 rounded-md border border-input bg-background text-foreground text-sm"
        >
          <option value="all">All Actions</option>
          <option value="CREATE">Create</option>
          <option value="UPDATE">Update</option>
          <option value="DELETE">Delete</option>
        </select>
        <Button variant="outline" size="sm">
          <Calendar className="w-4 h-4 mr-2" />
          Last 7 days
        </Button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-hidden flex gap-4 p-4">
        {/* Logs List */}
        <div className="flex-1 flex flex-col min-h-0">
          <Card className="flex-1 flex flex-col">
            <CardContent className="flex-1 overflow-auto p-0">
              <div className="divide-y divide-border">
                {filteredLogs.map((log, idx) => (
                  <motion.div
                    key={log.id}
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.05 }}
                    onClick={() => setSelectedLog(log)}
                    className={`p-4 cursor-pointer transition-colors ${
                      selectedLog?.id === log.id ? 'bg-primary/10' : 'hover:bg-secondary/50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4 flex-1">
                        <div
                          className={`px-3 py-1 rounded text-xs font-semibold text-white ${getActionColor(
                            log.action
                          )}`}
                        >
                          {log.action}
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-foreground">{log.table}</p>
                          <p className="text-xs text-muted-foreground">{log.user}</p>
                        </div>
                      </div>
                      <span className="text-xs text-muted-foreground">{log.timestamp}</span>
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Payload Viewer */}
        {selectedLog && (
          <div className="flex-1 flex flex-col min-h-0">
            <Tabs defaultValue="changes" className="flex-1 flex flex-col">
              <TabsList className="w-full justify-start border-b rounded-none bg-transparent">
                <TabsTrigger value="changes">Changes</TabsTrigger>
                <TabsTrigger value="before">Before</TabsTrigger>
                <TabsTrigger value="after">After</TabsTrigger>
              </TabsList>

              <TabsContent value="changes" className="flex-1 overflow-auto">
                <div className="p-4 space-y-2">
                  {selectedLog.action === 'UPDATE' && selectedLog.before && selectedLog.after ? (
                    <div className="space-y-2">
                      {Object.keys(selectedLog.after).map((key) => {
                        const before = selectedLog.before?.[key]
                        const after = selectedLog.after?.[key]
                        if (before !== after) {
                          return (
                            <div key={key} className="p-2 bg-secondary rounded text-xs space-y-1">
                              <p className="font-medium">{key}</p>
                              <div className="flex items-center gap-2">
                                <span className="text-red-600">{before}</span>
                                <span className="text-muted-foreground">→</span>
                                <span className="text-green-600">{after}</span>
                              </div>
                            </div>
                          )
                        }
                        return null
                      })}
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">No changes to display</p>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="before" className="flex-1 overflow-auto">
                <pre className="p-4 bg-secondary rounded text-xs overflow-auto max-h-full">
                  {JSON.stringify(selectedLog.before || {}, null, 2)}
                </pre>
              </TabsContent>

              <TabsContent value="after" className="flex-1 overflow-auto">
                <pre className="p-4 bg-secondary rounded text-xs overflow-auto max-h-full">
                  {JSON.stringify(selectedLog.after || {}, null, 2)}
                </pre>
              </TabsContent>
            </Tabs>
          </div>
        )}
      </div>
    </div>
  )
}
