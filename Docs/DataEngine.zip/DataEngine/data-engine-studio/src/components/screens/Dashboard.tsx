import { useEffect, useState } from 'react'
import { BarChart3, Database, Table2, Zap } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { getDbInfo } from '@/services/api/connections'
import { listTables } from '@/services/api/schema'
import { getAuditLog } from '@/services/api/audit'

const recentActivity = [
  { action: 'Created table', entity: 'products', time: '2 hours ago' },
  { action: 'Updated schema', entity: 'orders', time: '1 day ago' },
  { action: 'Executed procedure', entity: 'sp_GetProducts', time: '3 days ago' },
  { action: 'Refreshed cache', entity: 'schema', time: '1 week ago' },
]

export default function Dashboard() {
  const [connections, setConnections] = useState(0)
  const [tables, setTables] = useState(0)
  const [auditEntries, setAuditEntries] = useState(0)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const loadMetrics = async () => {
      try {
        const info = await getDbInfo()
        const schema = await listTables()
        const audit = await getAuditLog(1, 10)

        setConnections(Object.keys(info.connections).length)
        setTables(schema.tables.length)
        setAuditEntries(audit.entries.length)
      } catch {
        // keep the defaults if backend is unavailable
      } finally {
        setIsLoading(false)
      }
    }

    loadMetrics()
  }, [])

  const stats = [
    {
      icon: Database,
      label: 'Connections',
      value: isLoading ? '…' : String(connections),
      trend: '+1 this week',
    },
    {
      icon: Table2,
      label: 'Tables',
      value: isLoading ? '…' : String(tables),
      trend: '+4 this month',
    },
    {
      icon: Zap,
      label: 'Procedures',
      value: '1',
      trend: '+0 this week',
    },
    {
      icon: BarChart3,
      label: 'Audit Entries',
      value: isLoading ? '…' : String(auditEntries),
      trend: '+2 today',
    },
  ]

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="border-b border-border p-6">
        <h1 className="text-3xl font-bold text-foreground mb-2">Dashboard</h1>
        <p className="text-muted-foreground">Welcome to DataEngine Studio. Manage your database infrastructure.</p>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto">
        <div className="p-6 space-y-6">
          {/* Metrics Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {stats.map((stat) => {
              const Icon = stat.icon
              return (
                <Card key={stat.label} className="hover:border-primary/50 transition-colors">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-sm font-medium text-muted-foreground">{stat.label}</CardTitle>
                      <Icon className="w-4 h-4 text-primary" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-foreground">{stat.value}</div>
                    <p className="text-xs text-muted-foreground mt-1">{stat.trend}</p>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          {/* Main Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Recent Activity */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentActivity.map((activity, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between py-3 border-b border-border last:border-b-0"
                    >
                      <div>
                        <p className="text-sm font-medium text-foreground">{activity.action}</p>
                        <p className="text-xs text-muted-foreground">{activity.entity}</p>
                      </div>
                      <span className="text-xs text-muted-foreground">{activity.time}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full" size="sm">
                  Add Connection
                </Button>
                <Button variant="outline" className="w-full" size="sm">
                  Create Table
                </Button>
                <Button variant="outline" className="w-full" size="sm">
                  Run Query
                </Button>
                <Button variant="outline" className="w-full" size="sm">
                  View Logs
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Schema Cache Health */}
          <Card>
            <CardHeader>
              <CardTitle>Schema Cache Health</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">Cache Hit Rate</span>
                    <span className="text-sm text-primary font-semibold">94.2%</span>
                  </div>
                  <div className="h-2 bg-secondary rounded-full overflow-hidden">
                    <div className="h-full w-[94.2%] bg-primary rounded-full" />
                  </div>
                </div>
                <div className="flex justify-between text-xs text-muted-foreground pt-2">
                  <span>Last refresh: 2 minutes ago</span>
                  <Button variant="link" size="sm" className="h-auto p-0">
                    Refresh Now
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
