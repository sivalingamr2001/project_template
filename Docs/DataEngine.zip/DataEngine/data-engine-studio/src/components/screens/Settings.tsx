import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'

export default function Settings() {
  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="border-b border-border p-6">
        <h1 className="text-3xl font-bold text-foreground mb-2">Settings</h1>
        <p className="text-muted-foreground">Configure DataEngine Studio preferences.</p>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-6 max-w-3xl">
        <div className="space-y-6">
          {/* Cache Settings */}
          <Card>
            <CardHeader>
              <CardTitle>Cache Settings</CardTitle>
              <CardDescription>Configure schema caching behavior</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="flex items-center justify-between mb-3">
                  <span className="text-sm font-medium text-foreground">Enable Cache</span>
                  <input type="checkbox" defaultChecked className="w-4 h-4" />
                </label>
              </div>
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">
                  Cache TTL (seconds)
                </label>
                <input
                  type="number"
                  defaultValue="3600"
                  className="w-full px-3 py-2 rounded-md border border-input bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
              <div>
                <label className="flex items-center justify-between mb-3">
                  <span className="text-sm font-medium text-foreground">Auto Refresh</span>
                  <input type="checkbox" className="w-4 h-4" />
                </label>
              </div>
            </CardContent>
          </Card>

          {/* Data Grid Settings */}
          <Card>
            <CardHeader>
              <CardTitle>Data Grid</CardTitle>
              <CardDescription>Configure data grid display preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">
                  Default Page Size
                </label>
                <select className="w-full px-3 py-2 rounded-md border border-input bg-background text-foreground">
                  <option>25</option>
                  <option>50</option>
                  <option>100</option>
                  <option>250</option>
                </select>
              </div>
              <div>
                <label className="flex items-center justify-between mb-3">
                  <span className="text-sm font-medium text-foreground">Enable Inline Editing</span>
                  <input type="checkbox" defaultChecked className="w-4 h-4" />
                </label>
              </div>
            </CardContent>
          </Card>

          {/* Audit Settings */}
          <Card>
            <CardHeader>
              <CardTitle>Audit & Logging</CardTitle>
              <CardDescription>Control audit log settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="flex items-center justify-between mb-3">
                  <span className="text-sm font-medium text-foreground">Enable Audit Logging</span>
                  <input type="checkbox" defaultChecked className="w-4 h-4" />
                </label>
              </div>
              <div>
                <label className="flex items-center justify-between mb-3">
                  <span className="text-sm font-medium text-foreground">Log Before/After Payloads</span>
                  <input type="checkbox" defaultChecked className="w-4 h-4" />
                </label>
              </div>
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">
                  Retention Period (days)
                </label>
                <input
                  type="number"
                  defaultValue="90"
                  className="w-full px-3 py-2 rounded-md border border-input bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
            </CardContent>
          </Card>

          {/* Query Settings */}
          <Card>
            <CardHeader>
              <CardTitle>Query Execution</CardTitle>
              <CardDescription>Configure query behavior</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="flex items-center justify-between mb-3">
                  <span className="text-sm font-medium text-foreground">Enable Raw SQL</span>
                  <input type="checkbox" defaultChecked className="w-4 h-4" />
                </label>
              </div>
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">
                  Query Timeout (seconds)
                </label>
                <input
                  type="number"
                  defaultValue="30"
                  className="w-full px-3 py-2 rounded-md border border-input bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
            </CardContent>
          </Card>

          {/* Theme Settings */}
          <Card>
            <CardHeader>
              <CardTitle>Theme</CardTitle>
              <CardDescription>Appearance preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">
                  Color Scheme
                </label>
                <select className="w-full px-3 py-2 rounded-md border border-input bg-background text-foreground">
                  <option>Auto (System)</option>
                  <option>Light</option>
                  <option>Dark</option>
                </select>
              </div>
            </CardContent>
          </Card>

          {/* Save Button */}
          <div className="flex gap-2">
            <Button>Save Settings</Button>
            <Button variant="outline">Reset to Defaults</Button>
          </div>
        </div>
      </div>
    </div>
  )
}
