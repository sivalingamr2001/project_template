import { useState } from 'react'
import { Plus, Search, Download, RefreshCw } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { motion } from 'framer-motion'

interface Row {
  id: number
  name: string
  email: string
  status: string
  created_at: string
}

export default function DataExplorer() {
  const [selectedTable] = useState('users')
  const [searchTerm, setSearchTerm] = useState('')
  const [rows] = useState<Row[]>([
    { id: 1, name: 'Alice Johnson', email: 'alice@example.com', status: 'Active', created_at: '2024-01-10' },
    { id: 2, name: 'Bob Smith', email: 'bob@example.com', status: 'Active', created_at: '2024-01-15' },
    { id: 3, name: 'Charlie Brown', email: 'charlie@example.com', status: 'Inactive', created_at: '2024-01-20' },
    { id: 4, name: 'Diana Prince', email: 'diana@example.com', status: 'Active', created_at: '2024-02-01' },
    { id: 5, name: 'Eve Wilson', email: 'eve@example.com', status: 'Active', created_at: '2024-02-15' },
  ])

  const filteredRows = rows.filter((row) =>
    Object.values(row).some((val) => String(val).toLowerCase().includes(searchTerm.toLowerCase()))
  )

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="border-b border-border p-6 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Data Explorer</h1>
          <p className="text-muted-foreground">Browse and edit {selectedTable} data with inline editing.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline">
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          <Button>
            <Plus className="w-4 h-4 mr-2" />
            Insert Row
          </Button>
        </div>
      </div>

      {/* Toolbar */}
      <div className="border-b border-border px-6 py-3 flex items-center gap-3 bg-secondary/30">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search all columns..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-3 py-2 rounded-md border border-input bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary text-sm"
          />
        </div>
        <select className="px-3 py-2 rounded-md border border-input bg-background text-foreground text-sm">
          <option>All rows ({rows.length})</option>
          <option>Last 100</option>
          <option>Last 1000</option>
        </select>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-hidden flex flex-col p-4">
        <Card className="flex-1 flex flex-col">
          <CardContent className="flex-1 overflow-x-auto p-0">
            {filteredRows.length === 0 ? (
              <div className="flex items-center justify-center h-full text-center">
                <div>
                  <p className="text-muted-foreground mb-4">No rows found</p>
                  <Button variant="outline" size="sm">
                    Clear Filters
                  </Button>
                </div>
              </div>
            ) : (
              <table className="w-full text-sm">
                <thead className="sticky top-0 bg-secondary border-b border-border">
                  <tr>
                    <th className="px-4 py-2 text-left font-medium text-foreground w-12">
                      <input type="checkbox" />
                    </th>
                    <th className="px-4 py-2 text-left font-medium text-foreground">ID</th>
                    <th className="px-4 py-2 text-left font-medium text-foreground">Name</th>
                    <th className="px-4 py-2 text-left font-medium text-foreground">Email</th>
                    <th className="px-4 py-2 text-left font-medium text-foreground">Status</th>
                    <th className="px-4 py-2 text-left font-medium text-foreground">Created</th>
                    <th className="px-4 py-2 text-left font-medium text-foreground w-12">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {filteredRows.map((row, idx) => (
                    <motion.tr
                      key={row.id}
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.05 }}
                      className="hover:bg-secondary/50 transition-colors"
                    >
                      <td className="px-4 py-2">
                        <input type="checkbox" />
                      </td>
                      <td className="px-4 py-2 text-muted-foreground">{row.id}</td>
                      <td className="px-4 py-2 font-medium">{row.name}</td>
                      <td className="px-4 py-2 text-sm text-muted-foreground">{row.email}</td>
                      <td className="px-4 py-2">
                        <span
                          className={`inline-flex items-center px-2 py-1 rounded text-xs font-medium ${
                            row.status === 'Active'
                              ? 'bg-green-500/20 text-green-700 dark:text-green-400'
                              : 'bg-gray-500/20 text-gray-700 dark:text-gray-400'
                          }`}
                        >
                          {row.status}
                        </span>
                      </td>
                      <td className="px-4 py-2 text-sm text-muted-foreground">{row.created_at}</td>
                      <td className="px-4 py-2">
                        <Button variant="ghost" size="sm" className="text-xs">
                          Edit
                        </Button>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
