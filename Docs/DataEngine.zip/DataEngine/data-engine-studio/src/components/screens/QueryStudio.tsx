import { useState } from 'react'
import { Play, Save } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { CodeEditor } from '@/components/ui/CodeEditor'
import { motion } from 'framer-motion'
import { queryTable } from '@/services/api/query'
import { saveQueryDefinition } from '@/services/api/queryDefinitions'

interface QueryRequest {
  columns?: string[]
  filters?: Array<Record<string, unknown>>
  sort?: Array<Record<string, unknown>>
  pagination?: { page: number; pageSize: number }
  includeCount?: boolean
}

export default function QueryStudio() {
  const [tableName, setTableName] = useState('products')
  const [queryJson, setQueryJson] = useState(JSON.stringify({
    columns: ['id', 'name', 'price'],
    filters: [{ column: 'is_active', operator: 'Equals', value: 1 }],
    sort: [{ column: 'price', direction: 'Ascending' }],
    pagination: { page: 1, pageSize: 25 },
    includeCount: true,
  }, null, 2))
  const [definitionKey, setDefinitionKey] = useState('active-products')
  const [definitionDescription, setDefinitionDescription] = useState('Active products sorted by price')
  const [results, setResults] = useState<Array<Record<string, unknown>>>([])
  const [isRunning, setIsRunning] = useState(false)
  const [executionTime, setExecutionTime] = useState<number | null>(null)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)
  const [saveMessage, setSaveMessage] = useState<string | null>(null)

  const handleRun = async () => {
    setIsRunning(true)
    setErrorMessage(null)
    setSaveMessage(null)

    try {
      const request = JSON.parse(queryJson) as QueryRequest
      const response = await queryTable(tableName, request)
      setResults(response.data)
      setExecutionTime(response.executionTime ? Number(response.executionTime.toString().replace(/[a-zA-Z\s]/g, '')) : null)
    } catch (error) {
      setErrorMessage('Unable to execute query. Check the backend or the query JSON payload.')
    } finally {
      setIsRunning(false)
    }
  }

  const handleSaveDefinition = async () => {
    setIsRunning(true)
    setSaveMessage(null)
    setErrorMessage(null)

    try {
      const request = JSON.parse(queryJson) as QueryRequest
      await saveQueryDefinition({
        definitionKey,
        tableName,
        description: definitionDescription,
        queryJson: JSON.stringify(request),
      })
      setSaveMessage(`Saved query definition '${definitionKey}'.`)
    } catch (error) {
      setErrorMessage('Unable to save query definition. Check the backend or the JSON syntax.')
    } finally {
      setIsRunning(false)
    }
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="border-b border-border p-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Query Studio</h1>
          <p className="text-muted-foreground">Build, test, and save dynamic query definitions.</p>
        </div>
        <div className="grid gap-2 sm:grid-cols-3">
          <input
            type="text"
            value={tableName}
            onChange={(e) => setTableName(e.target.value)}
            placeholder="table name"
            className="px-3 py-2 rounded-md border border-input bg-background text-sm"
          />
          <input
            type="text"
            value={definitionKey}
            onChange={(e) => setDefinitionKey(e.target.value)}
            placeholder="definition key"
            className="px-3 py-2 rounded-md border border-input bg-background text-sm"
          />
          <input
            type="text"
            value={definitionDescription}
            onChange={(e) => setDefinitionDescription(e.target.value)}
            placeholder="description"
            className="px-3 py-2 rounded-md border border-input bg-background text-sm"
          />
        </div>
      </div>

      <div className="border-b border-border p-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2 flex-wrap">
          <Button variant="outline" onClick={handleSaveDefinition} disabled={isRunning}>
            <Save className="w-4 h-4 mr-2" />
            Save Definition
          </Button>
          <motion.div whileTap={{ scale: 0.95 }}>
            <Button onClick={handleRun} disabled={isRunning}>
              <Play className="w-4 h-4 mr-2" />
              {isRunning ? 'Running...' : 'Run'}
            </Button>
          </motion.div>
        </div>
        {saveMessage ? <div className="text-sm text-foreground">{saveMessage}</div> : null}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-hidden flex flex-col lg:flex-row gap-4 p-4">
        <div className="flex-1 flex flex-col min-h-0">
          <Card className="flex-1 flex flex-col">
            <CardHeader className="pb-3 border-b border-border">
              <CardTitle className="text-sm">Query Request JSON</CardTitle>
            </CardHeader>
            <CardContent className="flex-1 p-0">
              <CodeEditor value={queryJson} onChange={setQueryJson} language="json" height="100%" />
            </CardContent>
            {errorMessage ? (
              <div className="p-3 text-sm text-destructive bg-destructive/10 border-t border-destructive/20">
                {errorMessage}
              </div>
            ) : null}
          </Card>
        </div>

        <div className="flex-1 flex flex-col min-h-0">
          <Tabs defaultValue="results" className="flex-1 flex flex-col">
            <TabsList className="w-full justify-start border-b rounded-none bg-transparent">
              <TabsTrigger value="results">Results ({results.length})</TabsTrigger>
              <TabsTrigger value="metrics">Metrics</TabsTrigger>
              <TabsTrigger value="errors">Errors</TabsTrigger>
            </TabsList>

            <TabsContent value="results" className="flex-1 overflow-auto">
              <div className="p-4">
                {results.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <p className="text-sm">Run a query to see results</p>
                  </div>
                ) : (
                  <div className="border border-border rounded-lg overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead className="bg-secondary border-b border-border">
                        <tr>
                          {Object.keys(results[0] || {}).map((key) => (
                            <th key={key} className="px-4 py-2 text-left font-medium">
                              {key}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {results.map((row, idx) => (
                          <tr key={idx} className="border-b border-border hover:bg-secondary/50">
                            {Object.values(row).map((value, colIdx) => (
                              <td key={colIdx} className="px-4 py-2">
                                {value === null || value === undefined ? '-' : String(value)}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="metrics" className="flex-1 overflow-auto">
              <div className="p-4 space-y-3">
                <div className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                  <span className="text-sm font-medium">Rows Returned</span>
                  <span className="text-lg font-bold">{results.length}</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                  <span className="text-sm font-medium">Execution Time</span>
                  <span className="text-lg font-bold">{executionTime ?? 0}ms</span>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="errors" className="flex-1 overflow-auto">
              <div className="p-4 text-center text-muted-foreground">
                {errorMessage ? <p className="text-sm text-destructive">{errorMessage}</p> : <p className="text-sm">No errors</p>}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
