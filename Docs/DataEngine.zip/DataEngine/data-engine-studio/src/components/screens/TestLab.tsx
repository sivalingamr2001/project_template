import { useState } from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Play, CheckCircle2 } from 'lucide-react'
import { CodeEditor } from '@/components/ui/CodeEditor'
import { motion } from 'framer-motion'
import { queryTable } from '@/services/api/query'
import { executeProcedure } from '@/services/api/procedures'

export default function TestLab() {
  const [queryRequest, setQueryRequest] = useState(JSON.stringify({
    columns: ['id', 'name', 'email'],
    filters: [{ column: 'id', operator: 'Equals', value: 1 }],
    sort: [{ column: 'id', direction: 'Ascending' }],
    pagination: { page: 1, pageSize: 25 },
    includeCount: true,
  }, null, 2))
  const [procParams, setProcParams] = useState(JSON.stringify({
    procedureName: 'sp_get_users',
    type: 'Read',
    parameters: [{ name: 'p_status', value: 'active', direction: 'Input' }],
  }, null, 2))
  const [payloadJSON, setPayloadJSON] = useState(JSON.stringify({ status: 'active', timestamp: '2024-05-30T12:00:00Z' }, null, 2))
  const [results, setResults] = useState<any>(null)
  const [isRunning, setIsRunning] = useState(false)
  const [metrics, setMetrics] = useState({ duration: 0, rowsAffected: 0, cacheHit: false })
  const [errorMessage, setErrorMessage] = useState<string | null>(null)

  const handleExecute = async (type: string) => {
    setIsRunning(true)
    setErrorMessage(null)

    try {
      if (type === 'query') {
        const request = JSON.parse(queryRequest)
        const response = await queryTable('users', request)
        setResults({ data: response.data, totalCount: response.totalCount ?? 0 })
        setMetrics({ duration: Number(response.executionTime?.replace(/[a-zA-Z\s]/g, '') ?? 0), rowsAffected: response.data.length, cacheHit: false })
      } else if (type === 'procedure') {
        const request = JSON.parse(procParams)
        const response = await executeProcedure(request)
        setResults(response)
        setMetrics({ duration: Number(response.executionTime?.replace(/[a-zA-Z\s]/g, '') ?? 0), rowsAffected: response.affectedRows ?? 0, cacheHit: false })
      } else if (type === 'payload') {
        const parsed = JSON.parse(payloadJSON)
        setResults({ valid: true, parsed })
        setMetrics({ duration: 0, rowsAffected: 0, cacheHit: false })
      } else {
        setResults({ message: 'CRUD operations are not yet exposed by the backend sample.' })
      }
    } catch (error) {
      setErrorMessage('Request failed. Verify JSON payload and backend availability.')
      setResults(null)
    } finally {
      setIsRunning(false)
    }
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="border-b border-border p-6">
        <h1 className="text-3xl font-bold text-foreground mb-2">Test Lab</h1>
        <p className="text-muted-foreground">Test query and procedure payloads against the backend.</p>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-hidden flex flex-col p-4">
        <Tabs defaultValue="crud" className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="crud">CRUD Tester</TabsTrigger>
            <TabsTrigger value="query">Query Tester</TabsTrigger>
            <TabsTrigger value="procedure">Procedure Tester</TabsTrigger>
            <TabsTrigger value="payload">Payload Tester</TabsTrigger>
          </TabsList>

          {/* CRUD Tester */}
          <TabsContent value="crud" className="flex-1 flex flex-col gap-4 mt-4 overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 flex-1 overflow-hidden">
              <Card className="flex flex-col overflow-hidden">
                <CardHeader className="pb-3 border-b border-border">
                  <CardTitle className="text-sm">CRUD Payload</CardTitle>
                </CardHeader>
                <CardContent className="flex-1 p-0">
                  <CodeEditor value={queryRequest} onChange={setQueryRequest} language="json" height="100%" />
                </CardContent>
              </Card>

              <Card className="flex flex-col">
                <CardHeader className="pb-3 border-b border-border">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm">Result</CardTitle>
                    <motion.div whileTap={{ scale: 0.95 }}>
                      <Button variant="ghost" size="sm" onClick={() => handleExecute('crud')} disabled={isRunning}>
                        <Play className="w-4 h-4 mr-2" />
                        {isRunning ? 'Running...' : 'Execute'}
                      </Button>
                    </motion.div>
                  </div>
                </CardHeader>
                <CardContent className="flex-1 overflow-auto space-y-3">
                  {results ? (
                    <>
                      <div className="flex items-center gap-2 p-3 bg-green-500/10 rounded-lg border border-green-500/20">
                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                        <span className="text-sm font-medium">Backend CRUD not implemented in sample API</span>
                      </div>
                      <div className="text-xs bg-secondary p-3 rounded-lg font-mono overflow-auto max-h-40">
                        <pre>{JSON.stringify(results, null, 2)}</pre>
                      </div>
                    </>
                  ) : (
                    <p className="text-sm text-muted-foreground py-8 text-center">This sample backend exposes query and procedure APIs, but no generic CRUD endpoint.</p>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Query Tester */}
          <TabsContent value="query" className="flex-1 flex flex-col gap-4 mt-4 overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 flex-1 overflow-hidden">
              <Card className="flex flex-col overflow-hidden">
                <CardHeader className="pb-3 border-b border-border">
                  <CardTitle className="text-sm">Query Request</CardTitle>
                </CardHeader>
                <CardContent className="flex-1 p-0">
                  <CodeEditor value={queryRequest} onChange={setQueryRequest} language="json" height="100%" />
                </CardContent>
              </Card>

              <Card className="flex flex-col">
                <CardHeader className="pb-3 border-b border-border">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm">Result</CardTitle>
                    <motion.div whileTap={{ scale: 0.95 }}>
                      <Button variant="ghost" size="sm" onClick={() => handleExecute('query')} disabled={isRunning}>
                        <Play className="w-4 h-4 mr-2" />
                        {isRunning ? 'Running...' : 'Execute'}
                      </Button>
                    </motion.div>
                  </div>
                </CardHeader>
                <CardContent className="flex-1 overflow-auto space-y-3">
                  {errorMessage ? (
                    <div className="text-sm text-destructive p-3 bg-destructive/10 rounded-lg border border-destructive/20">{errorMessage}</div>
                  ) : null}
                  {results ? (
                    <>
                      <div className="flex items-center gap-2 p-3 bg-green-500/10 rounded-lg border border-green-500/20">
                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                        <span className="text-sm font-medium">Query executed</span>
                      </div>
                      <div className="text-xs bg-secondary p-3 rounded-lg font-mono overflow-auto max-h-40">
                        <pre>{JSON.stringify(results, null, 2)}</pre>
                      </div>
                      <div className="grid grid-cols-2 gap-2 pt-2">
                        <div className="p-2 bg-secondary rounded text-center">
                          <p className="text-xs text-muted-foreground">Duration</p>
                          <p className="text-sm font-bold">{metrics.duration.toFixed(0)}ms</p>
                        </div>
                        <div className="p-2 bg-secondary rounded text-center">
                          <p className="text-xs text-muted-foreground">Rows</p>
                          <p className="text-sm font-bold">{metrics.rowsAffected}</p>
                        </div>
                      </div>
                    </>
                  ) : (
                    <p className="text-sm text-muted-foreground py-8 text-center">Execute a query request to see backend output.</p>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Procedure Tester */}
          <TabsContent value="procedure" className="flex-1 flex flex-col gap-4 mt-4 overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 flex-1 overflow-hidden">
              <Card className="flex flex-col overflow-hidden">
                <CardHeader className="pb-3 border-b border-border">
                  <CardTitle className="text-sm">Procedure Request</CardTitle>
                </CardHeader>
                <CardContent className="flex-1 p-0">
                  <CodeEditor value={procParams} onChange={setProcParams} language="json" height="100%" />
                </CardContent>
              </Card>

              <Card className="flex flex-col">
                <CardHeader className="pb-3 border-b border-border">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm">Execution Result</CardTitle>
                    <motion.div whileTap={{ scale: 0.95 }}>
                      <Button variant="ghost" size="sm" onClick={() => handleExecute('procedure')} disabled={isRunning}>
                        <Play className="w-4 h-4 mr-2" />
                        {isRunning ? 'Running...' : 'Execute'}
                      </Button>
                    </motion.div>
                  </div>
                </CardHeader>
                <CardContent className="flex-1 overflow-auto space-y-3">
                  {errorMessage ? (
                    <div className="text-sm text-destructive p-3 bg-destructive/10 rounded-lg border border-destructive/20">{errorMessage}</div>
                  ) : null}
                  {results ? (
                    <>
                      <div className="flex items-center gap-2 p-3 bg-green-500/10 rounded-lg border border-green-500/20">
                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                        <span className="text-sm font-medium">Procedure executed</span>
                      </div>
                      <div className="text-xs bg-secondary p-3 rounded-lg font-mono overflow-auto max-h-40">
                        <pre>{JSON.stringify(results, null, 2)}</pre>
                      </div>
                      <div className="grid grid-cols-2 gap-2 pt-2">
                        <div className="p-2 bg-secondary rounded text-center">
                          <p className="text-xs text-muted-foreground">Duration</p>
                          <p className="text-sm font-bold">{metrics.duration.toFixed(0)}ms</p>
                        </div>
                        <div className="p-2 bg-secondary rounded text-center">
                          <p className="text-xs text-muted-foreground">Rows Affected</p>
                          <p className="text-sm font-bold">{metrics.rowsAffected}</p>
                        </div>
                      </div>
                    </>
                  ) : (
                    <p className="text-sm text-muted-foreground py-8 text-center">Execute a procedure request to see backend output.</p>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Payload Tester */}
          <TabsContent value="payload" className="flex-1 flex flex-col gap-4 mt-4 overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 flex-1 overflow-hidden">
              <Card className="flex flex-col overflow-hidden">
                <CardHeader className="pb-3 border-b border-border">
                  <CardTitle className="text-sm">JSON Payload</CardTitle>
                </CardHeader>
                <CardContent className="flex-1 p-0">
                  <CodeEditor value={payloadJSON} onChange={setPayloadJSON} language="json" height="100%" />
                </CardContent>
              </Card>

              <Card className="flex flex-col">
                <CardHeader className="pb-3 border-b border-border">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm">Validation Result</CardTitle>
                    <motion.div whileTap={{ scale: 0.95 }}>
                      <Button variant="ghost" size="sm" onClick={() => handleExecute('payload')} disabled={isRunning}>
                        <Play className="w-4 h-4 mr-2" />
                        {isRunning ? 'Running...' : 'Validate'}
                      </Button>
                    </motion.div>
                  </div>
                </CardHeader>
                <CardContent className="flex-1 overflow-auto space-y-3">
                  {results ? (
                    <>
                      <div className="flex items-center gap-2 p-3 bg-green-500/10 rounded-lg border border-green-500/20">
                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                        <span className="text-sm font-medium">Valid JSON</span>
                      </div>
                      <div className="text-xs bg-secondary p-3 rounded-lg font-mono overflow-auto max-h-40">
                        <pre>{JSON.stringify(results, null, 2)}</pre>
                      </div>
                    </>
                  ) : (
                    <p className="text-sm text-muted-foreground py-8 text-center">Validate payload JSON to view parsed output.</p>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
