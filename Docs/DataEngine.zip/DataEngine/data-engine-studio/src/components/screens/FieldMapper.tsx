import { useEffect, useState } from 'react'
import { RefreshCw, Plus, Save } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { motion } from 'framer-motion'
import { getFieldMappings, addFieldMapping } from '@/services/api/settings'
import { listTables } from '@/services/api/schema'

interface FieldMappingRow {
  id: string
  alias: string
  columnName: string
  tableName: string
  direction: 'both' | 'in' | 'out'
  type: string
  required: boolean
}

export default function FieldMapper() {
  const [selectedTable, setSelectedTable] = useState('users')
  const [availableTables, setAvailableTables] = useState<string[]>([])
  const [mappings, setMappings] = useState<FieldMappingRow[]>([
    { id: '1', alias: 'user_id', columnName: 'id', tableName: 'users', direction: 'both', type: 'INT', required: true },
    { id: '2', alias: 'full_name', columnName: 'name', tableName: 'users', direction: 'both', type: 'VARCHAR(255)', required: true },
  ])
  const [savedMappings, setSavedMappings] = useState<FieldMappingRow[]>([])
  const [isSaving, setIsSaving] = useState(false)
  const [saveMessage, setSaveMessage] = useState<string | null>(null)
  const [loadError, setLoadError] = useState<string | null>(null)

  useEffect(() => {
    const loadTablesAndMappings = async () => {
      try {
        const [schemaResponse, mappingResponse] = await Promise.all([listTables(), getFieldMappings()])
        setAvailableTables(schemaResponse.tables)
        setSavedMappings(mappingResponse.mappings.map((mapping) => ({
          id: `${mapping.tableName}-${mapping.columnName}-${mapping.alias}`,
          alias: mapping.alias,
          columnName: mapping.columnName,
          tableName: mapping.tableName,
          direction: mapping.direction,
          type: 'UNKNOWN',
          required: mapping.direction !== 'out',
        })))
      } catch (error) {
        setLoadError('Unable to load table or mapping metadata from the backend.')
      }
    }

    loadTablesAndMappings()
  }, [])

  const handleAutoMap = () => {
    const newMappings = mappings.map((m) => ({
      ...m,
      columnName: m.alias.replace(/_/g, ''),
    }))
    setMappings(newMappings)
  }

  const updateMapping = (id: string, field: keyof FieldMappingRow, value: any) => {
    setMappings((current) => current.map((m) => (m.id === id ? { ...m, [field]: value } : m)))
  }

  const addMappingRow = () => {
    setMappings((current) => [
      ...current,
      {
        id: Date.now().toString(),
        tableName: selectedTable,
        alias: '',
        columnName: '',
        direction: 'both',
        type: 'VARCHAR(255)',
        required: false,
      },
    ])
  }

  const saveMapping = async (mapping: FieldMappingRow) => {
    setIsSaving(true)
    setSaveMessage(null)

    try {
      await addFieldMapping({
        tableName: mapping.tableName,
        columnName: mapping.columnName,
        alias: mapping.alias,
        direction: mapping.direction,
      })

      setSaveMessage(`Saved mapping ${mapping.alias} → ${mapping.columnName}`)
      const response = await getFieldMappings()
      setSavedMappings(response.mappings.map((saved) => ({
        id: `${saved.tableName}-${saved.columnName}-${saved.alias}`,
        alias: saved.alias,
        columnName: saved.columnName,
        tableName: saved.tableName,
        direction: saved.direction,
        type: 'UNKNOWN',
        required: saved.direction !== 'out',
      })))
    } catch (error) {
      setSaveMessage('Unable to save mapping. Check the backend and try again.')
    } finally {
      setIsSaving(false)
    }
  }

  const handleTableChange = (tableName: string) => {
    setSelectedTable(tableName)
    setMappings((current) => current.map((mapping) => ({ ...mapping, tableName })))
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="border-b border-border p-6 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Field Mapper</h1>
          <p className="text-muted-foreground">Map API fields to database columns with intelligent type conversion.</p>
        </div>
        <Button>
          Export Mapping
        </Button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-hidden flex gap-4 p-4">
        {/* Mapping Grid */}
        <div className="flex-1 flex flex-col min-h-0">
          <Card className="flex-1 flex flex-col">
            <CardHeader className="pb-3 border-b border-border">
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-xs text-muted-foreground">Table</label>
                  <select
                    value={selectedTable}
                    onChange={(e) => setSelectedTable(e.target.value)}
                    className="mt-1 px-2 py-1 rounded border border-border bg-background text-sm"
                  >
                    <option>users</option>
                    <option>orders</option>
                    <option>products</option>
                  </select>
                </div>
                <Button variant="outline" size="sm" onClick={handleAutoMap}>
                  <RefreshCw className="w-4 h-4 mr-1" />
                  Auto Map
                </Button>
                <Button variant="outline" size="sm" onClick={addMappingRow}>
                  <Plus className="w-4 h-4 mr-1" />
                  Add Row
                </Button>
              </div>
            </CardHeader>
            <CardContent className="flex-1 overflow-auto p-0">
              <div className="divide-y divide-border">
                {mappings.map((mapping) => (
                  <motion.div
                    key={mapping.id}
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-3 hover:bg-secondary/50 transition-colors"
                  >
                    <div className="grid grid-cols-1 gap-3 mb-2 sm:grid-cols-4">
                      <div>
                        <label className="text-xs text-muted-foreground">API Alias</label>
                        <input
                          type="text"
                          value={mapping.alias}
                          onChange={(e) => updateMapping(mapping.id, 'alias', e.target.value)}
                          className="w-full mt-1 px-2 py-1 rounded border border-border bg-background text-xs"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-muted-foreground">DB Column</label>
                        <input
                          type="text"
                          value={mapping.columnName}
                          onChange={(e) => updateMapping(mapping.id, 'columnName', e.target.value)}
                          className="w-full mt-1 px-2 py-1 rounded border border-border bg-background text-xs"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-muted-foreground">Direction</label>
                        <select
                          value={mapping.direction}
                          onChange={(e) => updateMapping(mapping.id, 'direction', e.target.value as FieldMappingRow['direction'])}
                          className="w-full mt-1 px-2 py-1 rounded border border-border bg-background text-xs"
                        >
                          <option value="both">both</option>
                          <option value="in">in</option>
                          <option value="out">out</option>
                        </select>
                      </div>
                      <div className="flex flex-col justify-end gap-2">
                        <Button size="sm" onClick={() => saveMapping(mapping)} disabled={isSaving}>
                          <Save className="w-4 h-4 mr-1" />
                          Save
                        </Button>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-3 items-center text-xs text-muted-foreground">
                      <div>Table: {mapping.tableName}</div>
                      <div>Type: {mapping.type}</div>
                      <div>Required: {mapping.required ? 'Yes' : 'No'}</div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* JSON Preview */}
        <div className="flex-1 flex flex-col min-h-0">
          <Card className="flex-1 flex flex-col">
            <CardHeader className="pb-3 border-b border-border">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm">Saved Mappings</CardTitle>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">Table</span>
                  <select
                    value={selectedTable}
                    onChange={(e) => handleTableChange(e.target.value)}
                    className="px-2 py-1 rounded border border-border bg-background text-sm"
                  >
                    {availableTables.map((table) => (
                      <option key={table} value={table}>
                        {table}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </CardHeader>
            <CardContent className="flex-1 p-4">
              {loadError ? (
                <div className="rounded-lg border border-destructive bg-destructive/10 p-3 text-sm text-destructive">
                  {loadError}
                </div>
              ) : savedMappings.length === 0 ? (
                <p className="text-sm text-muted-foreground">No saved field mappings found.</p>
              ) : (
                <div className="space-y-2">
                  {savedMappings.map((mapping) => (
                    <div key={mapping.id} className="rounded-lg border border-border bg-secondary p-3 text-xs">
                      <div className="font-medium">{mapping.alias}</div>
                      <div className="grid grid-cols-2 gap-2 mt-2 text-muted-foreground">
                        <span>DB Column: {mapping.columnName}</span>
                        <span>Table: {mapping.tableName}</span>
                      </div>
                      <div className="text-muted-foreground mt-1">Direction: {mapping.direction}</div>
                    </div>
                  ))}
                </div>
              )}
              {saveMessage ? (
                <div className="mt-4 rounded-lg border border-border bg-secondary/60 p-3 text-sm">
                  {saveMessage}
                </div>
              ) : null}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
