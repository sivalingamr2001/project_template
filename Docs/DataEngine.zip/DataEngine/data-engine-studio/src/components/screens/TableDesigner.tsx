import { useEffect, useState } from 'react'
import { Plus, Trash2, Save, Eye } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { CodeEditor } from '@/components/ui/CodeEditor'
import { motion } from 'framer-motion'
import { getTableSchema, listTables } from '@/services/api/schema'

interface Column {
  id: string
  name: string
  type: string
  nullable: boolean
  primaryKey: boolean
  autoIncrement: boolean
  defaultValue?: string
}

interface TableSummary {
  name: string
}

export default function TableDesigner() {
  const [tableName, setTableName] = useState('products')
  const [columns, setColumns] = useState<Column[]>([])
  const [sqlPreview, setSqlPreview] = useState('')
  const [availableTables, setAvailableTables] = useState<TableSummary[]>([])
  const [schemaLoading, setSchemaLoading] = useState(false)
  const [schemaError, setSchemaError] = useState<string | null>(null)

  useEffect(() => {
    const loadTables = async () => {
      try {
        const response = await listTables()
        setAvailableTables(response.tables.map((name) => ({ name })))
      } catch {
        // ignore backend failure for table list
      }
    }
    loadTables()
  }, [])

  useEffect(() => {
    updateSQL(columns)
  }, [tableName, columns])

  const addColumn = () => {
    const newColumn: Column = {
      id: Date.now().toString(),
      name: `column_${columns.length + 1}`,
      type: 'VARCHAR(100)',
      nullable: true,
      primaryKey: false,
      autoIncrement: false,
    }
    setColumns((current) => [...current, newColumn])
  }

  const updateColumn = (id: string, field: keyof Column, value: any) => {
    setColumns((current) => current.map((col) => (col.id === id ? { ...col, [field]: value } : col)))
  }

  const deleteColumn = (id: string) => {
    setColumns((current) => current.filter((col) => col.id !== id))
  }

  const updateSQL = (cols: Column[]) => {
    const sql = `CREATE TABLE ${tableName} (\n  ${cols
      .map((col) => {
        let def = `${col.name} ${col.type}`
        if (!col.nullable) def += ' NOT NULL'
        if (col.primaryKey) def += ' PRIMARY KEY'
        if (col.autoIncrement) def += ' AUTO_INCREMENT'
        if (col.defaultValue) def += ` DEFAULT ${col.defaultValue}`
        return def
      })
      .join(',\n  ')}\n);`
    setSqlPreview(sql)
  }

  const loadTableSchema = async () => {
    setSchemaError(null)
    setSchemaLoading(true)
    try {
      const response = await getTableSchema(tableName)
      const newColumns = response.schema.columns?.map((column, idx) => ({
        id: `${column.columnName}-${idx}`,
        name: column.columnName,
        type: column.dataType,
        nullable: column.isNullable,
        primaryKey: column.isPrimaryKey,
        autoIncrement: column.isAutoIncrement,
        defaultValue: column.defaultValue ? String(column.defaultValue) : undefined,
      })) ?? []

      setColumns(newColumns)
    } catch {
      setSchemaError(`Unable to load schema for table '${tableName}'.`)
    } finally {
      setSchemaLoading(false)
    }
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="border-b border-border p-6 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Table Designer</h1>
          <p className="text-muted-foreground">Create and inspect database table schemas visually.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={loadTableSchema} disabled={schemaLoading}>
            <Eye className="w-4 h-4 mr-2" />
            {schemaLoading ? 'Loading...' : 'Load Schema'}
          </Button>
          <Button>
            <Save className="w-4 h-4 mr-2" />
            Save Table
          </Button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-hidden flex flex-col lg:flex-row gap-4 p-4">
        {/* Schema Builder */}
        <div className="flex-1 flex flex-col min-h-0">
          <Card className="flex-1 flex flex-col">
            <CardHeader className="pb-3 border-b border-border">
              <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
                <div className="flex-1">
                  <label className="text-xs text-muted-foreground">Table Name</label>
                  <input
                    type="text"
                    value={tableName}
                    onChange={(e) => setTableName(e.target.value)}
                    className="text-lg font-semibold bg-transparent border-b border-transparent hover:border-border focus:border-primary outline-none mt-1"
                  />
                </div>
                <div className="w-full sm:w-64">
                  <label className="text-xs text-muted-foreground">Existing Tables</label>
                  <select
                    value={tableName}
                    onChange={(e) => setTableName(e.target.value)}
                    className="w-full mt-1 px-2 py-2 rounded border border-border bg-background text-sm"
                  >
                    {availableTables.map((table) => (
                      <option key={table.name} value={table.name}>
                        {table.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </CardHeader>
            <CardContent className="flex-1 overflow-auto p-0">
              <div className="space-y-2 p-4">
                {schemaError ? (
                  <div className="rounded-lg border border-destructive bg-destructive/10 p-3 text-sm text-destructive">
                    {schemaError}
                  </div>
                ) : null}
                {columns.map((column) => (
                  <motion.div
                    key={column.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="bg-secondary p-3 rounded-lg border border-border hover:border-primary/30 transition-colors"
                  >
                    <div className="grid grid-cols-1 gap-3 mb-2">
                      <div className="flex gap-2 items-end">
                        <div className="flex-1">
                          <label className="text-xs text-muted-foreground block mb-1">Column Name</label>
                          <input
                            type="text"
                            value={column.name}
                            onChange={(e) => updateColumn(column.id, 'name', e.target.value)}
                            className="w-full px-2 py-1 rounded border border-border bg-background text-sm"
                          />
                        </div>
                        <div className="flex-1">
                          <label className="text-xs text-muted-foreground block mb-1">Data Type</label>
                          <select
                            value={column.type}
                            onChange={(e) => updateColumn(column.id, 'type', e.target.value)}
                            className="w-full px-2 py-1 rounded border border-border bg-background text-sm"
                          >
                            <option>INT</option>
                            <option>BIGINT</option>
                            <option>VARCHAR(100)</option>
                            <option>VARCHAR(255)</option>
                            <option>TEXT</option>
                            <option>DATETIME</option>
                            <option>DATE</option>
                            <option>BOOLEAN</option>
                            <option>DECIMAL(10,2)</option>
                          </select>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteColumn(column.id)}
                          className="h-9 px-2"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <div className="flex gap-3 flex-wrap">
                      <label className="flex items-center gap-2 cursor-pointer text-xs">
                        <input
                          type="checkbox"
                          checked={column.primaryKey}
                          onChange={(e) => updateColumn(column.id, 'primaryKey', e.target.checked)}
                          className="w-3 h-3"
                        />
                        Primary Key
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer text-xs">
                        <input
                          type="checkbox"
                          checked={!column.nullable}
                          onChange={(e) => updateColumn(column.id, 'nullable', !e.target.checked)}
                          className="w-3 h-3"
                        />
                        Not Null
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer text-xs">
                        <input
                          type="checkbox"
                          checked={column.autoIncrement}
                          onChange={(e) => updateColumn(column.id, 'autoIncrement', e.target.checked)}
                          className="w-3 h-3"
                          disabled={column.type !== 'INT' && column.type !== 'BIGINT'}
                        />
                        Auto Increment
                      </label>
                    </div>
                  </motion.div>
                ))}
                <Button size="sm" onClick={addColumn}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Column
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* SQL Preview */}
        <div className="flex-1 flex flex-col min-h-0">
          <Card className="flex-1 flex flex-col">
            <CardHeader className="pb-3 border-b border-border">
              <CardTitle className="text-sm">SQL Preview</CardTitle>
            </CardHeader>
            <CardContent className="flex-1 p-0">
              <CodeEditor value={sqlPreview} language="sql" readOnly height="100%" />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
