import { useState } from 'react'
import Navbar from './layout/Navbar'
import Sidebar from './layout/Sidebar'
import Dashboard from './screens/Dashboard'
import Connections from './screens/Connections'
import TableDesigner from './screens/TableDesigner'
import FieldMapper from './screens/FieldMapper'
import QueryStudio from './screens/QueryStudio'
import DataExplorer from './screens/DataExplorer'
import ProcedureStudio from './screens/ProcedureStudio'
import TestLab from './screens/TestLab'
import AuditLogs from './screens/AuditLogs'
import Settings from './screens/Settings'
import { useSidebar } from '@/contexts/SidebarContext'

type Screen = 
  | 'dashboard'
  | 'connections'
  | 'table-designer'
  | 'field-mapper'
  | 'query-studio'
  | 'data-explorer'
  | 'procedure-studio'
  | 'test-lab'
  | 'audit-logs'
  | 'settings'

export default function AppShell() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('dashboard')
  const { isOpen, isMobile } = useSidebar()

  const renderScreen = () => {
    switch (currentScreen) {
      case 'dashboard':
        return <Dashboard />
      case 'connections':
        return <Connections />
      case 'table-designer':
        return <TableDesigner />
      case 'field-mapper':
        return <FieldMapper />
      case 'query-studio':
        return <QueryStudio />
      case 'data-explorer':
        return <DataExplorer />
      case 'procedure-studio':
        return <ProcedureStudio />
      case 'test-lab':
        return <TestLab />
      case 'audit-logs':
        return <AuditLogs />
      case 'settings':
        return <Settings />
      default:
        return <Dashboard />
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar onNavigate={setCurrentScreen} />
      <div className="flex h-[calc(100vh-60px)] overflow-hidden">
        <Sidebar onNavigate={setCurrentScreen} currentScreen={currentScreen} />
        <main 
          className={`flex-1 overflow-auto transition-all duration-300 ${
            !isOpen && isMobile ? 'w-full' : ''
          }`}
        >
          <div className="h-full">
            {renderScreen()}
          </div>
        </main>
      </div>
    </div>
  )
}
