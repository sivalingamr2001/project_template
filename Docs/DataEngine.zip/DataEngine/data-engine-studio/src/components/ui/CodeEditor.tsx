import React, { useRef, useEffect } from 'react';
import * as monaco from 'monaco-editor';
import { useTheme } from '@/contexts/ThemeContext';

interface CodeEditorProps {
    value: string;
    onChange?: (value: string) => void;
    language?: string;
    height?: number | string;
    readOnly?: boolean;
    minimap?: boolean;
}

export const CodeEditor: React.FC<CodeEditorProps> = ({
    value,
    onChange,
    language = 'sql',
    height = '100%',
    readOnly = false,
    minimap = false,
}) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const editorRef = useRef<monaco.editor.IStandaloneCodeEditor | null>(null);
    const { theme } = useTheme()

    useEffect(() => {
        if (!containerRef.current) return;

        editorRef.current = monaco.editor.create(containerRef.current, {
            value,
            language,
            theme: theme === 'dark' ? 'vs-dark' : 'vs',
            readOnly,
            minimap: { enabled: minimap },
            automaticLayout: true,
            fontSize: 12,
            fontFamily: '"Fira Code", monospace',
            lineNumbersMinChars: 3,
            scrollBeyondLastLine: false,
        });

        const handleChange = () => {
            const content = editorRef.current?.getValue();
            if (content !== undefined) {
                onChange?.(content);
            }
        };

        const subscription = editorRef.current.onDidChangeModelContent(handleChange);

        return () => {
            subscription.dispose();
            editorRef.current?.dispose();
        };
    }, [language, theme, readOnly, minimap, onChange]);

    useEffect(() => {
        if (editorRef.current && editorRef.current.getValue() !== value) {
            editorRef.current.setValue(value);
        }
    }, [value]);

    return <div ref={containerRef} style={{ width: '100%', height }} />;
};
