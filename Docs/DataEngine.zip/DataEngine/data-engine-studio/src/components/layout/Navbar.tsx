import { Menu, Moon, Sun, Settings as SettingsIcon } from 'lucide-react'
import { useTheme } from '@/contexts/ThemeContext'
import { useSidebar } from '@/contexts/SidebarContext'
import { Button } from '@/components/ui/button'

interface NavbarProps {
  onNavigate: (screen: any) => void
}

export default function Navbar({ onNavigate }: NavbarProps) {
  const { theme, toggleTheme } = useTheme()
  const { toggleSidebar } = useSidebar()

  return (
    <nav className="h-[60px] border-b border-border bg-card flex items-center justify-between px-6 sticky top-0 z-40">
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="sm"
          onClick={toggleSidebar}
          className="md:hidden"
        >
          <Menu className="w-4 h-4" />
        </Button>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
            <span className="text-primary-foreground font-bold text-sm">DE</span>
          </div>
          <h1 className="text-lg font-semibold text-foreground hidden sm:block">
            DataEngine Studio
          </h1>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <Button
          variant="ghost"
          size="sm"
          onClick={toggleTheme}
          className="w-10 h-10 p-0"
          title={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
        >
          {theme === 'dark' ? (
            <Sun className="w-4 h-4" />
          ) : (
            <Moon className="w-4 h-4" />
          )}
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onNavigate('settings')}
          className="w-10 h-10 p-0"
          title="Settings"
        >
          <SettingsIcon className="w-4 h-4" />
        </Button>
      </div>
    </nav>
  )
}
