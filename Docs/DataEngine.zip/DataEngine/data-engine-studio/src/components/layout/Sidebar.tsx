import { useState } from 'react'
import { 
  LayoutDashboard, 
  Database, 
  Table2, 
  Grid3X3, 
  Search, 
  Database as DbIcon,
  Play,
  TestTube,
  FileText,
  MoreVertical,
  Settings
} from 'lucide-react'
import { useSidebar } from '@/contexts/SidebarContext'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

interface SidebarProps {
  onNavigate: (screen: any) => void
  currentScreen: string
}

const mainMenuItems = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'connections', label: 'Connections', icon: Database },
]

const metadataItems = [
  { id: 'table-designer', label: 'Table Designer', icon: Table2 },
  { id: 'field-mapper', label: 'Field Mapper', icon: Grid3X3 },
]

const queryItems = [
  { id: 'query-studio', label: 'Query Studio', icon: Search },
  { id: 'data-explorer', label: 'Data Explorer', icon: DbIcon },
]

const advancedItems = [
  { id: 'procedure-studio', label: 'Procedure Studio', icon: Play },
  { id: 'test-lab', label: 'Test Lab', icon: TestTube },
  { id: 'audit-logs', label: 'Audit Logs', icon: FileText },
  { id: 'settings', label: 'Settings', icon: Settings },
]

export default function Sidebar({ onNavigate, currentScreen }: SidebarProps) {
  const { isOpen, isMobile } = useSidebar()
  const [expandedMenu, setExpandedMenu] = useState<string | null>('query')

  const NavItem = ({ 
    item, 
    isActive 
  }: { 
    item: { id: string; label: string; icon: any }
    isActive: boolean 
  }) => {
    const Icon = item.icon
    return (
      <Button
        variant={isActive ? 'default' : 'ghost'}
        size="sm"
        onClick={() => {
          onNavigate(item.id)
          if (isMobile) {
            setExpandedMenu(null)
          }
        }}
        className={cn(
          'w-full justify-start gap-3 text-sm h-9 px-3',
          isActive && 'bg-primary text-primary-foreground'
        )}
      >
        <Icon className="w-4 h-4 flex-shrink-0" />
        {isOpen && <span className="truncate">{item.label}</span>}
      </Button>
    )
  }

  const MenuSection = ({ 
    title, 
    items, 
    sectionId 
  }: { 
    title: string
    items: Array<{ id: string; label: string; icon: any }>
    sectionId: string
  }) => {
    const isExpanded = expandedMenu === sectionId
    const hasActive = items.some(item => item.id === currentScreen)

    return (
      <div className="space-y-1">
        {isOpen && (
          <button
            onClick={() => setExpandedMenu(isExpanded ? null : sectionId)}
            className="flex items-center gap-2 w-full px-3 py-2 text-xs font-semibold text-muted-foreground hover:text-foreground transition-colors"
          >
            <span>{title}</span>
            <MoreVertical className={cn(
              'w-3 h-3 ml-auto transition-transform',
              isExpanded && 'rotate-90'
            )} />
          </button>
        )}
        {isOpen && isExpanded && items.map(item => (
          <NavItem
            key={item.id}
            item={item}
            isActive={item.id === currentScreen}
          />
        ))}
        {!isOpen && items.map(item => (
          item.id === currentScreen && (
            <NavItem
              key={item.id}
              item={item}
              isActive={true}
            />
          )
        ))}
      </div>
    )
  }

  if (isMobile && !isOpen) return null

  return (
    <aside className={cn(
      'border-r border-border bg-card transition-all duration-300',
      isOpen ? 'w-64' : 'w-20'
    )}>
      <div className="h-full flex flex-col overflow-y-auto">
        {/* Main Menu */}
        <div className="p-4 space-y-2 border-b border-border">
          {mainMenuItems.map(item => (
            <NavItem
              key={item.id}
              item={item}
              isActive={item.id === currentScreen}
            />
          ))}
        </div>

        {/* Metadata Section */}
        <div className="p-4 space-y-2 border-b border-border">
          <MenuSection
            title="Metadata"
            items={metadataItems}
            sectionId="metadata"
          />
        </div>

        {/* Query Section */}
        <div className="p-4 space-y-2 border-b border-border">
          <MenuSection
            title="Query"
            items={queryItems}
            sectionId="query"
          />
        </div>

        {/* Advanced Section */}
        <div className="p-4 space-y-2 border-b border-border flex-1">
          <MenuSection
            title="Advanced"
            items={advancedItems}
            sectionId="advanced"
          />
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-border">
          {isOpen && (
            <div className="text-xs text-muted-foreground">
              <p className="font-semibold mb-1">v1.0.0</p>
              <p>DataEngine Studio</p>
            </div>
          )}
        </div>
      </div>
    </aside>
  )
}
