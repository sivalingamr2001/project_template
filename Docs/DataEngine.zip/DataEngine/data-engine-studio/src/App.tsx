import { ThemeProvider } from '@/contexts/ThemeContext'
import { SidebarProvider } from '@/contexts/SidebarContext'
import AppShell from '@/components/AppShell'

function App() {
  return (
    <ThemeProvider>
      <SidebarProvider>
        <AppShell />
      </SidebarProvider>
    </ThemeProvider>
  )
}

export default App
