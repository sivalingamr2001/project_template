using DynamicTransactionEngine.Core.Enums;
using DynamicTransactionEngine.Core.Interfaces;
using DynamicTransactionEngine.Core.Models;

namespace DynamicTransactionEngine.Application.Processors;

public abstract class BaseProcessor(IFieldMapperProvider mapperProvider, IQueryBuilder queryBuilder)
    : ITransactionProcessor
{
    public async Task<TransactionResult> ProcessAsync(TransactionContext context, CancellationToken cancellationToken = default)
    {
        var metadata = await mapperProvider.GetEntityMetadataAsync(context.Request.EntityName, cancellationToken);
        _ = queryBuilder.Build(context, metadata);

        // Placeholder for repository execute; implementation seam kept via interface.
        return TransactionResult.Ok(1, $"{context.Request.Operation} executed for {context.Request.EntityName}");
    }
}

public sealed class InsertProcessor(IFieldMapperProvider mapperProvider, IQueryBuilder queryBuilder)
    : BaseProcessor(mapperProvider, queryBuilder);

public sealed class UpdateProcessor(IFieldMapperProvider mapperProvider, IQueryBuilder queryBuilder)
    : BaseProcessor(mapperProvider, queryBuilder);

public sealed class DeleteProcessor(IFieldMapperProvider mapperProvider, IQueryBuilder queryBuilder)
    : BaseProcessor(mapperProvider, queryBuilder);

public sealed class TransactionProcessorResolver(
    InsertProcessor insertProcessor,
    UpdateProcessor updateProcessor,
    DeleteProcessor deleteProcessor)
{
    public ITransactionProcessor Resolve(TransactionOperation operation) =>
        operation switch
        {
            TransactionOperation.Insert => insertProcessor,
            TransactionOperation.Update => updateProcessor,
            TransactionOperation.Delete => deleteProcessor,
            _ => throw new ArgumentOutOfRangeException(nameof(operation), operation, "Unsupported operation")
        };
}
