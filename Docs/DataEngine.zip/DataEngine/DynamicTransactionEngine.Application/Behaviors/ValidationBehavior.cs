using DynamicTransactionEngine.Application.Pipelines;
using DynamicTransactionEngine.Core.Interfaces;
using DynamicTransactionEngine.Core.Models;

namespace DynamicTransactionEngine.Application.Behaviors;

public sealed class ValidationBehavior(ITransactionValidator transactionValidator) : IPipelineStep
{
    public async Task InvokeAsync(TransactionContext context, Func<Task> next, CancellationToken cancellationToken = default)
    {
        await transactionValidator.ValidateAsync(context, cancellationToken);
        await next();
    }
}
