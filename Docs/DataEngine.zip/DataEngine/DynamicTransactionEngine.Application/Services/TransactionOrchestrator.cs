using DynamicTransactionEngine.Application.Pipelines;
using DynamicTransactionEngine.Application.Processors;
using DynamicTransactionEngine.Core.Contracts;
using DynamicTransactionEngine.Core.Interfaces;
using DynamicTransactionEngine.Core.Models;

namespace DynamicTransactionEngine.Application.Services;

public sealed class TransactionOrchestrator(
    TransactionPipeline pipeline,
    TransactionProcessorResolver resolver,
    IAuditService auditService,
    ITriggerService triggerService)
{
    public async Task<TransactionResult> ExecuteAsync(TransactionRequest request, CancellationToken cancellationToken = default)
    {
        var context = new TransactionContext
        {
            Request = request,
            CorrelationId = request.CorrelationId ?? Guid.NewGuid().ToString("N")
        };

        TransactionResult? result = null;

        await pipeline.ExecuteAsync(
            context,
            async () =>
            {
                await triggerService.OnBeforeExecuteAsync(context, cancellationToken);
                var processor = resolver.Resolve(request.Operation);
                result = await processor.ProcessAsync(context, cancellationToken);
                await triggerService.OnAfterExecuteAsync(context, result, cancellationToken);
            },
            cancellationToken);

        result ??= TransactionResult.Ok(0, "No-op");

        await auditService.WriteAsync(
            new AuditEntry
            {
                CorrelationId = context.CorrelationId,
                EntityName = request.EntityName,
                Operation = request.Operation.ToString(),
                Data = new Dictionary<string, object?>
                {
                    ["success"] = result.Success,
                    ["rowsAffected"] = result.RowsAffected
                }
            },
            cancellationToken);

        foreach (var child in request.Children)
        {
            await ExecuteAsync(child, cancellationToken);
        }

        return result;
    }
}
