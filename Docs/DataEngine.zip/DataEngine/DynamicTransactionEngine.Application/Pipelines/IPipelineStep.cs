using DynamicTransactionEngine.Core.Models;

namespace DynamicTransactionEngine.Application.Pipelines;

public interface IPipelineStep
{
    Task InvokeAsync(TransactionContext context, Func<Task> next, CancellationToken cancellationToken = default);
}
