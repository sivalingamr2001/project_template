using DynamicTransactionEngine.Core.Models;

namespace DynamicTransactionEngine.Application.Pipelines;

public sealed class TransactionPipeline(IEnumerable<IPipelineStep> steps)
{
    private readonly IReadOnlyList<IPipelineStep> _steps = steps.ToList();

    public Task ExecuteAsync(TransactionContext context, Func<Task> terminal, CancellationToken cancellationToken = default)
    {
        var index = -1;
        Task Next()
        {
            index++;
            if (index == _steps.Count)
            {
                return terminal();
            }

            return _steps[index].InvokeAsync(context, Next, cancellationToken);
        }

        return Next();
    }
}
