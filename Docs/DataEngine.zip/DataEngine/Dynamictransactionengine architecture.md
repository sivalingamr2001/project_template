# Dynamic Transaction Engine — .NET Class Library
## Enterprise Architecture & Implementation Reference
### Principal Architect Document · v1.0.0

---

> **Scope:** This document defines the complete architecture, interface contracts, implementation strategy, and delivery plan for the `DynamicTransactionEngine` .NET 8 class library. It targets staff-level and principal engineers responsible for implementation, review, and long-term ownership.

---

## Table of Contents

1. [Architectural Philosophy](#1-architectural-philosophy)
2. [Solution Structure](#2-solution-structure)
3. [Core Layer — Abstractions & Contracts](#3-core-layer)
4. [Application Layer — Orchestration & Pipelines](#4-application-layer)
5. [Infrastructure Layer — Persistence & Caching](#5-infrastructure-layer)
6. [MySQL Provider Layer](#6-mysql-provider-layer)
7. [Security Model](#7-security-model)
8. [Performance Design](#8-performance-design)
9. [Dependency Injection Bootstrap](#9-dependency-injection-bootstrap)
10. [Console Test Host](#10-console-test-host)
11. [Unit Test Architecture](#11-unit-test-architecture)
12. [Configuration Reference](#12-configuration-reference)
13. [Extension Points](#13-extension-points)
14. [Operational Concerns](#14-operational-concerns)

---

## 1. Architectural Philosophy

### 1.1 Design Principles

The engine is built on six non-negotiable design axioms:

| Axiom | Rationale |
|---|---|
| **Zero string-concatenated SQL** | Every identifier is whitelist-validated; every value is parameterized |
| **Pipeline-first processing** | All transaction paths flow through a composable, interceptable pipeline |
| **Metadata owns behaviour** | Business rules live in the mapper table, not in application code |
| **Async-all-the-way** | No `.Result` or `.Wait()` anywhere in the call chain |
| **Fail-loudly with context** | Every exception carries structured context for observability |
| **Seam-at-every-boundary** | Every major subsystem is behind an interface for testability and extensibility |

### 1.2 Bounded Contexts

```
┌──────────────────────────────────────────────────────────────────┐
│                      Calling Application                         │
└────────────────────────────┬─────────────────────────────────────┘
                             │  TransactionRequest
                             ▼
┌──────────────────────────────────────────────────────────────────┐
│              TransactionOrchestrator (Application)               │
│  ┌─────────────┐  ┌─────────────┐  ┌──────────────────────────┐ │
│  │  Validation │  │   Pipeline  │  │    Child Processor       │ │
│  │  Pipeline   │  │  Behaviors  │  │    (Recursive)           │ │
│  └─────────────┘  └─────────────┘  └──────────────────────────┘ │
└────────┬──────────────┬──────────────────┬───────────────────────┘
         │              │                  │
         ▼              ▼                  ▼
┌──────────────┐ ┌─────────────┐  ┌──────────────────────────────┐
│  Metadata &  │ │  Query      │  │  Audit / Trigger / Hook      │
│  FK Cache    │ │  Builder    │  │  Infrastructure              │
│ (Infra)      │ │ (Infra)     │  │  (Infra)                     │
└──────┬───────┘ └──────┬──────┘  └────────────┬─────────────────┘
       │                │                       │
       └────────────────┼───────────────────────┘
                        ▼
             ┌─────────────────────┐
             │  Database Provider  │
             │  (MySQL / Oracle)   │
             └─────────────────────┘
```

---

## 2. Solution Structure

```
DynamicTransactionEngine/
│
├── DynamicTransactionEngine.Core/
│   ├── Models/
│   │   ├── FieldMapper.cs
│   │   ├── EntityMetadata.cs
│   │   ├── ForeignKeyMetadata.cs
│   │   ├── TransactionContext.cs
│   │   ├── TransactionRequest.cs
│   │   └── TransactionResult.cs
│   ├── Interfaces/
│   │   ├── ITransactionProcessor.cs
│   │   ├── IQueryBuilder.cs
│   │   ├── IFieldMapperProvider.cs
│   │   ├── IEntityValidator.cs
│   │   ├── IForeignKeyValidator.cs
│   │   ├── IAuditService.cs
│   │   ├── ITransactionValidator.cs
│   │   ├── ISchemaProvider.cs
│   │   ├── ITriggerService.cs
│   │   └── IMetadataCacheService.cs
│   ├── Enums/
│   │   ├── TransactionOperation.cs
│   │   ├── CascadeRule.cs
│   │   ├── FieldProperty.cs
│   │   └── DataClassification.cs
│   ├── Exceptions/
│   │   ├── TransactionEngineException.cs
│   │   ├── EntityNotFoundException.cs
│   │   ├── ForeignKeyViolationException.cs
│   │   ├── ValidationException.cs
│   │   └── SqlInjectionAttemptException.cs
│   ├── Validators/
│   │   └── IdentifierValidator.cs
│   └── Contracts/
│       ├── QueryDefinition.cs
│       └── AuditEntry.cs
│
├── DynamicTransactionEngine.Application/
│   ├── Services/
│   │   └── TransactionOrchestrator.cs
│   ├── Processors/
│   │   ├── InsertProcessor.cs
│   │   ├── UpdateProcessor.cs
│   │   ├── DeleteProcessor.cs
│   │   └── ChildEntityProcessor.cs
│   ├── Pipelines/
│   │   ├── TransactionPipeline.cs
│   │   └── IPipelineStep.cs
│   ├── Behaviors/
│   │   ├── ValidationBehavior.cs
│   │   ├── AuditBehavior.cs
│   │   ├── RetryBehavior.cs
│   │   └── LoggingBehavior.cs
│   └── Handlers/
│       ├── InsertHandler.cs
│       ├── UpdateHandler.cs
│       └── DeleteHandler.cs
│
├── DynamicTransactionEngine.Infrastructure/
│   ├── Repositories/
│   │   ├── SchemaRepository.cs
│   │   ├── TransactionRepository.cs
│   │   └── MapperRepository.cs
│   ├── Database/
│   │   ├── IConnectionFactory.cs
│   │   └── DbConnectionScope.cs
│   ├── Caching/
│   │   ├── MetadataCacheService.cs
│   │   └── CacheKeyProvider.cs
│   ├── Auditing/
│   │   └── AuditService.cs
│   ├── Logging/
│   │   └── StructuredLoggerExtensions.cs
│   └── QueryBuilders/
│       └── BaseQueryBuilder.cs
│
├── DynamicTransactionEngine.MySql/
│   ├── MySqlQueryBuilder.cs
│   ├── MySqlSchemaProvider.cs
│   └── MySqlConnectionFactory.cs
│
├── DynamicTransactionEngine.Tests/         ← Console App (xUnit runner)
│   ├── Unit/
│   │   ├── Processors/
│   │   ├── Validators/
│   │   ├── QueryBuilders/
│   │   └── Pipeline/
│   └── Integration/
│       ├── MySqlIntegrationTests.cs
│       └── TransactionOrchestratorIntegrationTests.cs
│
└── DynamicTransactionEngine.sln
```

---

## 3. Core Layer

### 3.1 Enumerations

```csharp
// DynamicTransactionEngine.Core/Enums/TransactionOperation.cs

namespace DynamicTransactionEngine.Core.Enums;

public enum TransactionOperation
{
    Insert = 1,
    Update = 2,
    Delete = 3
}
```

```csharp
// DynamicTransactionEngine.Core/Enums/CascadeRule.cs

namespace DynamicTransactionEngine.Core.Enums;

public enum CascadeRule
{
    NoAction = 0,
    Cascade = 1,
    SetNull = 2,
    Restrict = 3
}
```

```csharp
// DynamicTransactionEngine.Core/Enums/FieldProperty.cs

namespace DynamicTransactionEngine.Core.Enums;

[Flags]
public enum FieldProperty
{
    None            = 0,
    Required        = 1 << 0,
    PrimaryKey      = 1 << 1,
    Identity        = 1 << 2,
    ForeignKey      = 1 << 3,
    ReadOnly        = 1 << 4,
    AllowUpdate     = 1 << 5,
    IgnoreOnInsert  = 1 << 6,
    IgnoreOnUpdate  = 1 << 7,
    SoftDeleteColumn = 1 << 8,
    Sensitive       = 1 << 9
}
```

```csharp
// DynamicTransactionEngine.Core/Enums/DataClassification.cs

namespace DynamicTransactionEngine.Core.Enums;

public enum DataClassification
{
    Public = 0,
    Internal = 1,
    Confidential = 2,
    Restricted = 3    // passwords, tokens, secrets — masked in audit
}
```

### 3.2 Domain Models

```csharp
// DynamicTransactionEngine.Core/Models/FieldMapper.cs

using DynamicTransactionEngine.Core.Enums;

namespace DynamicTransactionEngine.Core.Models;

/// <summary>
/// Represents a single row in the FieldMapper metadata table.
/// Drives all dynamic SQL generation and validation behaviour.
/// </summary>
public sealed record FieldMapper
{
    public int Id { get; init; }
    public required string EntityName { get; init; }
    public required string FieldName { get; init; }
    public required string ColumnName { get; init; }
    public required string DataType { get; init; }
    public FieldProperty Properties { get; init; } = FieldProperty.None;
    public string? DefaultValue { get; init; }
    public string? ForeignKeyEntity { get; init; }
    public string? ForeignKeyColumn { get; init; }
    public CascadeRule CascadeRule { get; init; } = CascadeRule.NoAction;
    public int? MaxLength { get; init; }
    public string? ValidationRegex { get; init; }
    public DataClassification Classification { get; init; } = DataClassification.Public;
    public int SortOrder { get; init; }

    public bool HasProperty(FieldProperty prop) => (Properties & prop) == prop;
    public bool IsPrimaryKey => HasProperty(FieldProperty.PrimaryKey);
    public bool IsIdentity => HasProperty(FieldProperty.Identity);
    public bool IsRequired => HasProperty(FieldProperty.Required);
    public bool IsForeignKey => HasProperty(FieldProperty.ForeignKey);
    public bool IsSensitive => HasProperty(FieldProperty.Sensitive);
}
```

```csharp
// DynamicTransactionEngine.Core/Models/EntityMetadata.cs

namespace DynamicTransactionEngine.Core.Models;

/// <summary>
/// Aggregated metadata for a single entity, composed from FieldMapper rows.
/// Cached aggressively; never materialised on the hot path without cache hit.
/// </summary>
public sealed record EntityMetadata
{
    public required string EntityName { get; init; }
    public required string TableName { get; init; }
    public required IReadOnlyList<FieldMapper> Fields { get; init; }
    public required IReadOnlyList<ForeignKeyMetadata> ForeignKeys { get; init; }
    public DateTimeOffset CachedAt { get; init; } = DateTimeOffset.UtcNow;

    public FieldMapper? PrimaryKey => Fields.FirstOrDefault(f => f.IsPrimaryKey);
    public FieldMapper? IdentityField => Fields.FirstOrDefault(f => f.IsIdentity);
    public FieldMapper? SoftDeleteField => Fields.FirstOrDefault(
        f => f.HasProperty(Enums.FieldProperty.SoftDeleteColumn));

    public IEnumerable<FieldMapper> InsertableFields =>
        Fields.Where(f => !f.HasProperty(Enums.FieldProperty.IgnoreOnInsert)
                       && !f.IsIdentity
                       && !f.HasProperty(Enums.FieldProperty.ReadOnly));

    public IEnumerable<FieldMapper> UpdatableFields =>
        Fields.Where(f => f.HasProperty(Enums.FieldProperty.AllowUpdate)
                       && !f.HasProperty(Enums.FieldProperty.IgnoreOnUpdate)
                       && !f.IsPrimaryKey
                       && !f.IsIdentity);
}
```

```csharp
// DynamicTransactionEngine.Core/Models/ForeignKeyMetadata.cs

using DynamicTransactionEngine.Core.Enums;

namespace DynamicTransactionEngine.Core.Models;

public sealed record ForeignKeyMetadata
{
    public required string ConstraintName { get; init; }
    public required string ChildEntity { get; init; }
    public required string ChildColumn { get; init; }
    public required string ParentEntity { get; init; }
    public required string ParentColumn { get; init; }
    public CascadeRule DeleteRule { get; init; } = CascadeRule.NoAction;
    public CascadeRule UpdateRule { get; init; } = CascadeRule.NoAction;
}
```

```csharp
// DynamicTransactionEngine.Core/Models/TransactionContext.cs

using System.Data;
using DynamicTransactionEngine.Core.Enums;

namespace DynamicTransactionEngine.Core.Models;

/// <summary>
/// Mutable execution context threaded through the entire pipeline.
/// Carries the live DB transaction and accumulated state.
/// </summary>
public sealed class TransactionContext
{
    public required string CorrelationId { get; init; }
    public required string UserId { get; init; }
    public required TransactionOperation Operation { get; init; }
    public required TransactionRequest Request { get; init; }
    public EntityMetadata? EntityMetadata { get; set; }
    public IDbTransaction? DbTransaction { get; set; }
    public Dictionary<string, object?> PreviousValues { get; set; } = new();
    public Dictionary<string, object?> ResolvedValues { get; set; } = new();
    public List<ValidationError> ValidationErrors { get; set; } = new();
    public object? InsertedId { get; set; }
    public bool IsChildContext { get; set; }
    public string? ParentEntityName { get; set; }
    public object? ParentInsertedId { get; set; }
    public string? ParentForeignKeyColumn { get; set; }
    public CancellationToken CancellationToken { get; init; } = CancellationToken.None;

    public bool HasErrors => ValidationErrors.Count > 0;
}
```

```csharp
// DynamicTransactionEngine.Core/Models/TransactionRequest.cs

using System.Text.Json.Serialization;

namespace DynamicTransactionEngine.Core.Models;

public sealed class TransactionRequest
{
    [JsonPropertyName("extendedProperties")]
    public Dictionary<string, object?> ExtendedProperties { get; set; } = new();

    [JsonPropertyName("renProps")]
    public Dictionary<string, List<Dictionary<string, object?>>> RenProps { get; set; } = new();

    [JsonPropertyName("delProps")]
    public Dictionary<string, List<Dictionary<string, object?>>> DelProps { get; set; } = new();

    [JsonPropertyName("transactionEntityName")]
    public string TransactionEntityName { get; set; } = string.Empty;

    [JsonPropertyName("transactionId")]
    public string TransactionId { get; set; } = string.Empty;

    [JsonPropertyName("userId")]
    public string UserId { get; set; } = string.Empty;

    [JsonPropertyName("useModelBinding")]
    public bool UseModelBinding { get; set; } = false;
}
```

```csharp
// DynamicTransactionEngine.Core/Models/TransactionResult.cs

using System.Text.Json.Serialization;

namespace DynamicTransactionEngine.Core.Models;

public sealed class TransactionResult
{
    public bool Success { get; set; }
    public string TransactionId { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;
    public Dictionary<string, object?> Data { get; set; } = new();
    public List<ValidationError> ValidationErrors { get; set; } = new();
    public string? CorrelationId { get; set; }
    public long ElapsedMilliseconds { get; set; }

    [JsonIgnore]
    public Exception? Exception { get; set; }

    public static TransactionResult Ok(string transactionId, string message = "Success") =>
        new() { Success = true, TransactionId = transactionId, Message = message };

    public static TransactionResult Fail(string transactionId, string message,
        List<ValidationError>? errors = null) =>
        new() { Success = false, TransactionId = transactionId, Message = message,
                ValidationErrors = errors ?? new() };
}
```

```csharp
// DynamicTransactionEngine.Core/Models/ValidationError.cs

namespace DynamicTransactionEngine.Core.Models;

public sealed record ValidationError
{
    public required string Field { get; init; }
    public required string Code { get; init; }
    public required string Message { get; init; }
    public object? AttemptedValue { get; init; }
}
```

### 3.3 Contracts

```csharp
// DynamicTransactionEngine.Core/Contracts/QueryDefinition.cs

namespace DynamicTransactionEngine.Core.Contracts;

/// <summary>
/// Immutable descriptor of a parameterized SQL statement ready for execution.
/// Produced by IQueryBuilder; consumed by ITransactionRepository.
/// </summary>
public sealed record QueryDefinition
{
    public required string Sql { get; init; }
    public required IReadOnlyDictionary<string, object?> Parameters { get; init; }
    public int? CommandTimeoutSeconds { get; init; }

    public static QueryDefinition Create(string sql,
        Dictionary<string, object?> parameters,
        int? timeout = null) =>
        new() { Sql = sql, Parameters = parameters, CommandTimeoutSeconds = timeout };
}
```

```csharp
// DynamicTransactionEngine.Core/Contracts/AuditEntry.cs

using DynamicTransactionEngine.Core.Enums;

namespace DynamicTransactionEngine.Core.Contracts;

public sealed record AuditEntry
{
    public required string CorrelationId { get; init; }
    public required string UserId { get; init; }
    public required string EntityName { get; init; }
    public required string TableName { get; init; }
    public required TransactionOperation Operation { get; init; }
    public object? PrimaryKeyValue { get; init; }
    public required IReadOnlyDictionary<string, object?> PreviousValues { get; init; }
    public required IReadOnlyDictionary<string, object?> NewValues { get; init; }
    public DateTimeOffset OccurredAt { get; init; } = DateTimeOffset.UtcNow;
    public string? MachineName { get; init; } = Environment.MachineName;
}
```

### 3.4 Interfaces

```csharp
// DynamicTransactionEngine.Core/Interfaces/ITransactionProcessor.cs

using DynamicTransactionEngine.Core.Models;

namespace DynamicTransactionEngine.Core.Interfaces;

/// <summary>
/// Top-level entry point contract for all transaction processing.
/// Implementations are operation-specific (Insert / Update / Delete).
/// </summary>
public interface ITransactionProcessor
{
    Task<TransactionResult> InsertAsync(
        TransactionRequest request,
        CancellationToken cancellationToken = default);

    Task<TransactionResult> UpdateAsync(
        TransactionRequest request,
        CancellationToken cancellationToken = default);

    Task<TransactionResult> DeleteAsync(
        TransactionRequest request,
        CancellationToken cancellationToken = default);
}
```

```csharp
// DynamicTransactionEngine.Core/Interfaces/IQueryBuilder.cs

using DynamicTransactionEngine.Core.Contracts;
using DynamicTransactionEngine.Core.Models;

namespace DynamicTransactionEngine.Core.Interfaces;

/// <summary>
/// Produces parameterized QueryDefinition objects for each DML operation.
/// Implementations are DB-vendor-specific (MySQL, Oracle, etc.).
/// </summary>
public interface IQueryBuilder
{
    QueryDefinition BuildInsertQuery(
        EntityMetadata metadata,
        IReadOnlyDictionary<string, object?> values);

    QueryDefinition BuildUpdateQuery(
        EntityMetadata metadata,
        IReadOnlyDictionary<string, object?> values,
        object primaryKeyValue);

    QueryDefinition BuildDeleteQuery(
        EntityMetadata metadata,
        object primaryKeyValue,
        bool softDelete);

    QueryDefinition BuildSelectQuery(
        EntityMetadata metadata,
        object primaryKeyValue);

    QueryDefinition BuildExistsQuery(
        string tableName,
        string columnName,
        object value);

    /// <summary>
    /// Returns a safely-escaped, whitelist-validated identifier.
    /// Throws SqlInjectionAttemptException if the identifier fails validation.
    /// </summary>
    string EscapeIdentifier(string identifier);
}
```

```csharp
// DynamicTransactionEngine.Core/Interfaces/IFieldMapperProvider.cs

using DynamicTransactionEngine.Core.Models;

namespace DynamicTransactionEngine.Core.Interfaces;

public interface IFieldMapperProvider
{
    Task<EntityMetadata> GetEntityMetadataAsync(
        string entityName,
        CancellationToken cancellationToken = default);

    Task<IReadOnlyList<FieldMapper>> GetFieldMappersAsync(
        string entityName,
        CancellationToken cancellationToken = default);

    Task InvalidateCacheAsync(string entityName);
}
```

```csharp
// DynamicTransactionEngine.Core/Interfaces/IEntityValidator.cs

using DynamicTransactionEngine.Core.Enums;
using DynamicTransactionEngine.Core.Models;

namespace DynamicTransactionEngine.Core.Interfaces;

public interface IEntityValidator
{
    Task<List<ValidationError>> ValidateAsync(
        TransactionContext context,
        TransactionOperation operation,
        CancellationToken cancellationToken = default);
}
```

```csharp
// DynamicTransactionEngine.Core/Interfaces/IForeignKeyValidator.cs

using DynamicTransactionEngine.Core.Models;

namespace DynamicTransactionEngine.Core.Interfaces;

public interface IForeignKeyValidator
{
    /// <summary>
    /// Validates that all foreign key references in the resolved values
    /// exist in their parent tables. Returns validation errors for any violation.
    /// </summary>
    Task<List<ValidationError>> ValidateReferencesAsync(
        TransactionContext context,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Validates that deleting this entity will not orphan dependent child records
    /// where the cascade rule is Restrict or NoAction.
    /// </summary>
    Task<List<ValidationError>> ValidateDependentsAsync(
        TransactionContext context,
        CancellationToken cancellationToken = default);
}
```

```csharp
// DynamicTransactionEngine.Core/Interfaces/IAuditService.cs

using DynamicTransactionEngine.Core.Contracts;

namespace DynamicTransactionEngine.Core.Interfaces;

public interface IAuditService
{
    Task RecordAsync(AuditEntry entry, CancellationToken cancellationToken = default);
}
```

```csharp
// DynamicTransactionEngine.Core/Interfaces/ITransactionValidator.cs

using DynamicTransactionEngine.Core.Enums;
using DynamicTransactionEngine.Core.Models;

namespace DynamicTransactionEngine.Core.Interfaces;

/// <summary>
/// Extension point for domain-specific business validation rules.
/// Register multiple implementations; all are executed in pipeline order.
/// </summary>
public interface ITransactionValidator
{
    int Priority { get; }

    Task<List<ValidationError>> ValidateAsync(
        TransactionContext context,
        TransactionOperation operation,
        CancellationToken cancellationToken = default);
}
```

```csharp
// DynamicTransactionEngine.Core/Interfaces/ISchemaProvider.cs

using DynamicTransactionEngine.Core.Models;

namespace DynamicTransactionEngine.Core.Interfaces;

public interface ISchemaProvider
{
    Task<bool> TableExistsAsync(string tableName, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<ForeignKeyMetadata>> GetForeignKeysAsync(string tableName,
        CancellationToken cancellationToken = default);
    Task<bool> RecordExistsAsync(string tableName, string columnName, object value,
        CancellationToken cancellationToken = default);
}
```

```csharp
// DynamicTransactionEngine.Core/Interfaces/ITriggerService.cs

using DynamicTransactionEngine.Core.Models;

namespace DynamicTransactionEngine.Core.Interfaces;

/// <summary>
/// Post-commit extension point. Implementations are fire-and-forget by default
/// but can be awaited for synchronous side-effects.
/// </summary>
public interface ITriggerService
{
    int Priority { get; }
    Task ExecuteAsync(TransactionContext context, CancellationToken cancellationToken = default);
}
```

```csharp
// DynamicTransactionEngine.Core/Interfaces/IMetadataCacheService.cs

namespace DynamicTransactionEngine.Core.Interfaces;

public interface IMetadataCacheService
{
    Task<T?> GetAsync<T>(string key);
    Task SetAsync<T>(string key, T value, TimeSpan? expiry = null);
    Task RemoveAsync(string key);
    Task<bool> ExistsAsync(string key);
}
```

### 3.5 Exceptions

```csharp
// DynamicTransactionEngine.Core/Exceptions/TransactionEngineException.cs

namespace DynamicTransactionEngine.Core.Exceptions;

public class TransactionEngineException : Exception
{
    public string? CorrelationId { get; }
    public string? EntityName { get; }

    public TransactionEngineException(string message,
        string? correlationId = null,
        string? entityName = null,
        Exception? innerException = null)
        : base(message, innerException)
    {
        CorrelationId = correlationId;
        EntityName = entityName;
    }
}
```

```csharp
// DynamicTransactionEngine.Core/Exceptions/ForeignKeyViolationException.cs

namespace DynamicTransactionEngine.Core.Exceptions;

public sealed class ForeignKeyViolationException : TransactionEngineException
{
    public string ParentEntity { get; }
    public string ParentColumn { get; }
    public object AttemptedValue { get; }

    public ForeignKeyViolationException(
        string parentEntity,
        string parentColumn,
        object attemptedValue,
        string? correlationId = null)
        : base($"Foreign key violation: referenced record not found in '{parentEntity}.{parentColumn}' for value '{attemptedValue}'.",
               correlationId,
               parentEntity)
    {
        ParentEntity = parentEntity;
        ParentColumn = parentColumn;
        AttemptedValue = attemptedValue;
    }
}
```

```csharp
// DynamicTransactionEngine.Core/Exceptions/SqlInjectionAttemptException.cs

namespace DynamicTransactionEngine.Core.Exceptions;

public sealed class SqlInjectionAttemptException : TransactionEngineException
{
    public string RejectedIdentifier { get; }

    public SqlInjectionAttemptException(string rejectedIdentifier)
        : base($"Identifier '{rejectedIdentifier}' failed whitelist validation. Possible SQL injection attempt.")
    {
        RejectedIdentifier = rejectedIdentifier;
    }
}
```

```csharp
// DynamicTransactionEngine.Core/Exceptions/ValidationException.cs

using DynamicTransactionEngine.Core.Models;

namespace DynamicTransactionEngine.Core.Exceptions;

public sealed class ValidationException : TransactionEngineException
{
    public IReadOnlyList<ValidationError> Errors { get; }

    public ValidationException(IReadOnlyList<ValidationError> errors,
        string? correlationId = null,
        string? entityName = null)
        : base($"Validation failed with {errors.Count} error(s).", correlationId, entityName)
    {
        Errors = errors;
    }
}
```

### 3.6 Identifier Validator

```csharp
// DynamicTransactionEngine.Core/Validators/IdentifierValidator.cs

using System.Text.RegularExpressions;
using DynamicTransactionEngine.Core.Exceptions;

namespace DynamicTransactionEngine.Core.Validators;

/// <summary>
/// Strict whitelist-based SQL identifier validator.
/// Allows only alphanumeric characters and underscores.
/// No dashes, dots, spaces, quotes, or SQL metacharacters permitted.
/// </summary>
public static class IdentifierValidator
{
    private static readonly Regex _safeIdentifier =
        new(@"^[a-zA-Z_][a-zA-Z0-9_]{0,127}$",
            RegexOptions.Compiled | RegexOptions.CultureInvariant);

    private static readonly HashSet<string> _reservedWords = new(StringComparer.OrdinalIgnoreCase)
    {
        "SELECT", "INSERT", "UPDATE", "DELETE", "DROP", "CREATE", "ALTER",
        "EXEC", "EXECUTE", "UNION", "WHERE", "FROM", "JOIN", "OR", "AND",
        "TRUNCATE", "GRANT", "REVOKE", "INFORMATION_SCHEMA", "SYS", "SYSOBJECTS"
    };

    public static void Validate(string identifier)
    {
        if (string.IsNullOrWhiteSpace(identifier))
            throw new SqlInjectionAttemptException(identifier ?? "(null)");

        if (!_safeIdentifier.IsMatch(identifier))
            throw new SqlInjectionAttemptException(identifier);

        if (_reservedWords.Contains(identifier))
            throw new SqlInjectionAttemptException(identifier);
    }

    public static bool IsValid(string identifier) =>
        !string.IsNullOrWhiteSpace(identifier)
        && _safeIdentifier.IsMatch(identifier)
        && !_reservedWords.Contains(identifier);
}
```

---

## 4. Application Layer

### 4.1 Pipeline Abstraction

```csharp
// DynamicTransactionEngine.Application/Pipelines/IPipelineStep.cs

using DynamicTransactionEngine.Core.Models;

namespace DynamicTransactionEngine.Application.Pipelines;

public interface IPipelineStep
{
    int Order { get; }
    Task ExecuteAsync(TransactionContext context, Func<Task> next);
}
```

```csharp
// DynamicTransactionEngine.Application/Pipelines/TransactionPipeline.cs

using DynamicTransactionEngine.Core.Models;
using Microsoft.Extensions.Logging;

namespace DynamicTransactionEngine.Application.Pipelines;

/// <summary>
/// Ordered pipeline executor. Steps are sorted by Order, then chained
/// using continuation-passing style — equivalent to ASP.NET middleware but
/// for transaction processing.
/// </summary>
public sealed class TransactionPipeline
{
    private readonly IEnumerable<IPipelineStep> _steps;
    private readonly ILogger<TransactionPipeline> _logger;

    public TransactionPipeline(
        IEnumerable<IPipelineStep> steps,
        ILogger<TransactionPipeline> logger)
    {
        _steps = steps.OrderBy(s => s.Order);
        _logger = logger;
    }

    public async Task ExecuteAsync(TransactionContext context)
    {
        var orderedSteps = _steps.ToList();
        _logger.LogDebug(
            "Executing pipeline with {StepCount} steps for {Entity} [{CorrelationId}]",
            orderedSteps.Count, context.Request.TransactionEntityName, context.CorrelationId);

        async Task BuildChain(int index)
        {
            if (index >= orderedSteps.Count) return;
            var step = orderedSteps[index];
            _logger.LogDebug("Pipeline step [{Order}] {StepName}", step.Order, step.GetType().Name);
            await step.ExecuteAsync(context, () => BuildChain(index + 1));
        }

        await BuildChain(0);
    }
}
```

### 4.2 Pipeline Behaviors

```csharp
// DynamicTransactionEngine.Application/Behaviors/ValidationBehavior.cs

using DynamicTransactionEngine.Application.Pipelines;
using DynamicTransactionEngine.Core.Interfaces;
using DynamicTransactionEngine.Core.Models;
using Microsoft.Extensions.Logging;

namespace DynamicTransactionEngine.Application.Behaviors;

public sealed class ValidationBehavior : IPipelineStep
{
    public int Order => 100;

    private readonly IEntityValidator _entityValidator;
    private readonly IForeignKeyValidator _fkValidator;
    private readonly IEnumerable<ITransactionValidator> _customValidators;
    private readonly ILogger<ValidationBehavior> _logger;

    public ValidationBehavior(
        IEntityValidator entityValidator,
        IForeignKeyValidator fkValidator,
        IEnumerable<ITransactionValidator> customValidators,
        ILogger<ValidationBehavior> logger)
    {
        _entityValidator = entityValidator;
        _fkValidator = fkValidator;
        _customValidators = customValidators.OrderBy(v => v.Priority);
        _logger = logger;
    }

    public async Task ExecuteAsync(TransactionContext context, Func<Task> next)
    {
        var errors = new List<ValidationError>();

        // 1. Entity-level validation (table exists, mapper loaded, etc.)
        errors.AddRange(await _entityValidator.ValidateAsync(
            context, context.Operation, context.CancellationToken));

        // 2. FK reference validation
        if (!errors.Any())
        {
            errors.AddRange(await _fkValidator.ValidateReferencesAsync(
                context, context.CancellationToken));
        }

        // 3. Custom business validators (ordered by Priority)
        foreach (var validator in _customValidators)
        {
            errors.AddRange(await validator.ValidateAsync(
                context, context.Operation, context.CancellationToken));
        }

        if (errors.Count > 0)
        {
            context.ValidationErrors.AddRange(errors);
            _logger.LogWarning(
                "Validation failed for {Entity} [{CorrelationId}] with {ErrorCount} error(s)",
                context.Request.TransactionEntityName, context.CorrelationId, errors.Count);
            return; // Short-circuit; do not continue pipeline
        }

        await next();
    }
}
```

```csharp
// DynamicTransactionEngine.Application/Behaviors/AuditBehavior.cs

using DynamicTransactionEngine.Application.Pipelines;
using DynamicTransactionEngine.Core.Contracts;
using DynamicTransactionEngine.Core.Enums;
using DynamicTransactionEngine.Core.Interfaces;
using DynamicTransactionEngine.Core.Models;
using Microsoft.Extensions.Logging;

namespace DynamicTransactionEngine.Application.Behaviors;

public sealed class AuditBehavior : IPipelineStep
{
    public int Order => 900; // Post-execution, pre-commit

    private readonly IAuditService _auditService;
    private readonly ILogger<AuditBehavior> _logger;

    public AuditBehavior(IAuditService auditService, ILogger<AuditBehavior> logger)
    {
        _auditService = auditService;
        _logger = logger;
    }

    public async Task ExecuteAsync(TransactionContext context, Func<Task> next)
    {
        await next();

        if (context.HasErrors) return;

        var metadata = context.EntityMetadata!;

        // Mask sensitive fields before recording
        var previousMasked = MaskSensitiveFields(context.PreviousValues, metadata);
        var newMasked = MaskSensitiveFields(context.ResolvedValues, metadata);

        var entry = new AuditEntry
        {
            CorrelationId = context.CorrelationId,
            UserId = context.UserId,
            EntityName = metadata.EntityName,
            TableName = metadata.TableName,
            Operation = context.Operation,
            PrimaryKeyValue = context.InsertedId ?? GetPrimaryKeyValue(context),
            PreviousValues = previousMasked,
            NewValues = newMasked
        };

        try
        {
            await _auditService.RecordAsync(entry, context.CancellationToken);
        }
        catch (Exception ex)
        {
            // Audit failure must NOT roll back the business transaction
            _logger.LogError(ex,
                "Audit recording failed for {Entity} [{CorrelationId}] — audit gap exists",
                metadata.EntityName, context.CorrelationId);
        }
    }

    private static IReadOnlyDictionary<string, object?> MaskSensitiveFields(
        Dictionary<string, object?> values,
        EntityMetadata metadata)
    {
        var result = new Dictionary<string, object?>(values);
        foreach (var field in metadata.Fields.Where(f => f.IsSensitive))
        {
            if (result.ContainsKey(field.FieldName))
                result[field.FieldName] = "***REDACTED***";
        }
        return result;
    }

    private static object? GetPrimaryKeyValue(TransactionContext context)
    {
        var pk = context.EntityMetadata?.PrimaryKey;
        if (pk is null) return null;
        context.ResolvedValues.TryGetValue(pk.FieldName, out var val);
        return val;
    }
}
```

```csharp
// DynamicTransactionEngine.Application/Behaviors/RetryBehavior.cs

using DynamicTransactionEngine.Application.Pipelines;
using DynamicTransactionEngine.Core.Models;
using Microsoft.Extensions.Logging;
using MySqlConnector;

namespace DynamicTransactionEngine.Application.Behaviors;

/// <summary>
/// Implements exponential backoff retry for deadlock (error 1213) and
/// lock wait timeout (error 1205) scenarios in MySQL.
/// </summary>
public sealed class RetryBehavior : IPipelineStep
{
    public int Order => 50; // Wraps the inner execution steps

    private const int MaxRetries = 3;
    private static readonly TimeSpan BaseDelay = TimeSpan.FromMilliseconds(100);

    private readonly ILogger<RetryBehavior> _logger;

    public RetryBehavior(ILogger<RetryBehavior> logger) => _logger = logger;

    public async Task ExecuteAsync(TransactionContext context, Func<Task> next)
    {
        var attempt = 0;
        while (true)
        {
            try
            {
                await next();
                return;
            }
            catch (MySqlException ex) when (IsRetryable(ex) && attempt < MaxRetries)
            {
                attempt++;
                var delay = BaseDelay * Math.Pow(2, attempt);
                _logger.LogWarning(
                    "Retryable MySQL error {ErrorCode} on attempt {Attempt}/{MaxRetries} "
                    + "for [{CorrelationId}]. Retrying in {DelayMs}ms.",
                    ex.Number, attempt, MaxRetries, context.CorrelationId, delay.TotalMilliseconds);

                await Task.Delay(delay, context.CancellationToken);
            }
        }
    }

    private static bool IsRetryable(MySqlException ex) =>
        ex.Number is 1213 /* Deadlock */ or 1205 /* Lock wait timeout */;
}
```

```csharp
// DynamicTransactionEngine.Application/Behaviors/LoggingBehavior.cs

using System.Diagnostics;
using DynamicTransactionEngine.Application.Pipelines;
using DynamicTransactionEngine.Core.Models;
using Microsoft.Extensions.Logging;

namespace DynamicTransactionEngine.Application.Behaviors;

public sealed class LoggingBehavior : IPipelineStep
{
    public int Order => 10; // Outermost wrapper

    private readonly ILogger<LoggingBehavior> _logger;

    public LoggingBehavior(ILogger<LoggingBehavior> logger) => _logger = logger;

    public async Task ExecuteAsync(TransactionContext context, Func<Task> next)
    {
        var sw = Stopwatch.StartNew();

        _logger.LogInformation(
            "Transaction started: {Operation} on {Entity} [{CorrelationId}] by {UserId}",
            context.Operation, context.Request.TransactionEntityName,
            context.CorrelationId, context.UserId);

        try
        {
            await next();
            sw.Stop();

            _logger.LogInformation(
                "Transaction completed: {Operation} on {Entity} [{CorrelationId}] "
                + "in {ElapsedMs}ms. Success={Success}",
                context.Operation, context.Request.TransactionEntityName,
                context.CorrelationId, sw.ElapsedMilliseconds, !context.HasErrors);
        }
        catch (Exception ex)
        {
            sw.Stop();
            _logger.LogError(ex,
                "Transaction faulted: {Operation} on {Entity} [{CorrelationId}] after {ElapsedMs}ms",
                context.Operation, context.Request.TransactionEntityName,
                context.CorrelationId, sw.ElapsedMilliseconds);
            throw;
        }
    }
}
```

### 4.3 Operation Processors

```csharp
// DynamicTransactionEngine.Application/Processors/InsertProcessor.cs

using DynamicTransactionEngine.Application.Pipelines;
using DynamicTransactionEngine.Core.Interfaces;
using DynamicTransactionEngine.Core.Models;
using Microsoft.Extensions.Logging;

namespace DynamicTransactionEngine.Application.Processors;

public sealed class InsertProcessor : IPipelineStep
{
    public int Order => 500;

    private readonly IQueryBuilder _queryBuilder;
    private readonly ITransactionRepository _repository;
    private readonly ILogger<InsertProcessor> _logger;

    public InsertProcessor(
        IQueryBuilder queryBuilder,
        ITransactionRepository repository,
        ILogger<InsertProcessor> logger)
    {
        _queryBuilder = queryBuilder;
        _repository = repository;
        _logger = logger;
    }

    public async Task ExecuteAsync(TransactionContext context, Func<Task> next)
    {
        var metadata = context.EntityMetadata!;

        // Resolve defaults for missing fields
        foreach (var field in metadata.InsertableFields)
        {
            if (!context.ResolvedValues.ContainsKey(field.FieldName)
                && field.DefaultValue is not null)
            {
                context.ResolvedValues[field.FieldName] = field.DefaultValue;
            }
        }

        // If this is a child context, inject the parent FK value
        if (context.IsChildContext
            && context.ParentForeignKeyColumn is not null
            && context.ParentInsertedId is not null)
        {
            context.ResolvedValues[context.ParentForeignKeyColumn] = context.ParentInsertedId;
        }

        var query = _queryBuilder.BuildInsertQuery(metadata, context.ResolvedValues);

        _logger.LogDebug(
            "Executing INSERT on {Table} [{CorrelationId}]",
            metadata.TableName, context.CorrelationId);

        context.InsertedId = await _repository.ExecuteInsertAsync(
            query, context.DbTransaction!, context.CancellationToken);

        await next();
    }
}
```

```csharp
// DynamicTransactionEngine.Application/Processors/UpdateProcessor.cs

using DynamicTransactionEngine.Application.Pipelines;
using DynamicTransactionEngine.Core.Interfaces;
using DynamicTransactionEngine.Core.Models;
using Microsoft.Extensions.Logging;

namespace DynamicTransactionEngine.Application.Processors;

public sealed class UpdateProcessor : IPipelineStep
{
    public int Order => 500;

    private readonly IQueryBuilder _queryBuilder;
    private readonly ITransactionRepository _repository;
    private readonly ILogger<UpdateProcessor> _logger;

    public UpdateProcessor(
        IQueryBuilder queryBuilder,
        ITransactionRepository repository,
        ILogger<UpdateProcessor> logger)
    {
        _queryBuilder = queryBuilder;
        _repository = repository;
        _logger = logger;
    }

    public async Task ExecuteAsync(TransactionContext context, Func<Task> next)
    {
        var metadata = context.EntityMetadata!;
        var pk = metadata.PrimaryKey
            ?? throw new InvalidOperationException(
                $"No primary key defined for entity '{metadata.EntityName}'.");

        if (!context.ResolvedValues.TryGetValue(pk.FieldName, out var pkValue) || pkValue is null)
            throw new InvalidOperationException(
                $"Primary key field '{pk.FieldName}' not present in request for UPDATE.");

        // Load previous values for audit and change-detection
        var selectQuery = _queryBuilder.BuildSelectQuery(metadata, pkValue);
        context.PreviousValues = await _repository.QuerySingleAsync(
            selectQuery, context.DbTransaction!, context.CancellationToken)
            ?? new Dictionary<string, object?>();

        // Filter to only updatable, changed fields
        var changed = metadata.UpdatableFields
            .Where(f => context.ResolvedValues.ContainsKey(f.FieldName)
                && !Equals(context.ResolvedValues[f.FieldName],
                           context.PreviousValues.GetValueOrDefault(f.FieldName)))
            .ToDictionary(f => f.FieldName, f => context.ResolvedValues[f.FieldName]);

        if (changed.Count == 0)
        {
            _logger.LogInformation(
                "No changed fields detected for UPDATE on {Entity} [{CorrelationId}]. Skipping.",
                metadata.EntityName, context.CorrelationId);
            await next();
            return;
        }

        var query = _queryBuilder.BuildUpdateQuery(metadata, changed, pkValue);

        await _repository.ExecuteAsync(
            query, context.DbTransaction!, context.CancellationToken);

        await next();
    }
}
```

```csharp
// DynamicTransactionEngine.Application/Processors/DeleteProcessor.cs

using DynamicTransactionEngine.Application.Pipelines;
using DynamicTransactionEngine.Core.Enums;
using DynamicTransactionEngine.Core.Interfaces;
using DynamicTransactionEngine.Core.Models;
using Microsoft.Extensions.Logging;

namespace DynamicTransactionEngine.Application.Processors;

public sealed class DeleteProcessor : IPipelineStep
{
    public int Order => 500;

    private readonly IQueryBuilder _queryBuilder;
    private readonly ITransactionRepository _repository;
    private readonly IForeignKeyValidator _fkValidator;
    private readonly ILogger<DeleteProcessor> _logger;

    public DeleteProcessor(
        IQueryBuilder queryBuilder,
        ITransactionRepository repository,
        IForeignKeyValidator fkValidator,
        ILogger<DeleteProcessor> logger)
    {
        _queryBuilder = queryBuilder;
        _repository = repository;
        _fkValidator = fkValidator;
        _logger = logger;
    }

    public async Task ExecuteAsync(TransactionContext context, Func<Task> next)
    {
        var metadata = context.EntityMetadata!;
        var pk = metadata.PrimaryKey!;

        if (!context.ResolvedValues.TryGetValue(pk.FieldName, out var pkValue) || pkValue is null)
            throw new InvalidOperationException(
                $"Primary key not found in request for DELETE on '{metadata.EntityName}'.");

        // Validate dependents before delete
        var dependentErrors = await _fkValidator.ValidateDependentsAsync(
            context, context.CancellationToken);

        if (dependentErrors.Count > 0)
        {
            context.ValidationErrors.AddRange(dependentErrors);
            return;
        }

        // Load current state for audit
        var selectQuery = _queryBuilder.BuildSelectQuery(metadata, pkValue);
        context.PreviousValues = await _repository.QuerySingleAsync(
            selectQuery, context.DbTransaction!, context.CancellationToken)
            ?? new Dictionary<string, object?>();

        var softDelete = metadata.SoftDeleteField is not null;
        var query = _queryBuilder.BuildDeleteQuery(metadata, pkValue, softDelete);

        _logger.LogDebug(
            "Executing {DeleteMode} DELETE on {Table} pk={PkValue} [{CorrelationId}]",
            softDelete ? "soft" : "hard", metadata.TableName, pkValue, context.CorrelationId);

        await _repository.ExecuteAsync(query, context.DbTransaction!, context.CancellationToken);

        await next();
    }
}
```

```csharp
// DynamicTransactionEngine.Application/Processors/ChildEntityProcessor.cs

using DynamicTransactionEngine.Core.Enums;
using DynamicTransactionEngine.Core.Interfaces;
using DynamicTransactionEngine.Core.Models;
using Microsoft.Extensions.Logging;

namespace DynamicTransactionEngine.Application.Processors;

/// <summary>
/// Recursive child entity processor. Handles nested renProps (upsert) and
/// delProps (delete) payloads. Parent FK is propagated automatically from
/// the parent TransactionContext.
/// </summary>
public sealed class ChildEntityProcessor
{
    private readonly IFieldMapperProvider _mapperProvider;
    private readonly ITransactionProcessor _processor;
    private readonly ILogger<ChildEntityProcessor> _logger;

    public ChildEntityProcessor(
        IFieldMapperProvider mapperProvider,
        ITransactionProcessor processor,
        ILogger<ChildEntityProcessor> logger)
    {
        _mapperProvider = mapperProvider;
        _processor = processor;
        _logger = logger;
    }

    public async Task ProcessChildrenAsync(
        TransactionContext parentContext,
        CancellationToken cancellationToken = default)
    {
        var request = parentContext.Request;

        // Process upsert children (renProps)
        foreach (var (childEntity, rows) in request.RenProps)
        {
            _logger.LogDebug(
                "Processing {RowCount} child rows for entity '{ChildEntity}' "
                + "under parent '{ParentEntity}' [{CorrelationId}]",
                rows.Count, childEntity, request.TransactionEntityName, parentContext.CorrelationId);

            foreach (var row in rows)
            {
                var childRequest = BuildChildRequest(request, childEntity, row);
                var childContext = await BuildChildContext(
                    parentContext, childRequest, childEntity, cancellationToken);

                // Determine insert vs update by presence of PK in the child row
                var childMetadata = await _mapperProvider.GetEntityMetadataAsync(
                    childEntity, cancellationToken);
                var pkField = childMetadata.PrimaryKey;
                var isUpdate = pkField is not null
                    && row.ContainsKey(pkField.FieldName)
                    && row[pkField.FieldName] is not null;

                TransactionResult result;
                if (isUpdate)
                    result = await _processor.UpdateAsync(childRequest, cancellationToken);
                else
                    result = await _processor.InsertAsync(childRequest, cancellationToken);

                if (!result.Success)
                {
                    // Propagate failures upward to trigger rollback
                    parentContext.ValidationErrors.AddRange(result.ValidationErrors);
                    throw new InvalidOperationException(
                        $"Child entity '{childEntity}' processing failed: {result.Message}");
                }
            }
        }

        // Process delete children (delProps)
        foreach (var (childEntity, rows) in request.DelProps)
        {
            foreach (var row in rows)
            {
                var childRequest = BuildChildRequest(request, childEntity, row);
                var result = await _processor.DeleteAsync(childRequest, cancellationToken);

                if (!result.Success)
                {
                    parentContext.ValidationErrors.AddRange(result.ValidationErrors);
                    throw new InvalidOperationException(
                        $"Child entity delete '{childEntity}' failed: {result.Message}");
                }
            }
        }
    }

    private static TransactionRequest BuildChildRequest(
        TransactionRequest parent,
        string childEntity,
        Dictionary<string, object?> row) =>
        new()
        {
            TransactionEntityName = childEntity,
            TransactionId = parent.TransactionId,
            UserId = parent.UserId,
            ExtendedProperties = row,
            UseModelBinding = false
        };

    private async Task<TransactionContext> BuildChildContext(
        TransactionContext parentContext,
        TransactionRequest childRequest,
        string childEntity,
        CancellationToken cancellationToken)
    {
        var childMetadata = await _mapperProvider.GetEntityMetadataAsync(
            childEntity, cancellationToken);

        // Find the FK field in the child that points back to the parent
        var parentFkField = childMetadata.Fields.FirstOrDefault(f =>
            f.IsForeignKey
            && string.Equals(f.ForeignKeyEntity,
                             parentContext.Request.TransactionEntityName,
                             StringComparison.OrdinalIgnoreCase));

        return new TransactionContext
        {
            CorrelationId = parentContext.CorrelationId,
            UserId = parentContext.UserId,
            Operation = TransactionOperation.Insert,
            Request = childRequest,
            DbTransaction = parentContext.DbTransaction,
            IsChildContext = true,
            ParentEntityName = parentContext.Request.TransactionEntityName,
            ParentInsertedId = parentContext.InsertedId,
            ParentForeignKeyColumn = parentFkField?.FieldName,
            CancellationToken = cancellationToken
        };
    }
}
```

### 4.4 Transaction Orchestrator

```csharp
// DynamicTransactionEngine.Application/Services/TransactionOrchestrator.cs

using System.Data;
using System.Diagnostics;
using DynamicTransactionEngine.Application.Processors;
using DynamicTransactionEngine.Core.Enums;
using DynamicTransactionEngine.Core.Interfaces;
using DynamicTransactionEngine.Core.Models;
using Microsoft.Extensions.Logging;

namespace DynamicTransactionEngine.Application.Services;

/// <summary>
/// Central orchestration service. Manages the DB transaction lifecycle,
/// delegates to operation-specific processors, and coordinates child processing.
/// This is the only public entry point intended to be consumed by host applications.
/// </summary>
public sealed class TransactionOrchestrator : ITransactionProcessor
{
    private readonly IConnectionFactory _connectionFactory;
    private readonly IFieldMapperProvider _mapperProvider;
    private readonly InsertProcessorFactory _insertFactory;
    private readonly UpdateProcessorFactory _updateFactory;
    private readonly DeleteProcessorFactory _deleteFactory;
    private readonly ChildEntityProcessor _childProcessor;
    private readonly IEnumerable<ITriggerService> _triggers;
    private readonly ILogger<TransactionOrchestrator> _logger;

    public TransactionOrchestrator(
        IConnectionFactory connectionFactory,
        IFieldMapperProvider mapperProvider,
        InsertProcessorFactory insertFactory,
        UpdateProcessorFactory updateFactory,
        DeleteProcessorFactory deleteFactory,
        ChildEntityProcessor childProcessor,
        IEnumerable<ITriggerService> triggers,
        ILogger<TransactionOrchestrator> logger)
    {
        _connectionFactory = connectionFactory;
        _mapperProvider = mapperProvider;
        _insertFactory = insertFactory;
        _updateFactory = updateFactory;
        _deleteFactory = deleteFactory;
        _childProcessor = childProcessor;
        _triggers = triggers.OrderBy(t => t.Priority);
        _logger = logger;
    }

    public Task<TransactionResult> InsertAsync(
        TransactionRequest request,
        CancellationToken cancellationToken = default) =>
        ExecuteWithTransactionAsync(request, TransactionOperation.Insert,
            _insertFactory.Build(), cancellationToken);

    public Task<TransactionResult> UpdateAsync(
        TransactionRequest request,
        CancellationToken cancellationToken = default) =>
        ExecuteWithTransactionAsync(request, TransactionOperation.Update,
            _updateFactory.Build(), cancellationToken);

    public Task<TransactionResult> DeleteAsync(
        TransactionRequest request,
        CancellationToken cancellationToken = default) =>
        ExecuteWithTransactionAsync(request, TransactionOperation.Delete,
            _deleteFactory.Build(), cancellationToken);

    private async Task<TransactionResult> ExecuteWithTransactionAsync(
        TransactionRequest request,
        TransactionOperation operation,
        TransactionPipeline pipeline,
        CancellationToken cancellationToken)
    {
        var correlationId = Guid.NewGuid().ToString("N");
        var sw = Stopwatch.StartNew();

        ValidateRequest(request);

        var metadata = await _mapperProvider.GetEntityMetadataAsync(
            request.TransactionEntityName, cancellationToken);

        var resolved = ResolveValues(request, metadata);

        await using var connection = await _connectionFactory.CreateAsync(cancellationToken);
        await using var dbTransaction = await connection.BeginTransactionAsync(
            IsolationLevel.ReadCommitted, cancellationToken);

        var context = new TransactionContext
        {
            CorrelationId = correlationId,
            UserId = request.UserId,
            Operation = operation,
            Request = request,
            EntityMetadata = metadata,
            DbTransaction = dbTransaction,
            ResolvedValues = resolved,
            CancellationToken = cancellationToken
        };

        try
        {
            await pipeline.ExecuteAsync(context);

            if (context.HasErrors)
            {
                await dbTransaction.RollbackAsync(cancellationToken);
                return TransactionResult.Fail(
                    request.TransactionId,
                    $"Validation failed for '{request.TransactionEntityName}'.",
                    context.ValidationErrors);
            }

            // Process child records within the same DB transaction
            await _childProcessor.ProcessChildrenAsync(context, cancellationToken);

            if (context.HasErrors)
            {
                await dbTransaction.RollbackAsync(cancellationToken);
                return TransactionResult.Fail(
                    request.TransactionId,
                    "Child entity processing failed.",
                    context.ValidationErrors);
            }

            await dbTransaction.CommitAsync(cancellationToken);

            // Fire post-commit triggers (non-blocking by design)
            FireTriggers(context, cancellationToken);

            var result = TransactionResult.Ok(request.TransactionId);
            result.ElapsedMilliseconds = sw.ElapsedMilliseconds;
            if (context.InsertedId is not null)
                result.Data["insertedId"] = context.InsertedId;

            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Transaction faulted for {Entity} [{CorrelationId}]. Rolling back.",
                request.TransactionEntityName, correlationId);

            try { await dbTransaction.RollbackAsync(CancellationToken.None); }
            catch (Exception rollbackEx)
            {
                _logger.LogCritical(rollbackEx,
                    "Rollback failed for [{CorrelationId}]", correlationId);
            }

            return new TransactionResult
            {
                Success = false,
                TransactionId = request.TransactionId,
                Message = ex.Message,
                Exception = ex,
                ElapsedMilliseconds = sw.ElapsedMilliseconds,
                CorrelationId = correlationId
            };
        }
    }

    private void FireTriggers(TransactionContext context, CancellationToken cancellationToken)
    {
        // Intentionally not awaited — triggers are fire-and-forget
        _ = Task.Run(async () =>
        {
            foreach (var trigger in _triggers)
            {
                try
                {
                    await trigger.ExecuteAsync(context, cancellationToken);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex,
                        "Trigger {TriggerType} failed for [{CorrelationId}]",
                        trigger.GetType().Name, context.CorrelationId);
                }
            }
        }, CancellationToken.None);
    }

    private static void ValidateRequest(TransactionRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.TransactionEntityName))
            throw new ArgumentException(
                "TransactionEntityName must not be empty.", nameof(request));
    }

    private static Dictionary<string, object?> ResolveValues(
        TransactionRequest request,
        EntityMetadata metadata)
    {
        // In mapper-driven mode, use ExtendedProperties directly
        // In model binding mode, reflect the entity properties
        return request.ExtendedProperties
            .ToDictionary(kv => kv.Key, kv => kv.Value);
    }
}
```

---

## 5. Infrastructure Layer

### 5.1 Connection Factory

```csharp
// DynamicTransactionEngine.Infrastructure/Database/IConnectionFactory.cs

using MySqlConnector;

namespace DynamicTransactionEngine.Infrastructure.Database;

public interface IConnectionFactory
{
    Task<MySqlConnection> CreateAsync(CancellationToken cancellationToken = default);
}
```

```csharp
// DynamicTransactionEngine.Infrastructure/Database/DbConnectionScope.cs

using DynamicTransactionEngine.Core.Interfaces;
using MySqlConnector;
using Microsoft.Extensions.Options;

namespace DynamicTransactionEngine.Infrastructure.Database;

public sealed class DbConnectionScope : IConnectionFactory
{
    private readonly string _connectionString;

    public DbConnectionScope(IOptions<DatabaseOptions> options)
    {
        _connectionString = options.Value.ConnectionString
            ?? throw new InvalidOperationException("ConnectionString is not configured.");
    }

    public async Task<MySqlConnection> CreateAsync(CancellationToken cancellationToken = default)
    {
        var connection = new MySqlConnection(_connectionString);
        await connection.OpenAsync(cancellationToken);
        return connection;
    }
}

public sealed class DatabaseOptions
{
    public const string Section = "DynamicTransactionEngine:Database";
    public required string ConnectionString { get; set; }
    public int CommandTimeoutSeconds { get; set; } = 30;
    public int MaxRetryCount { get; set; } = 3;
}
```

### 5.2 Repositories

```csharp
// DynamicTransactionEngine.Infrastructure/Repositories/TransactionRepository.cs

using System.Data;
using DynamicTransactionEngine.Core.Contracts;
using DynamicTransactionEngine.Core.Interfaces;
using Microsoft.Extensions.Logging;
using MySqlConnector;

namespace DynamicTransactionEngine.Infrastructure.Repositories;

public interface ITransactionRepository
{
    Task<object?> ExecuteInsertAsync(
        QueryDefinition query,
        IDbTransaction transaction,
        CancellationToken cancellationToken = default);

    Task<int> ExecuteAsync(
        QueryDefinition query,
        IDbTransaction transaction,
        CancellationToken cancellationToken = default);

    Task<Dictionary<string, object?>> QuerySingleAsync(
        QueryDefinition query,
        IDbTransaction transaction,
        CancellationToken cancellationToken = default);
}

public sealed class TransactionRepository : ITransactionRepository
{
    private readonly ILogger<TransactionRepository> _logger;
    private readonly DatabaseOptions _options;

    public TransactionRepository(
        ILogger<TransactionRepository> logger,
        Microsoft.Extensions.Options.IOptions<DatabaseOptions> options)
    {
        _logger = logger;
        _options = options.Value;
    }

    public async Task<object?> ExecuteInsertAsync(
        QueryDefinition query,
        IDbTransaction transaction,
        CancellationToken cancellationToken = default)
    {
        using var cmd = CreateCommand(query, transaction);
        var result = await cmd.ExecuteScalarAsync(cancellationToken);
        return result == DBNull.Value ? null : result;
    }

    public async Task<int> ExecuteAsync(
        QueryDefinition query,
        IDbTransaction transaction,
        CancellationToken cancellationToken = default)
    {
        using var cmd = CreateCommand(query, transaction);
        return await cmd.ExecuteNonQueryAsync(cancellationToken);
    }

    public async Task<Dictionary<string, object?>> QuerySingleAsync(
        QueryDefinition query,
        IDbTransaction transaction,
        CancellationToken cancellationToken = default)
    {
        using var cmd = CreateCommand(query, transaction);
        await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);

        if (!await reader.ReadAsync(cancellationToken))
            return new Dictionary<string, object?>();

        var result = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase);
        for (var i = 0; i < reader.FieldCount; i++)
        {
            var value = reader.GetValue(i);
            result[reader.GetName(i)] = value == DBNull.Value ? null : value;
        }
        return result;
    }

    private MySqlCommand CreateCommand(QueryDefinition query, IDbTransaction transaction)
    {
        var cmd = new MySqlCommand(query.Sql, (MySqlConnection)transaction.Connection!)
        {
            Transaction = (MySqlTransaction)transaction,
            CommandTimeout = query.CommandTimeoutSeconds ?? _options.CommandTimeoutSeconds
        };

        foreach (var (key, value) in query.Parameters)
        {
            cmd.Parameters.AddWithValue(key, value ?? DBNull.Value);
        }

        return cmd;
    }
}
```

```csharp
// DynamicTransactionEngine.Infrastructure/Repositories/MapperRepository.cs

using DynamicTransactionEngine.Core.Models;
using MySqlConnector;
using Microsoft.Extensions.Options;
using DynamicTransactionEngine.Core.Enums;

namespace DynamicTransactionEngine.Infrastructure.Repositories;

public sealed class MapperRepository
{
    private readonly string _connectionString;

    public MapperRepository(IOptions<DatabaseOptions> options)
    {
        _connectionString = options.Value.ConnectionString;
    }

    public async Task<IReadOnlyList<FieldMapper>> LoadAsync(
        string entityName,
        CancellationToken cancellationToken = default)
    {
        const string sql = """
            SELECT
                Id, EntityName, FieldName, ColumnName, DataType,
                Properties, DefaultValue, ForeignKeyEntity,
                ForeignKeyColumn, CascadeRule, MaxLength,
                ValidationRegex, Classification, SortOrder
            FROM FieldMapper
            WHERE EntityName = @EntityName
              AND IsActive = 1
            ORDER BY SortOrder ASC;
            """;

        await using var conn = new MySqlConnection(_connectionString);
        await conn.OpenAsync(cancellationToken);

        await using var cmd = new MySqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@EntityName", entityName);

        await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);
        var result = new List<FieldMapper>();

        while (await reader.ReadAsync(cancellationToken))
        {
            result.Add(new FieldMapper
            {
                Id = reader.GetInt32("Id"),
                EntityName = reader.GetString("EntityName"),
                FieldName = reader.GetString("FieldName"),
                ColumnName = reader.GetString("ColumnName"),
                DataType = reader.GetString("DataType"),
                Properties = (FieldProperty)reader.GetInt32("Properties"),
                DefaultValue = reader.IsDBNull("DefaultValue")
                    ? null : reader.GetString("DefaultValue"),
                ForeignKeyEntity = reader.IsDBNull("ForeignKeyEntity")
                    ? null : reader.GetString("ForeignKeyEntity"),
                ForeignKeyColumn = reader.IsDBNull("ForeignKeyColumn")
                    ? null : reader.GetString("ForeignKeyColumn"),
                CascadeRule = (CascadeRule)reader.GetInt32("CascadeRule"),
                MaxLength = reader.IsDBNull("MaxLength")
                    ? null : reader.GetInt32("MaxLength"),
                ValidationRegex = reader.IsDBNull("ValidationRegex")
                    ? null : reader.GetString("ValidationRegex"),
                Classification = (DataClassification)reader.GetInt32("Classification"),
                SortOrder = reader.GetInt32("SortOrder")
            });
        }

        return result;
    }
}
```

### 5.3 Metadata Cache

```csharp
// DynamicTransactionEngine.Infrastructure/Caching/MetadataCacheService.cs

using DynamicTransactionEngine.Core.Interfaces;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;

namespace DynamicTransactionEngine.Infrastructure.Caching;

public sealed class MetadataCacheService : IMetadataCacheService
{
    private readonly IMemoryCache _cache;
    private readonly ILogger<MetadataCacheService> _logger;
    private static readonly TimeSpan DefaultExpiry = TimeSpan.FromMinutes(30);

    public MetadataCacheService(IMemoryCache cache, ILogger<MetadataCacheService> logger)
    {
        _cache = cache;
        _logger = logger;
    }

    public Task<T?> GetAsync<T>(string key)
    {
        _cache.TryGetValue(key, out T? value);
        return Task.FromResult(value);
    }

    public Task SetAsync<T>(string key, T value, TimeSpan? expiry = null)
    {
        var options = new MemoryCacheEntryOptions
        {
            AbsoluteExpirationRelativeToNow = expiry ?? DefaultExpiry,
            SlidingExpiration = TimeSpan.FromMinutes(5),
            Priority = CacheItemPriority.High
        };

        _cache.Set(key, value, options);
        _logger.LogDebug("Cache SET: {Key} (expiry={Expiry})", key, expiry ?? DefaultExpiry);
        return Task.CompletedTask;
    }

    public Task RemoveAsync(string key)
    {
        _cache.Remove(key);
        _logger.LogDebug("Cache EVICT: {Key}", key);
        return Task.CompletedTask;
    }

    public Task<bool> ExistsAsync(string key) =>
        Task.FromResult(_cache.TryGetValue(key, out _));
}
```

```csharp
// DynamicTransactionEngine.Infrastructure/Caching/CacheKeyProvider.cs

namespace DynamicTransactionEngine.Infrastructure.Caching;

public static class CacheKeyProvider
{
    private const string Prefix = "DTE";

    public static string EntityMetadata(string entityName) =>
        $"{Prefix}:metadata:{entityName.ToUpperInvariant()}";

    public static string ForeignKeys(string tableName) =>
        $"{Prefix}:fk:{tableName.ToUpperInvariant()}";

    public static string FieldMappers(string entityName) =>
        $"{Prefix}:mappers:{entityName.ToUpperInvariant()}";

    public static string TableExists(string tableName) =>
        $"{Prefix}:tablecheck:{tableName.ToUpperInvariant()}";
}
```

### 5.4 Field Mapper Provider

```csharp
// DynamicTransactionEngine.Infrastructure/Providers/FieldMapperProvider.cs

using DynamicTransactionEngine.Core.Exceptions;
using DynamicTransactionEngine.Core.Interfaces;
using DynamicTransactionEngine.Core.Models;
using DynamicTransactionEngine.Infrastructure.Caching;
using DynamicTransactionEngine.Infrastructure.Repositories;

namespace DynamicTransactionEngine.Infrastructure.Providers;

public sealed class FieldMapperProvider : IFieldMapperProvider
{
    private readonly MapperRepository _mapperRepository;
    private readonly ISchemaProvider _schemaProvider;
    private readonly IMetadataCacheService _cache;

    public FieldMapperProvider(
        MapperRepository mapperRepository,
        ISchemaProvider schemaProvider,
        IMetadataCacheService cache)
    {
        _mapperRepository = mapperRepository;
        _schemaProvider = schemaProvider;
        _cache = cache;
    }

    public async Task<EntityMetadata> GetEntityMetadataAsync(
        string entityName,
        CancellationToken cancellationToken = default)
    {
        var cacheKey = CacheKeyProvider.EntityMetadata(entityName);
        var cached = await _cache.GetAsync<EntityMetadata>(cacheKey);
        if (cached is not null) return cached;

        var fields = await _mapperRepository.LoadAsync(entityName, cancellationToken);

        if (fields.Count == 0)
            throw new EntityNotFoundException(
                $"No field mappings found for entity '{entityName}'. "
                + "Ensure the entity is registered in the FieldMapper table.");

        var fkKey = CacheKeyProvider.ForeignKeys(entityName);
        var foreignKeys = await _cache.GetAsync<IReadOnlyList<ForeignKeyMetadata>>(fkKey)
            ?? await _schemaProvider.GetForeignKeysAsync(entityName, cancellationToken);

        await _cache.SetAsync(fkKey, foreignKeys);

        // Infer table name from the entity name convention
        // or allow a separate TableName column in FieldMapper
        var tableName = entityName;

        var metadata = new EntityMetadata
        {
            EntityName = entityName,
            TableName = tableName,
            Fields = fields,
            ForeignKeys = foreignKeys
        };

        await _cache.SetAsync(cacheKey, metadata);
        return metadata;
    }

    public async Task<IReadOnlyList<FieldMapper>> GetFieldMappersAsync(
        string entityName,
        CancellationToken cancellationToken = default)
    {
        var meta = await GetEntityMetadataAsync(entityName, cancellationToken);
        return meta.Fields;
    }

    public async Task InvalidateCacheAsync(string entityName)
    {
        await _cache.RemoveAsync(CacheKeyProvider.EntityMetadata(entityName));
        await _cache.RemoveAsync(CacheKeyProvider.FieldMappers(entityName));
        await _cache.RemoveAsync(CacheKeyProvider.ForeignKeys(entityName));
    }
}
```

### 5.5 Audit Service

```csharp
// DynamicTransactionEngine.Infrastructure/Auditing/AuditService.cs

using System.Text.Json;
using DynamicTransactionEngine.Core.Contracts;
using DynamicTransactionEngine.Core.Interfaces;
using DynamicTransactionEngine.Infrastructure.Database;
using Microsoft.Extensions.Logging;
using MySqlConnector;

namespace DynamicTransactionEngine.Infrastructure.Auditing;

public sealed class AuditService : IAuditService
{
    private readonly IConnectionFactory _connectionFactory;
    private readonly ILogger<AuditService> _logger;

    public AuditService(
        IConnectionFactory connectionFactory,
        ILogger<AuditService> logger)
    {
        _connectionFactory = connectionFactory;
        _logger = logger;
    }

    public async Task RecordAsync(AuditEntry entry, CancellationToken cancellationToken = default)
    {
        // Audit writes to a separate connection — never participates in the business transaction
        const string sql = """
            INSERT INTO AuditLog
                (CorrelationId, UserId, EntityName, TableName, Operation,
                 PrimaryKeyValue, PreviousValues, NewValues, OccurredAt, MachineName)
            VALUES
                (@CorrelationId, @UserId, @EntityName, @TableName, @Operation,
                 @PrimaryKeyValue, @PreviousValues, @NewValues, @OccurredAt, @MachineName);
            """;

        try
        {
            await using var conn = await _connectionFactory.CreateAsync(cancellationToken);
            await using var cmd = new MySqlCommand(sql, conn);

            cmd.Parameters.AddWithValue("@CorrelationId", entry.CorrelationId);
            cmd.Parameters.AddWithValue("@UserId", entry.UserId);
            cmd.Parameters.AddWithValue("@EntityName", entry.EntityName);
            cmd.Parameters.AddWithValue("@TableName", entry.TableName);
            cmd.Parameters.AddWithValue("@Operation", entry.Operation.ToString());
            cmd.Parameters.AddWithValue("@PrimaryKeyValue",
                entry.PrimaryKeyValue?.ToString() ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@PreviousValues",
                JsonSerializer.Serialize(entry.PreviousValues));
            cmd.Parameters.AddWithValue("@NewValues",
                JsonSerializer.Serialize(entry.NewValues));
            cmd.Parameters.AddWithValue("@OccurredAt", entry.OccurredAt.UtcDateTime);
            cmd.Parameters.AddWithValue("@MachineName",
                entry.MachineName ?? (object)DBNull.Value);

            await cmd.ExecuteNonQueryAsync(cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Failed to write audit entry for [{CorrelationId}]", entry.CorrelationId);
            // Do not rethrow — audit failure must not affect business operations
        }
    }
}
```

---

## 6. MySQL Provider Layer

```csharp
// DynamicTransactionEngine.MySql/MySqlQueryBuilder.cs

using DynamicTransactionEngine.Core.Contracts;
using DynamicTransactionEngine.Core.Interfaces;
using DynamicTransactionEngine.Core.Models;
using DynamicTransactionEngine.Core.Validators;
using System.Text;

namespace DynamicTransactionEngine.MySql;

/// <summary>
/// MySQL-specific query builder. All identifiers pass through IdentifierValidator
/// before being embedded in SQL. All values are parameterized — zero concatenation.
/// </summary>
public sealed class MySqlQueryBuilder : IQueryBuilder
{
    public QueryDefinition BuildInsertQuery(
        EntityMetadata metadata,
        IReadOnlyDictionary<string, object?> values)
    {
        var table = EscapeIdentifier(metadata.TableName);
        var insertableFields = metadata.InsertableFields
            .Where(f => values.ContainsKey(f.FieldName))
            .ToList();

        if (insertableFields.Count == 0)
            throw new InvalidOperationException(
                $"No insertable fields resolved for entity '{metadata.EntityName}'.");

        var columns = new StringBuilder();
        var parameters = new StringBuilder();
        var paramDict = new Dictionary<string, object?>();

        for (var i = 0; i < insertableFields.Count; i++)
        {
            var field = insertableFields[i];
            var col = EscapeIdentifier(field.ColumnName);
            var param = $"@p_{field.ColumnName}";

            if (i > 0) { columns.Append(", "); parameters.Append(", "); }
            columns.Append(col);
            parameters.Append(param);
            paramDict[param] = values[field.FieldName];
        }

        // LAST_INSERT_ID() returns the auto-increment value after INSERT
        var sql = $"INSERT INTO {table} ({columns}) VALUES ({parameters}); SELECT LAST_INSERT_ID();";

        return QueryDefinition.Create(sql, paramDict);
    }

    public QueryDefinition BuildUpdateQuery(
        EntityMetadata metadata,
        IReadOnlyDictionary<string, object?> values,
        object primaryKeyValue)
    {
        var table = EscapeIdentifier(metadata.TableName);
        var pk = metadata.PrimaryKey!;
        var pkCol = EscapeIdentifier(pk.ColumnName);

        var setClauses = new StringBuilder();
        var paramDict = new Dictionary<string, object?>();
        var first = true;

        foreach (var field in metadata.UpdatableFields.Where(f => values.ContainsKey(f.FieldName)))
        {
            if (!first) setClauses.Append(", ");
            var col = EscapeIdentifier(field.ColumnName);
            var param = $"@p_{field.ColumnName}";
            setClauses.Append($"{col} = {param}");
            paramDict[param] = values[field.FieldName];
            first = false;
        }

        if (first)
            throw new InvalidOperationException(
                $"No updatable fields found in request for '{metadata.EntityName}'.");

        paramDict["@pk"] = primaryKeyValue;
        var sql = $"UPDATE {table} SET {setClauses} WHERE {pkCol} = @pk;";

        return QueryDefinition.Create(sql, paramDict);
    }

    public QueryDefinition BuildDeleteQuery(
        EntityMetadata metadata,
        object primaryKeyValue,
        bool softDelete)
    {
        var table = EscapeIdentifier(metadata.TableName);
        var pk = metadata.PrimaryKey!;
        var pkCol = EscapeIdentifier(pk.ColumnName);
        var paramDict = new Dictionary<string, object?> { ["@pk"] = primaryKeyValue };

        string sql;
        if (softDelete && metadata.SoftDeleteField is { } softField)
        {
            var softCol = EscapeIdentifier(softField.ColumnName);
            sql = $"UPDATE {table} SET {softCol} = 1 WHERE {pkCol} = @pk;";
        }
        else
        {
            sql = $"DELETE FROM {table} WHERE {pkCol} = @pk;";
        }

        return QueryDefinition.Create(sql, paramDict);
    }

    public QueryDefinition BuildSelectQuery(
        EntityMetadata metadata,
        object primaryKeyValue)
    {
        var table = EscapeIdentifier(metadata.TableName);
        var pk = metadata.PrimaryKey!;
        var pkCol = EscapeIdentifier(pk.ColumnName);
        var paramDict = new Dictionary<string, object?> { ["@pk"] = primaryKeyValue };
        var sql = $"SELECT * FROM {table} WHERE {pkCol} = @pk LIMIT 1;";
        return QueryDefinition.Create(sql, paramDict);
    }

    public QueryDefinition BuildExistsQuery(
        string tableName,
        string columnName,
        object value)
    {
        var table = EscapeIdentifier(tableName);
        var col = EscapeIdentifier(columnName);
        var paramDict = new Dictionary<string, object?> { ["@val"] = value };
        var sql = $"SELECT 1 FROM {table} WHERE {col} = @val LIMIT 1;";
        return QueryDefinition.Create(sql, paramDict);
    }

    public string EscapeIdentifier(string identifier)
    {
        IdentifierValidator.Validate(identifier);
        return $"`{identifier}`";
    }
}
```

```csharp
// DynamicTransactionEngine.MySql/MySqlSchemaProvider.cs

using DynamicTransactionEngine.Core.Enums;
using DynamicTransactionEngine.Core.Interfaces;
using DynamicTransactionEngine.Core.Models;
using DynamicTransactionEngine.Infrastructure.Caching;
using DynamicTransactionEngine.Infrastructure.Database;
using MySqlConnector;

namespace DynamicTransactionEngine.MySql;

public sealed class MySqlSchemaProvider : ISchemaProvider
{
    private readonly IConnectionFactory _connectionFactory;
    private readonly IMetadataCacheService _cache;

    public MySqlSchemaProvider(
        IConnectionFactory connectionFactory,
        IMetadataCacheService cache)
    {
        _connectionFactory = connectionFactory;
        _cache = cache;
    }

    public async Task<bool> TableExistsAsync(
        string tableName,
        CancellationToken cancellationToken = default)
    {
        var cacheKey = CacheKeyProvider.TableExists(tableName);
        var cached = await _cache.GetAsync<bool?>(cacheKey);
        if (cached.HasValue) return cached.Value;

        const string sql = """
            SELECT COUNT(1)
            FROM information_schema.tables
            WHERE table_schema = DATABASE()
              AND table_name = @TableName;
            """;

        await using var conn = await _connectionFactory.CreateAsync(cancellationToken);
        await using var cmd = new MySqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@TableName", tableName);

        var count = Convert.ToInt32(await cmd.ExecuteScalarAsync(cancellationToken));
        var exists = count > 0;
        await _cache.SetAsync(cacheKey, (bool?)exists, TimeSpan.FromHours(1));
        return exists;
    }

    public async Task<IReadOnlyList<ForeignKeyMetadata>> GetForeignKeysAsync(
        string tableName,
        CancellationToken cancellationToken = default)
    {
        const string sql = """
            SELECT
                rc.CONSTRAINT_NAME,
                kcu.TABLE_NAME    AS child_table,
                kcu.COLUMN_NAME   AS child_column,
                kcu.REFERENCED_TABLE_NAME  AS parent_table,
                kcu.REFERENCED_COLUMN_NAME AS parent_column,
                rc.DELETE_RULE,
                rc.UPDATE_RULE
            FROM information_schema.REFERENTIAL_CONSTRAINTS rc
            JOIN information_schema.KEY_COLUMN_USAGE kcu
              ON kcu.CONSTRAINT_NAME = rc.CONSTRAINT_NAME
             AND kcu.CONSTRAINT_SCHEMA = rc.CONSTRAINT_SCHEMA
            WHERE rc.CONSTRAINT_SCHEMA = DATABASE()
              AND kcu.TABLE_NAME = @TableName;
            """;

        await using var conn = await _connectionFactory.CreateAsync(cancellationToken);
        await using var cmd = new MySqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@TableName", tableName);

        await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);
        var result = new List<ForeignKeyMetadata>();

        while (await reader.ReadAsync(cancellationToken))
        {
            result.Add(new ForeignKeyMetadata
            {
                ConstraintName = reader.GetString("CONSTRAINT_NAME"),
                ChildEntity = reader.GetString("child_table"),
                ChildColumn = reader.GetString("child_column"),
                ParentEntity = reader.GetString("parent_table"),
                ParentColumn = reader.GetString("parent_column"),
                DeleteRule = ParseCascadeRule(reader.GetString("DELETE_RULE")),
                UpdateRule = ParseCascadeRule(reader.GetString("UPDATE_RULE"))
            });
        }

        return result;
    }

    public async Task<bool> RecordExistsAsync(
        string tableName,
        string columnName,
        object value,
        CancellationToken cancellationToken = default)
    {
        // NOTE: tableName and columnName are already validated by IdentifierValidator
        // before reaching this method via the FK validator.
        var sql = $"SELECT 1 FROM `{tableName}` WHERE `{columnName}` = @val LIMIT 1;";

        await using var conn = await _connectionFactory.CreateAsync(cancellationToken);
        await using var cmd = new MySqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@val", value);

        var result = await cmd.ExecuteScalarAsync(cancellationToken);
        return result is not null && result != DBNull.Value;
    }

    private static CascadeRule ParseCascadeRule(string rule) => rule.ToUpperInvariant() switch
    {
        "CASCADE" => CascadeRule.Cascade,
        "SET NULL" => CascadeRule.SetNull,
        "RESTRICT" => CascadeRule.Restrict,
        "NO ACTION" => CascadeRule.NoAction,
        _ => CascadeRule.NoAction
    };
}
```

```csharp
// DynamicTransactionEngine.MySql/MySqlConnectionFactory.cs

using DynamicTransactionEngine.Infrastructure.Database;
using Microsoft.Extensions.Options;
using MySqlConnector;

namespace DynamicTransactionEngine.MySql;

public sealed class MySqlConnectionFactory : IConnectionFactory
{
    private readonly string _connectionString;

    public MySqlConnectionFactory(IOptions<DatabaseOptions> options)
    {
        _connectionString = options.Value.ConnectionString;
    }

    public async Task<MySqlConnection> CreateAsync(CancellationToken cancellationToken = default)
    {
        var conn = new MySqlConnection(_connectionString);
        await conn.OpenAsync(cancellationToken);
        return conn;
    }
}
```

---

## 7. Security Model

### 7.1 SQL Injection Prevention — Layered Defence

| Layer | Mechanism |
|---|---|
| **Layer 1** | `IdentifierValidator` rejects any table/column name not matching `^[a-zA-Z_][a-zA-Z0-9_]{0,127}$` |
| **Layer 2** | Reserved SQL keyword blocklist rejects `SELECT`, `DROP`, `UNION`, `EXEC`, etc. |
| **Layer 3** | All values are `MySqlParameter` — never string-interpolated |
| **Layer 4** | `EntityMetadata.InsertableFields` / `UpdatableFields` whitelist the exact set of columns that can be touched |
| **Layer 5** | `FieldMapperProvider` throws `EntityNotFoundException` for unknown entities — unknown table names never reach a query builder |

### 7.2 Sensitive Field Masking

Fields marked with `FieldProperty.Sensitive` or `DataClassification.Restricted` have their values replaced with `***REDACTED***` in audit entries before persistence. They are never logged at any log level.

```csharp
// Enforcement happens in AuditBehavior.MaskSensitiveFields()
// and in StructuredLoggerExtensions before any ILogger call
```

### 7.3 Entity & Field Whitelisting Flow

```
IncomingRequest.ExtendedProperties
        │
        ▼
 FieldMapperProvider.GetEntityMetadata()
        │  ← Throws EntityNotFoundException if entity unknown
        ▼
 EntityMetadata.InsertableFields / UpdatableFields
        │  ← Computed properties; only mapper-registered fields pass through
        ▼
 QueryBuilder.BuildInsertQuery()
        │  ← Iterates InsertableFields; ignores any key not in the whitelist
        ▼
 Parameterized MySqlCommand
```

---

## 8. Performance Design

### 8.1 Metadata Caching Strategy

| Cache Key | Default TTL | Eviction Trigger |
|---|---|---|
| `DTE:metadata:{entity}` | 30 min | `IFieldMapperProvider.InvalidateCacheAsync()` |
| `DTE:fk:{table}` | 30 min | Schema change (manual) |
| `DTE:mappers:{entity}` | 30 min | Same as metadata |
| `DTE:tablecheck:{table}` | 1 hour | Schema change (manual) |

All cache reads are `IMemoryCache` — in-process, zero-latency for hot paths. A distributed cache layer (Redis) can be substituted by implementing `IMetadataCacheService` against `IDistributedCache` without changing any other component.

### 8.2 Change-Detection on Update

The `UpdateProcessor` performs a `SELECT` before `UPDATE` and diffs the values. Only changed columns are included in the `SET` clause. This eliminates unnecessary writes and produces a precise audit delta.

### 8.3 Batch Child Processing

Child records in `renProps` are processed sequentially within the parent transaction for correctness. For high-volume scenarios, implement `IBatchInsertStrategy` (extension seam) with multi-row `INSERT` statements:

```sql
INSERT INTO `OrderItems` (`OrderId`, `ProductId`, `Qty`)
VALUES (@p0_OrderId, @p0_ProductId, @p0_Qty),
       (@p1_OrderId, @p1_ProductId, @p1_Qty),
       (@p2_OrderId, @p2_ProductId, @p2_Qty);
```

This reduces N child inserts to a single round-trip.

### 8.4 Connection Pooling

`MySqlConnector` implements connection pooling by default via `Pooling=true` in the connection string. Recommend:

```
Server=...;Database=...;Uid=...;Pwd=...;
Pooling=true;Min Pool Size=5;Max Pool Size=100;
Connection Timeout=15;Command Timeout=30;
AllowUserVariables=true;
```

---

## 9. Dependency Injection Bootstrap

```csharp
// DynamicTransactionEngine.MySql/ServiceCollectionExtensions.cs

using DynamicTransactionEngine.Application.Behaviors;
using DynamicTransactionEngine.Application.Pipelines;
using DynamicTransactionEngine.Application.Processors;
using DynamicTransactionEngine.Application.Services;
using DynamicTransactionEngine.Core.Interfaces;
using DynamicTransactionEngine.Infrastructure.Auditing;
using DynamicTransactionEngine.Infrastructure.Caching;
using DynamicTransactionEngine.Infrastructure.Database;
using DynamicTransactionEngine.Infrastructure.Providers;
using DynamicTransactionEngine.Infrastructure.Repositories;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace DynamicTransactionEngine.MySql;

public static class ServiceCollectionExtensions
{
    /// <summary>
    /// Registers the complete DynamicTransactionEngine with MySQL provider.
    /// Call from Program.cs / Startup.cs.
    /// </summary>
    public static IServiceCollection AddDynamicTransactionEngine(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        // Options
        services.Configure<DatabaseOptions>(
            configuration.GetSection(DatabaseOptions.Section));

        // Memory cache (add IDistributedCache override if needed)
        services.AddMemoryCache();

        // Core infrastructure
        services.AddSingleton<IMetadataCacheService, MetadataCacheService>();
        services.AddSingleton<IConnectionFactory, MySqlConnectionFactory>();
        services.AddSingleton<ISchemaProvider, MySqlSchemaProvider>();
        services.AddSingleton<IQueryBuilder, MySqlQueryBuilder>();

        // Repositories
        services.AddScoped<MapperRepository>();
        services.AddScoped<ITransactionRepository, TransactionRepository>();

        // Providers
        services.AddScoped<IFieldMapperProvider, FieldMapperProvider>();

        // Validators
        services.AddScoped<IEntityValidator, EntityValidator>();
        services.AddScoped<IForeignKeyValidator, ForeignKeyValidator>();

        // Audit
        services.AddScoped<IAuditService, AuditService>();

        // Pipeline steps (order is enforced by IPipelineStep.Order)
        services.AddScoped<IPipelineStep, LoggingBehavior>();
        services.AddScoped<IPipelineStep, RetryBehavior>();
        services.AddScoped<IPipelineStep, ValidationBehavior>();

        // Operation-specific pipeline factories
        services.AddScoped<InsertProcessorFactory>();
        services.AddScoped<UpdateProcessorFactory>();
        services.AddScoped<DeleteProcessorFactory>();

        // Child processor
        services.AddScoped<ChildEntityProcessor>();

        // Orchestrator (primary entry point)
        services.AddScoped<ITransactionProcessor, TransactionOrchestrator>();

        return services;
    }

    /// <summary>
    /// Register a custom business validator. Multiple can be registered; all are executed
    /// in Priority order within ValidationBehavior.
    /// </summary>
    public static IServiceCollection AddTransactionValidator<TValidator>(
        this IServiceCollection services)
        where TValidator : class, ITransactionValidator
    {
        services.AddScoped<ITransactionValidator, TValidator>();
        return services;
    }

    /// <summary>
    /// Register a post-commit trigger service.
    /// </summary>
    public static IServiceCollection AddTriggerService<TTrigger>(
        this IServiceCollection services)
        where TTrigger : class, ITriggerService
    {
        services.AddScoped<ITriggerService, TTrigger>();
        return services;
    }
}
```

---

## 10. Console Test Host

```csharp
// DynamicTransactionEngine.Tests/Program.cs

using DynamicTransactionEngine.Core.Interfaces;
using DynamicTransactionEngine.Core.Models;
using DynamicTransactionEngine.MySql;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

var host = Host.CreateDefaultBuilder(args)
    .ConfigureAppConfiguration(config =>
    {
        config.AddJsonFile("appsettings.json", optional: false);
        config.AddEnvironmentVariables();
    })
    .ConfigureLogging(logging =>
    {
        logging.ClearProviders();
        logging.AddConsole();
        logging.SetMinimumLevel(LogLevel.Debug);
    })
    .ConfigureServices((ctx, services) =>
    {
        services.AddDynamicTransactionEngine(ctx.Configuration);
    })
    .Build();

await host.StartAsync();

var processor = host.Services.GetRequiredService<ITransactionProcessor>();

// ──────────────────────────────────────────────────────────────
// TEST 1: Insert Order with child OrderItems
// ──────────────────────────────────────────────────────────────
Console.WriteLine("\n[TEST 1] INSERT Order with child OrderItems");

var insertRequest = new TransactionRequest
{
    TransactionEntityName = "Order",
    TransactionId = Guid.NewGuid().ToString("N"),
    UserId = "system-test",
    ExtendedProperties = new Dictionary<string, object?>
    {
        ["CustomerId"]  = 1001,
        ["OrderDate"]   = DateTime.UtcNow,
        ["TotalAmount"] = 299.99m,
        ["Status"]      = "Pending"
    },
    RenProps = new Dictionary<string, List<Dictionary<string, object?>>>
    {
        ["OrderItem"] = new()
        {
            new() { ["ProductId"] = 42, ["Qty"] = 2, ["UnitPrice"] = 99.99m },
            new() { ["ProductId"] = 17, ["Qty"] = 1, ["UnitPrice"] = 100.01m }
        }
    }
};

var insertResult = await processor.InsertAsync(insertRequest);
Console.WriteLine($"  Success: {insertResult.Success}");
Console.WriteLine($"  Message: {insertResult.Message}");
Console.WriteLine($"  InsertedId: {insertResult.Data.GetValueOrDefault("insertedId")}");
Console.WriteLine($"  ElapsedMs: {insertResult.ElapsedMilliseconds}");

if (!insertResult.Success)
{
    foreach (var err in insertResult.ValidationErrors)
        Console.WriteLine($"  ERROR [{err.Code}] {err.Field}: {err.Message}");
}

// ──────────────────────────────────────────────────────────────
// TEST 2: Update Order status
// ──────────────────────────────────────────────────────────────
Console.WriteLine("\n[TEST 2] UPDATE Order status");

var updateRequest = new TransactionRequest
{
    TransactionEntityName = "Order",
    TransactionId = Guid.NewGuid().ToString("N"),
    UserId = "system-test",
    ExtendedProperties = new Dictionary<string, object?>
    {
        ["OrderId"] = insertResult.Data.GetValueOrDefault("insertedId"),
        ["Status"]  = "Confirmed"
    }
};

var updateResult = await processor.UpdateAsync(updateRequest);
Console.WriteLine($"  Success: {updateResult.Success}");
Console.WriteLine($"  Message: {updateResult.Message}");

// ──────────────────────────────────────────────────────────────
// TEST 3: Delete with FK dependency check
// ──────────────────────────────────────────────────────────────
Console.WriteLine("\n[TEST 3] DELETE Order (should fail if OrderItems exist and rule=Restrict)");

var deleteRequest = new TransactionRequest
{
    TransactionEntityName = "Order",
    TransactionId = Guid.NewGuid().ToString("N"),
    UserId = "system-test",
    ExtendedProperties = new Dictionary<string, object?>
    {
        ["OrderId"] = insertResult.Data.GetValueOrDefault("insertedId")
    }
};

var deleteResult = await processor.DeleteAsync(deleteRequest);
Console.WriteLine($"  Success: {deleteResult.Success}");
Console.WriteLine($"  Message: {deleteResult.Message}");

if (!deleteResult.Success)
    foreach (var err in deleteResult.ValidationErrors)
        Console.WriteLine($"  ERROR [{err.Code}] {err.Field}: {err.Message}");

Console.WriteLine("\nAll tests completed.");
await host.StopAsync();
```

```json
// DynamicTransactionEngine.Tests/appsettings.json
{
  "DynamicTransactionEngine": {
    "Database": {
      "ConnectionString": "Server=localhost;Database=dte_dev;Uid=dte_user;Pwd=dte_pass;Pooling=true;Min Pool Size=5;Max Pool Size=50;",
      "CommandTimeoutSeconds": 30,
      "MaxRetryCount": 3
    }
  },
  "Logging": {
    "LogLevel": {
      "Default": "Debug",
      "DynamicTransactionEngine": "Debug",
      "Microsoft": "Warning"
    }
  }
}
```

---

## 11. Unit Test Architecture

### 11.1 Test Project Setup

```xml
<!-- DynamicTransactionEngine.Tests/DynamicTransactionEngine.Tests.csproj -->
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <TargetFramework>net8.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
  </PropertyGroup>
  <ItemGroup>
    <PackageReference Include="xunit" Version="2.9.*" />
    <PackageReference Include="xunit.runner.console" Version="2.9.*" />
    <PackageReference Include="Moq" Version="4.20.*" />
    <PackageReference Include="FluentAssertions" Version="6.12.*" />
    <PackageReference Include="Microsoft.Extensions.Hosting" Version="8.0.*" />
    <PackageReference Include="MySqlConnector" Version="2.3.*" />
  </ItemGroup>
</Project>
```

### 11.2 Query Builder Tests

```csharp
// DynamicTransactionEngine.Tests/Unit/QueryBuilders/MySqlQueryBuilderTests.cs

using DynamicTransactionEngine.Core.Enums;
using DynamicTransactionEngine.Core.Models;
using DynamicTransactionEngine.MySql;
using FluentAssertions;
using Xunit;

namespace DynamicTransactionEngine.Tests.Unit.QueryBuilders;

public sealed class MySqlQueryBuilderTests
{
    private readonly MySqlQueryBuilder _sut = new();

    private static EntityMetadata BuildMetadata(string entity = "Order") =>
        new()
        {
            EntityName = entity,
            TableName = entity,
            Fields = new List<FieldMapper>
            {
                new() { EntityName = entity, FieldName = "OrderId", ColumnName = "OrderId",
                        DataType = "int", Properties = FieldProperty.PrimaryKey | FieldProperty.Identity },
                new() { EntityName = entity, FieldName = "CustomerId", ColumnName = "CustomerId",
                        DataType = "int", Properties = FieldProperty.Required | FieldProperty.ForeignKey,
                        ForeignKeyEntity = "Customer", ForeignKeyColumn = "CustomerId" },
                new() { EntityName = entity, FieldName = "Status", ColumnName = "Status",
                        DataType = "varchar", Properties = FieldProperty.AllowUpdate }
            },
            ForeignKeys = Array.Empty<ForeignKeyMetadata>()
        };

    [Fact]
    public void BuildInsertQuery_ExcludesIdentityColumn()
    {
        var metadata = BuildMetadata();
        var values = new Dictionary<string, object?>
        {
            ["CustomerId"] = 1001,
            ["Status"] = "Pending"
        };

        var result = _sut.BuildInsertQuery(metadata, values);

        result.Sql.Should().NotContain("`OrderId`");
        result.Sql.Should().Contain("`CustomerId`");
        result.Sql.Should().Contain("`Status`");
        result.Sql.Should().Contain("LAST_INSERT_ID()");
        result.Parameters.Should().ContainKey("@p_CustomerId");
        result.Parameters.Should().ContainKey("@p_Status");
    }

    [Fact]
    public void BuildUpdateQuery_OnlyUpdatableFields()
    {
        var metadata = BuildMetadata();
        var values = new Dictionary<string, object?> { ["Status"] = "Confirmed" };

        var result = _sut.BuildUpdateQuery(metadata, values, primaryKeyValue: 42);

        result.Sql.Should().StartWith("UPDATE `Order`");
        result.Sql.Should().Contain("`Status` = @p_Status");
        result.Sql.Should().Contain("WHERE `OrderId` = @pk");
        result.Sql.Should().NotContain("`CustomerId`");
        result.Parameters["@p_Status"].Should().Be("Confirmed");
        result.Parameters["@pk"].Should().Be(42);
    }

    [Fact]
    public void BuildDeleteQuery_HardDelete_WhenNoSoftDeleteField()
    {
        var metadata = BuildMetadata();
        var result = _sut.BuildDeleteQuery(metadata, primaryKeyValue: 99, softDelete: false);

        result.Sql.Should().Be("DELETE FROM `Order` WHERE `OrderId` = @pk;");
        result.Parameters["@pk"].Should().Be(99);
    }

    [Fact]
    public void EscapeIdentifier_ThrowsOnSqlKeyword()
    {
        var act = () => _sut.EscapeIdentifier("SELECT");
        act.Should().Throw<Core.Exceptions.SqlInjectionAttemptException>();
    }

    [Fact]
    public void EscapeIdentifier_ThrowsOnSpecialCharacters()
    {
        var act = () => _sut.EscapeIdentifier("table; DROP TABLE orders--");
        act.Should().Throw<Core.Exceptions.SqlInjectionAttemptException>();
    }

    [Fact]
    public void EscapeIdentifier_AcceptsValidIdentifier()
    {
        var result = _sut.EscapeIdentifier("OrderItems");
        result.Should().Be("`OrderItems`");
    }
}
```

### 11.3 Validation Behavior Tests

```csharp
// DynamicTransactionEngine.Tests/Unit/Pipeline/ValidationBehaviorTests.cs

using DynamicTransactionEngine.Application.Behaviors;
using DynamicTransactionEngine.Core.Enums;
using DynamicTransactionEngine.Core.Interfaces;
using DynamicTransactionEngine.Core.Models;
using FluentAssertions;
using Moq;
using Microsoft.Extensions.Logging.Abstractions;
using Xunit;

namespace DynamicTransactionEngine.Tests.Unit.Pipeline;

public sealed class ValidationBehaviorTests
{
    private readonly Mock<IEntityValidator> _entityValidator = new();
    private readonly Mock<IForeignKeyValidator> _fkValidator = new();

    private ValidationBehavior BuildSut(IEnumerable<ITransactionValidator>? customValidators = null)
    {
        return new ValidationBehavior(
            _entityValidator.Object,
            _fkValidator.Object,
            customValidators ?? Enumerable.Empty<ITransactionValidator>(),
            NullLogger<ValidationBehavior>.Instance);
    }

    private static TransactionContext BuildContext() => new()
    {
        CorrelationId = "test-correlation",
        UserId = "test-user",
        Operation = TransactionOperation.Insert,
        Request = new TransactionRequest { TransactionEntityName = "Order" }
    };

    [Fact]
    public async Task ExecuteAsync_WhenNoErrors_CallsNext()
    {
        _entityValidator
            .Setup(v => v.ValidateAsync(It.IsAny<TransactionContext>(),
                It.IsAny<TransactionOperation>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<ValidationError>());

        _fkValidator
            .Setup(v => v.ValidateReferencesAsync(
                It.IsAny<TransactionContext>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<ValidationError>());

        var sut = BuildSut();
        var nextCalled = false;

        await sut.ExecuteAsync(BuildContext(), () =>
        {
            nextCalled = true;
            return Task.CompletedTask;
        });

        nextCalled.Should().BeTrue();
    }

    [Fact]
    public async Task ExecuteAsync_WhenEntityValidationFails_DoesNotCallNext()
    {
        _entityValidator
            .Setup(v => v.ValidateAsync(It.IsAny<TransactionContext>(),
                It.IsAny<TransactionOperation>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<ValidationError>
            {
                new() { Field = "EntityName", Code = "ENTITY_NOT_FOUND",
                        Message = "Entity 'Order' not found." }
            });

        var sut = BuildSut();
        var context = BuildContext();
        var nextCalled = false;

        await sut.ExecuteAsync(context, () =>
        {
            nextCalled = true;
            return Task.CompletedTask;
        });

        nextCalled.Should().BeFalse();
        context.ValidationErrors.Should().HaveCount(1);
        context.ValidationErrors[0].Code.Should().Be("ENTITY_NOT_FOUND");
    }
}
```

### 11.4 Insert Processor Tests

```csharp
// DynamicTransactionEngine.Tests/Unit/Processors/InsertProcessorTests.cs

using DynamicTransactionEngine.Application.Processors;
using DynamicTransactionEngine.Core.Contracts;
using DynamicTransactionEngine.Core.Enums;
using DynamicTransactionEngine.Core.Interfaces;
using DynamicTransactionEngine.Core.Models;
using DynamicTransactionEngine.Infrastructure.Repositories;
using FluentAssertions;
using Moq;
using Microsoft.Extensions.Logging.Abstractions;
using System.Data;
using Xunit;

namespace DynamicTransactionEngine.Tests.Unit.Processors;

public sealed class InsertProcessorTests
{
    private readonly Mock<IQueryBuilder> _queryBuilder = new();
    private readonly Mock<ITransactionRepository> _repository = new();
    private readonly Mock<IDbTransaction> _transaction = new();

    private InsertProcessor BuildSut() => new(
        _queryBuilder.Object,
        _repository.Object,
        NullLogger<InsertProcessor>.Instance);

    private static EntityMetadata BuildMetadata() => new()
    {
        EntityName = "Order",
        TableName = "Order",
        Fields = new List<FieldMapper>
        {
            new() { EntityName = "Order", FieldName = "OrderId", ColumnName = "OrderId",
                    DataType = "int",
                    Properties = FieldProperty.PrimaryKey | FieldProperty.Identity },
            new() { EntityName = "Order", FieldName = "CustomerId", ColumnName = "CustomerId",
                    DataType = "int",
                    Properties = FieldProperty.Required }
        },
        ForeignKeys = Array.Empty<ForeignKeyMetadata>()
    };

    [Fact]
    public async Task ExecuteAsync_SetsInsertedId_FromRepository()
    {
        var metadata = BuildMetadata();
        var expectedId = 42L;

        _queryBuilder
            .Setup(q => q.BuildInsertQuery(It.IsAny<EntityMetadata>(),
                It.IsAny<IReadOnlyDictionary<string, object?>>()))
            .Returns(QueryDefinition.Create("INSERT ...", new Dictionary<string, object?>()));

        _repository
            .Setup(r => r.ExecuteInsertAsync(
                It.IsAny<QueryDefinition>(),
                It.IsAny<IDbTransaction>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(expectedId);

        var context = new TransactionContext
        {
            CorrelationId = "test",
            UserId = "test",
            Operation = TransactionOperation.Insert,
            Request = new TransactionRequest { TransactionEntityName = "Order" },
            EntityMetadata = metadata,
            DbTransaction = _transaction.Object,
            ResolvedValues = new() { ["CustomerId"] = 1001 }
        };

        var sut = BuildSut();
        await sut.ExecuteAsync(context, () => Task.CompletedTask);

        context.InsertedId.Should().Be(expectedId);
    }
}
```

---

## 12. Configuration Reference

### 12.1 appsettings Schema

```json
{
  "DynamicTransactionEngine": {
    "Database": {
      "ConnectionString": "Server=...;Database=...;Uid=...;Pwd=...;Pooling=true;",
      "CommandTimeoutSeconds": 30,
      "MaxRetryCount": 3
    },
    "Cache": {
      "MetadataExpiryMinutes": 30,
      "SchemaExpiryMinutes": 60,
      "SlidingExpiryMinutes": 5
    },
    "Audit": {
      "Enabled": true,
      "TableName": "AuditLog",
      "MaskSensitiveFields": true
    },
    "Security": {
      "EnforceEntityWhitelist": true,
      "MaxIdentifierLength": 128
    }
  }
}
```

### 12.2 Required Database Schema

```sql
-- FieldMapper: drives all engine behaviour
CREATE TABLE FieldMapper (
    Id              INT             NOT NULL AUTO_INCREMENT,
    EntityName      VARCHAR(128)    NOT NULL,
    FieldName       VARCHAR(128)    NOT NULL,
    ColumnName      VARCHAR(128)    NOT NULL,
    DataType        VARCHAR(64)     NOT NULL,
    Properties      INT             NOT NULL DEFAULT 0,  -- Bitmask of FieldProperty enum
    DefaultValue    VARCHAR(512)    NULL,
    ForeignKeyEntity VARCHAR(128)   NULL,
    ForeignKeyColumn VARCHAR(128)   NULL,
    CascadeRule     TINYINT         NOT NULL DEFAULT 0,
    MaxLength       INT             NULL,
    ValidationRegex VARCHAR(512)    NULL,
    Classification  TINYINT         NOT NULL DEFAULT 0,
    SortOrder       INT             NOT NULL DEFAULT 0,
    IsActive        TINYINT(1)      NOT NULL DEFAULT 1,
    PRIMARY KEY (Id),
    INDEX idx_entity (EntityName),
    UNIQUE KEY uq_entity_field (EntityName, FieldName)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- AuditLog: written by AuditService on a separate connection
CREATE TABLE AuditLog (
    Id              BIGINT          NOT NULL AUTO_INCREMENT,
    CorrelationId   VARCHAR(64)     NOT NULL,
    UserId          VARCHAR(256)    NOT NULL,
    EntityName      VARCHAR(128)    NOT NULL,
    TableName       VARCHAR(128)    NOT NULL,
    Operation       VARCHAR(16)     NOT NULL,
    PrimaryKeyValue VARCHAR(256)    NULL,
    PreviousValues  LONGTEXT        NULL,   -- JSON
    NewValues       LONGTEXT        NULL,   -- JSON
    OccurredAt      DATETIME(6)     NOT NULL,
    MachineName     VARCHAR(256)    NULL,
    PRIMARY KEY (Id),
    INDEX idx_entity_ts (EntityName, OccurredAt),
    INDEX idx_correlation (CorrelationId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

---

## 13. Extension Points

### 13.1 Custom Business Validator

```csharp
// Example: Prevent orders above $10,000 without manager approval flag
public sealed class HighValueOrderValidator : ITransactionValidator
{
    public int Priority => 200;

    public Task<List<ValidationError>> ValidateAsync(
        TransactionContext context,
        TransactionOperation operation,
        CancellationToken cancellationToken = default)
    {
        var errors = new List<ValidationError>();

        if (operation != TransactionOperation.Insert
            && operation != TransactionOperation.Update)
            return Task.FromResult(errors);

        if (!context.ResolvedValues.TryGetValue("TotalAmount", out var raw)
            || raw is not decimal total)
            return Task.FromResult(errors);

        if (total > 10_000m)
        {
            var approved = context.ResolvedValues.TryGetValue("ManagerApproved", out var a)
                           && a is true;
            if (!approved)
                errors.Add(new ValidationError
                {
                    Field = "TotalAmount",
                    Code = "APPROVAL_REQUIRED",
                    Message = "Orders exceeding $10,000 require ManagerApproved=true.",
                    AttemptedValue = total
                });
        }

        return Task.FromResult(errors);
    }
}

// Registration:
services.AddTransactionValidator<HighValueOrderValidator>();
```

### 13.2 Post-Commit Trigger

```csharp
// Example: Publish domain event to message bus after successful insert
public sealed class OrderCreatedTrigger : ITriggerService
{
    public int Priority => 100;

    private readonly IMessageBus _bus;
    private readonly ILogger<OrderCreatedTrigger> _logger;

    public OrderCreatedTrigger(IMessageBus bus, ILogger<OrderCreatedTrigger> logger)
    {
        _bus = bus;
        _logger = logger;
    }

    public async Task ExecuteAsync(
        TransactionContext context,
        CancellationToken cancellationToken = default)
    {
        if (context.Operation != TransactionOperation.Insert
            || context.Request.TransactionEntityName != "Order")
            return;

        await _bus.PublishAsync(new OrderCreatedEvent
        {
            OrderId = context.InsertedId,
            CorrelationId = context.CorrelationId,
            UserId = context.UserId,
            OccurredAt = DateTimeOffset.UtcNow
        }, cancellationToken);

        _logger.LogInformation("OrderCreatedEvent published for [{CorrelationId}]",
            context.CorrelationId);
    }
}

// Registration:
services.AddTriggerService<OrderCreatedTrigger>();
```

### 13.3 Oracle DB Provider (Future)

To add Oracle support, create `DynamicTransactionEngine.Oracle/` project:

```
DynamicTransactionEngine.Oracle/
├── OracleQueryBuilder.cs          ← Implements IQueryBuilder with Oracle syntax
├── OracleSchemaProvider.cs        ← Queries ALL_CONSTRAINTS, ALL_CONS_COLUMNS
└── OracleConnectionFactory.cs     ← Uses Oracle.ManagedDataAccess.Client
```

Key Oracle differences handled in `OracleQueryBuilder`:
- `INSERT INTO ... RETURNING id INTO :out_id` instead of `LAST_INSERT_ID()`
- `"TableName"` double-quote escaping instead of MySQL backticks
- `:param` prefix instead of `@param`
- `FETCH FIRST 1 ROW ONLY` instead of `LIMIT 1`

Switch provider by replacing the DI registration — no Application or Core layer changes required.

---

## 14. Operational Concerns

### 14.1 Health Check Integration

```csharp
// Implement IHealthCheck to verify DB connectivity and FieldMapper table accessibility
services.AddHealthChecks()
    .AddCheck<DynamicTransactionEngineHealthCheck>("dte-db");
```

### 14.2 Observability — Structured Log Events

| Event | Level | Key Fields |
|---|---|---|
| Transaction started | `Information` | `Operation`, `Entity`, `CorrelationId`, `UserId` |
| Transaction completed | `Information` | `ElapsedMs`, `Success` |
| Validation failure | `Warning` | `ErrorCount`, `Errors[*].Code` |
| FK violation | `Warning` | `ParentEntity`, `ParentColumn`, `AttemptedValue` |
| Deadlock retry | `Warning` | `Attempt`, `DelayMs` |
| Transaction fault | `Error` | `ExceptionType`, `Message` |
| Rollback failure | `Critical` | `ExceptionType` |
| Audit gap | `Error` | `CorrelationId` |
| SQL injection attempt | `Critical` | `RejectedIdentifier` |
| Cache eviction | `Debug` | `CacheKey` |

### 14.3 Metrics (OpenTelemetry)

```csharp
// Decorate TransactionOrchestrator with a metrics-emitting proxy or use Activity API
using var activity = ActivitySource.StartActivity("DTE.Transaction");
activity?.SetTag("dte.entity", request.TransactionEntityName);
activity?.SetTag("dte.operation", operation.ToString());
```

Counters to instrument:

- `dte.transactions.total` (labels: entity, operation, success)
- `dte.transactions.duration_ms` (histogram)
- `dte.cache.hits` / `dte.cache.misses`
- `dte.fk.violations`
- `dte.retries`

### 14.4 Runbook — Common Failure Modes

| Symptom | Likely Cause | Remediation |
|---|---|---|
| `EntityNotFoundException` | FieldMapper row missing or `IsActive=0` | Insert mapper row; call `InvalidateCacheAsync()` |
| `SqlInjectionAttemptException` | Invalid identifier in request | Audit calling code; check `EntityName` source |
| `ForeignKeyViolationException` | Parent record does not exist | Verify parent entity data before child insert |
| Deadlock retries exhausted | High concurrency on same rows | Review index strategy; consider queue-based serialization |
| Audit gap logged | AuditLog DB unavailable | Check AuditLog DB connection; restore connectivity |
| Stale metadata served | Long-running cache entries | Call `InvalidateCacheAsync(entityName)` after schema changes |

---

*End of Document — DynamicTransactionEngine v1.0.0*
*Classification: Internal Engineering · Principal Architect Review Required Before Production Deployment*