using DynamicTransactionEngine.Core.Interfaces;
using DynamicTransactionEngine.Core.Models;

namespace DynamicTransactionEngine.MySql;

public sealed class MySqlFieldMapperProvider : IFieldMapperProvider
{
    public Task<EntityMetadata> GetEntityMetadataAsync(string entityName, CancellationToken cancellationToken = default)
    {
        // Placeholder metadata contract. Replace with mapper-table fetch from MySQL.
        var metadata = new EntityMetadata
        {
            EntityName = entityName,
            TableName = entityName,
            Fields =
            [
                new FieldMapper { ColumnName = "Id" },
                new FieldMapper { ColumnName = "Name" },
                new FieldMapper { ColumnName = "UpdatedAtUtc" }
            ]
        };

        return Task.FromResult(metadata);
    }
}

public sealed class MySqlSchemaProvider : ISchemaProvider
{
    public Task<bool> EntityExistsAsync(string entityName, CancellationToken cancellationToken = default) =>
        Task.FromResult(!string.IsNullOrWhiteSpace(entityName));
}
