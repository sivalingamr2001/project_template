using DynamicTransactionEngine.Core.Interfaces;
using Microsoft.Extensions.DependencyInjection;

namespace DynamicTransactionEngine.MySql;

public static class MySqlServiceCollectionExtensions
{
    public static IServiceCollection AddDynamicTransactionEngineMySql(this IServiceCollection services)
    {
        services.AddScoped<IQueryBuilder, MySqlQueryBuilder>();
        services.AddScoped<IFieldMapperProvider, MySqlFieldMapperProvider>();
        services.AddScoped<ISchemaProvider, MySqlSchemaProvider>();
        return services;
    }
}
