using DynamicTransactionEngine.Infrastructure.QueryBuilders;

namespace DynamicTransactionEngine.MySql;

public sealed class MySqlQueryBuilder : BaseQueryBuilder
{
    protected override string QuoteIdentifier(string identifier) => $"`{identifier}`";
}
