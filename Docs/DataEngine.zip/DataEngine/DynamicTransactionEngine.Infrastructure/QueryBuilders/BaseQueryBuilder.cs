using DynamicTransactionEngine.Core.Contracts;
using DynamicTransactionEngine.Core.Enums;
using DynamicTransactionEngine.Core.Interfaces;
using DynamicTransactionEngine.Core.Models;
using DynamicTransactionEngine.Core.Validators;

namespace DynamicTransactionEngine.Infrastructure.QueryBuilders;

public abstract class BaseQueryBuilder : IQueryBuilder
{
    protected abstract string QuoteIdentifier(string identifier);

    public QueryDefinition Build(TransactionContext context, EntityMetadata metadata)
    {
        var table = QuoteIdentifier(IdentifierValidator.EnsureValid(metadata.TableName));
        return context.Request.Operation switch
        {
            TransactionOperation.Insert => BuildInsert(context, metadata, table),
            TransactionOperation.Update => BuildUpdate(context, metadata, table),
            TransactionOperation.Delete => BuildDelete(context, metadata, table),
            _ => throw new InvalidOperationException("Unsupported transaction operation.")
        };
    }

    private QueryDefinition BuildInsert(TransactionContext context, EntityMetadata metadata, string table)
    {
        var validValues = context.Request.Values
            .Where(kv => metadata.Fields.Any(f => f.ColumnName == kv.Key))
            .ToList();

        var columns = validValues.Select(kv => QuoteIdentifier(IdentifierValidator.EnsureValid(kv.Key))).ToArray();
        var parameters = validValues.Select((kv, idx) => new { kv.Value, Name = $"@p{idx}" }).ToList();
        var sql = $"INSERT INTO {table} ({string.Join(", ", columns)}) VALUES ({string.Join(", ", parameters.Select(p => p.Name))})";
        return new QueryDefinition(sql, parameters.ToDictionary(x => x.Name, x => x.Value));
    }

    private QueryDefinition BuildUpdate(TransactionContext context, EntityMetadata metadata, string table)
    {
        var validValues = context.Request.Values
            .Where(kv => metadata.Fields.Any(f => f.ColumnName == kv.Key))
            .ToList();
        var setClauses = validValues.Select((kv, idx) => $"{QuoteIdentifier(IdentifierValidator.EnsureValid(kv.Key))} = @p{idx}").ToArray();
        var sql = $"UPDATE {table} SET {string.Join(", ", setClauses)}";
        return new QueryDefinition(sql, validValues.Select((kv, idx) => new { idx, kv.Value }).ToDictionary(x => $"@p{x.idx}", x => x.Value));
    }

    private QueryDefinition BuildDelete(TransactionContext context, EntityMetadata metadata, string table)
    {
        _ = metadata;
        return new QueryDefinition($"DELETE FROM {table}", new Dictionary<string, object?>());
    }
}
