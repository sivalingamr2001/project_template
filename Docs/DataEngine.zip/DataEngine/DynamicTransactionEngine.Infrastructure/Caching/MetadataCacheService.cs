using DynamicTransactionEngine.Core.Interfaces;
using DynamicTransactionEngine.Core.Models;
using Microsoft.Extensions.Caching.Memory;

namespace DynamicTransactionEngine.Infrastructure.Caching;

public sealed class MetadataCacheService(IMemoryCache cache) : IMetadataCacheService
{
    public async Task<EntityMetadata> GetOrCreateEntityMetadataAsync(
        string entityName,
        Func<CancellationToken, Task<EntityMetadata>> factory,
        CancellationToken cancellationToken = default)
    {
        return await cache.GetOrCreateAsync(
                   $"dte:metadata:{entityName}",
                   async entry =>
                   {
                       entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(15);
                       return await factory(cancellationToken);
                   })
               ?? throw new InvalidOperationException($"Metadata factory returned null for {entityName}.");
    }
}
