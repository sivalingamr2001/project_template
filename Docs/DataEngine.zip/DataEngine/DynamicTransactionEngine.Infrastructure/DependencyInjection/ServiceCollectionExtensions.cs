using DynamicTransactionEngine.Application.Behaviors;
using DynamicTransactionEngine.Application.Pipelines;
using DynamicTransactionEngine.Application.Processors;
using DynamicTransactionEngine.Application.Services;
using DynamicTransactionEngine.Core.Interfaces;
using DynamicTransactionEngine.Core.Models;
using DynamicTransactionEngine.Infrastructure.Auditing;
using DynamicTransactionEngine.Infrastructure.Caching;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.DependencyInjection;

namespace DynamicTransactionEngine.Infrastructure.DependencyInjection;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddDynamicTransactionEngine(this IServiceCollection services)
    {
        services.AddMemoryCache();
        services.AddSingleton<IMetadataCacheService, MetadataCacheService>();
        services.AddSingleton<IAuditService, AuditService>();
        services.AddSingleton<ITransactionValidator, NullTransactionValidator>();
        services.AddSingleton<ITriggerService, NullTriggerService>();

        services.AddScoped<InsertProcessor>();
        services.AddScoped<UpdateProcessor>();
        services.AddScoped<DeleteProcessor>();
        services.AddScoped<TransactionProcessorResolver>();

        services.AddScoped<IPipelineStep, ValidationBehavior>();
        services.AddScoped<TransactionPipeline>();
        services.AddScoped<TransactionOrchestrator>();
        return services;
    }

    private sealed class NullTransactionValidator : ITransactionValidator
    {
        public Task ValidateAsync(TransactionContext context, CancellationToken cancellationToken = default)
        {
            if (string.IsNullOrWhiteSpace(context.Request.EntityName))
            {
                throw new ArgumentException("Entity name is required.");
            }

            return Task.CompletedTask;
        }
    }

    private sealed class NullTriggerService : ITriggerService
    {
        public Task OnBeforeExecuteAsync(TransactionContext context, CancellationToken cancellationToken = default) => Task.CompletedTask;

        public Task OnAfterExecuteAsync(TransactionContext context, TransactionResult result, CancellationToken cancellationToken = default) => Task.CompletedTask;
    }
}
