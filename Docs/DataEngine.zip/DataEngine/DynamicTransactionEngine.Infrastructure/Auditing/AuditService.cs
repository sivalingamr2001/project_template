using DynamicTransactionEngine.Core.Contracts;
using DynamicTransactionEngine.Core.Interfaces;
using Microsoft.Extensions.Logging;

namespace DynamicTransactionEngine.Infrastructure.Auditing;

public sealed class AuditService(ILogger<AuditService> logger) : IAuditService
{
    public Task WriteAsync(AuditEntry entry, CancellationToken cancellationToken = default)
    {
        logger.LogInformation(
            "Audit {Operation} {Entity} ({CorrelationId})",
            entry.Operation,
            entry.EntityName,
            entry.CorrelationId);
        return Task.CompletedTask;
    }
}
