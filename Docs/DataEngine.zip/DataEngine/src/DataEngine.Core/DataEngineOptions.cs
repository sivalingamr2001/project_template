// DataEngine.Core/DataEngineOptions.cs
namespace DataEngine.Core;

public sealed class DataEngineOptions
{
    // ── Connection ─────────────────────────────────────────────────────

    public string DefaultConnectionStringName { get; set; } = "DefaultConnection";
    public Dictionary<string, string> AdditionalDatabases { get; set; } = new();

    // ── Schema cache ───────────────────────────────────────────────────

    public TimeSpan? SchemaCacheTtl { get; set; } = TimeSpan.FromMinutes(30);
    public bool PreloadSchemaOnStartup { get; set; } = true;

    // ── Security ───────────────────────────────────────────────────────

    public bool AllowRawSql { get; set; } = false;
    public bool AllowStoredProcedures { get; set; } = true;

    // ── Optional features ─────────────────────────────────────────────────

    public bool EnableAudit { get; set; } = false;
    public bool EnableFieldMapping { get; set; } = false;
    public bool EnableSavedQueryDefinitions { get; set; } = false;

    // ── Performance ────────────────────────────────────────────────────

    public int DefaultCommandTimeoutSeconds { get; set; } = 30;
    public int DefaultPageSize { get; set; } = 20;
    public int MaxPageSize { get; set; } = 1000;
    public int BulkInsertBatchSize { get; set; } = 500;
}
