// DataEngine.Core/Exceptions/SchemaValidationException.cs
namespace DataEngine.Core.Exceptions;

/// <summary>
/// Thrown when a column or table reference fails schema validation.
/// e.g., column doesn't exist, column is not writable.
/// </summary>
public sealed class SchemaValidationException : DataEngineException
{
    public string? ColumnName { get; }
    public string? TableName { get; }

    public SchemaValidationException(string message)
        : base(message) { }

    public SchemaValidationException(string columnName, string tableName)
        : base($"Column '{columnName}' does not exist in table '{tableName}'.")
    {
        ColumnName = columnName;
        TableName = tableName;
    }
}