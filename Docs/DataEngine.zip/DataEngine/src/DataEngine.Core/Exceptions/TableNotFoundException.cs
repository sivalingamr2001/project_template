// DataEngine.Core/Exceptions/TableNotFoundException.cs
namespace DataEngine.Core.Exceptions;

/// <summary>
/// Thrown when a table name is not found in the schema cache.
/// Indicates either a typo in the request or a schema that hasn't been loaded.
/// </summary>
public sealed class TableNotFoundException : DataEngineException
{
    public string TableName { get; }
    public string DatabaseName { get; }

    public TableNotFoundException(string tableName, string databaseName)
        : base($"Table '{tableName}' was not found in database '{databaseName}'. " +
               $"Verify the table exists and the schema cache is current.")
    {
        TableName = tableName;
        DatabaseName = databaseName;
    }
}