// DataEngine.Core/Exceptions/SecurityViolationException.cs
namespace DataEngine.Core.Exceptions;

/// <summary>
/// Thrown when a request violates DataEngine's safety rules.
/// e.g., access to system databases, invalid identifier characters.
/// This is a hard stop — never catch and continue.
/// </summary>
public sealed class SecurityViolationException : DataEngineException
{
    public SecurityViolationException(string message)
        : base(message) { }
}