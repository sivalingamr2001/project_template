// DataEngine.Core/Exceptions/ConnectionException.cs
namespace DataEngine.Core.Exceptions;

/// <summary>
/// Thrown when a database connection cannot be established or
/// a named database alias is not registered.
/// </summary>
public sealed class ConnectionException : DataEngineException
{
    public ConnectionException(string message)
        : base(message) { }

    public ConnectionException(string message, Exception inner)
        : base(message, inner) { }
}