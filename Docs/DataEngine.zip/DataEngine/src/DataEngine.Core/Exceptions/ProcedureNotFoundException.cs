// DataEngine.Core/Exceptions/ProcedureNotFoundException.cs
namespace DataEngine.Core.Exceptions;

/// <summary>
/// Thrown when a stored procedure cannot be found or accessed.
/// </summary>
public sealed class ProcedureNotFoundException : DataEngineException
{
    public string ProcedureName { get; }

    public ProcedureNotFoundException(string procedureName, string databaseName)
        : base($"Stored procedure '{procedureName}' was not found in database '{databaseName}'.")
    {
        ProcedureName = procedureName;
    }
}