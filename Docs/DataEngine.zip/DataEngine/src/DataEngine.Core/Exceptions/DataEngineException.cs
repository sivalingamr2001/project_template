// DataEngine.Core/Exceptions/DataEngineException.cs
namespace DataEngine.Core.Exceptions;

/// <summary>
/// Base exception for all DataEngine operational errors.
/// Consumers can catch this to handle any DataEngine failure uniformly.
/// </summary>
public class DataEngineException : Exception
{
    public DataEngineException(string message)
        : base(message) { }

    public DataEngineException(string message, Exception inner)
        : base(message, inner) { }
}