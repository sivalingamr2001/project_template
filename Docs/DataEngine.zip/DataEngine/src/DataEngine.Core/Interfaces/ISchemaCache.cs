namespace DataEngine.Core.Interfaces;

public interface ISchemaCache
{
    SchemaMetadataSnapshot? Get(string databaseName);
    void Set(string databaseName, SchemaMetadataSnapshot snapshot);
    void Invalidate(string databaseName);
    void InvalidateAll();
    IEnumerable<string> GetCachedDatabases();
}