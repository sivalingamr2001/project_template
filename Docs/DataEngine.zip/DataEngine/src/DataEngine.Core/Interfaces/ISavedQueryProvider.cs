namespace DataEngine.Core.Interfaces;

public interface ISavedQueryProvider
{
    bool IsAvailable { get; }

    ValueTask<QueryRequest?> ResolveAsync(
        string definitionKey,
        CancellationToken ct = default);
}