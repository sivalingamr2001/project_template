namespace DataEngine.Core.Interfaces;

public interface ITransactionExecutor
{
    Task<TransactionResult> ExecuteAsync(
        IReadOnlyList<CompiledQuery> queries,
        string connectionString,
        CancellationToken ct = default);
}