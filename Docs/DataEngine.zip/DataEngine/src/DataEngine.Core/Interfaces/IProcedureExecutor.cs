namespace DataEngine.Core.Interfaces;

public interface IProcedureExecutor
{
    Task<ProcedureResult> ExecuteReadAsync(
        ProcedureRequest request,
        string connectionString,
        CancellationToken ct = default);
    
    Task<ProcedureResult> ExecuteWriteAsync(
        ProcedureRequest request,
        string connectionString,
        CancellationToken ct = default);
}