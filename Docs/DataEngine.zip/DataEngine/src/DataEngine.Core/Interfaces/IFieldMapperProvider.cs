namespace DataEngine.Core.Interfaces;

public interface IFieldMapperProvider
{
    /// <summary>
    /// Map an incoming field alias to the real column name.
    /// Returns null if no mapping exists (use original key).
    /// </summary>
    ValueTask<string?> ResolveColumnAsync(
        string tableName,
        string alias,
        CancellationToken ct = default);
    
    /// <summary>
    /// Map outgoing column name to alias for response.
    /// Returns null if no mapping (use original column name).
    /// </summary>
    ValueTask<string?> ResolveAliasAsync(
        string tableName,
        string columnName,
        CancellationToken ct = default);
    
    bool IsAvailable { get; }
}