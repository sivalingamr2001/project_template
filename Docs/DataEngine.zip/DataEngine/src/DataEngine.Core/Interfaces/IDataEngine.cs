namespace DataEngine.Core.Interfaces;

/// <summary>
/// Primary entry point for all DataEngine operations.
/// This is what consumer apps inject and use.
/// </summary>
public interface IDataEngine
{
    // ── Reads ──────────────────────────────────────────────────────────
    Task<QueryResponse> QueryAsync(
        QueryRequest request,
        CancellationToken ct = default);
    
    Task<QueryResponse> QueryByDefinitionAsync(
        string definitionKey,
        IReadOnlyDictionary<string, object?>? parameters = null,
        CancellationToken ct = default);
    
    // ── Single-row writes ──────────────────────────────────────────────
    Task<MutationResponse> InsertAsync(
        InsertRequest request,
        CancellationToken ct = default);
    
    Task<MutationResponse> UpdateAsync(
        UpdateRequest request,
        CancellationToken ct = default);
    
    Task<MutationResponse> DeleteAsync(
        DeleteRequest request,
        CancellationToken ct = default);
    
    // ── Bulk operations ────────────────────────────────────────────────
    Task<MutationResponse> BulkInsertAsync(
        BulkInsertRequest request,
        CancellationToken ct = default);
    
    Task<MutationResponse> BulkUpdateAsync(
        BulkUpdateRequest request,
        CancellationToken ct = default);
    
    // ── Transaction scope ──────────────────────────────────────────────
    Task<TransactionResponse> ExecuteTransactionAsync(
        TransactionRequest request,
        CancellationToken ct = default);
    
    // ── Stored procedures ─────────────────────────────────────────────
    Task<ProcedureResponse> ExecuteProcedureAsync(
        ProcedureRequest request,
        CancellationToken ct = default);
    
    // ── Schema operations ─────────────────────────────────────────────
    Task<SchemaResponse> GetSchemaAsync(
        string tableName,
        string? database = null,
        CancellationToken ct = default);
    
    Task InvalidateSchemaAsync(
        string? tableName = null,    // null = full refresh
        string? database = null,
        CancellationToken ct = default);
}