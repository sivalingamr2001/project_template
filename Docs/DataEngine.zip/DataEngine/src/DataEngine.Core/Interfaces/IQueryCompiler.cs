namespace DataEngine.Core.Interfaces;

public interface IQueryCompiler
{
    CompiledQuery CompileSelect(QueryRequest request, TableMetadata schema);
    CompiledQuery CompileInsert(InsertRequest request, TableMetadata schema);
    CompiledQuery CompileUpdate(UpdateRequest request, TableMetadata schema);
    CompiledQuery CompileDelete(DeleteRequest request, TableMetadata schema);
    CompiledQuery CompileBulkInsert(BulkInsertRequest request, TableMetadata schema);
}