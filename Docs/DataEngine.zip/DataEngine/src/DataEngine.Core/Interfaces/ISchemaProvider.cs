namespace DataEngine.Core.Interfaces;

public interface ISchemaProvider
{
    /// <summary>
    /// Load schema from INFORMATION_SCHEMA for a given database.
    /// Called on first use and on manual invalidation.
    /// </summary>
    Task<SchemaMetadataSnapshot> LoadSchemaAsync(
        string databaseName,
        CancellationToken ct = default);
    
    /// <summary>
    /// Get currently cached snapshot. Never goes to DB.
    /// </summary>
    SchemaMetadataSnapshot? GetCachedSnapshot(string databaseName);
    
    /// <summary>
    /// Ensure a snapshot is loaded (load if not cached).
    /// </summary>
    Task<SchemaMetadataSnapshot> EnsureSnapshotAsync(
        string databaseName,
        CancellationToken ct = default);
}