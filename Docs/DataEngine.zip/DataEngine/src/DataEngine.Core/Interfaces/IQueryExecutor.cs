namespace DataEngine.Core.Interfaces;

public interface IQueryExecutor
{
    Task<IReadOnlyList<IDictionary<string, object?>>> ExecuteQueryAsync(
        CompiledQuery query,
        string connectionString,
        CancellationToken ct = default);
    
    Task<long> ExecuteCountAsync(
        CompiledQuery query,
        string connectionString,
        CancellationToken ct = default);
}