namespace DataEngine.Core.Interfaces;

public interface IAuditWriter
{
    ValueTask WriteAsync(AuditEntry entry, CancellationToken ct = default);
    bool IsEnabled { get; }
}