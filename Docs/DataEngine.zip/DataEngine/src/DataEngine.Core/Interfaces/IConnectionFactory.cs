namespace DataEngine.Core.Interfaces;

public interface IConnectionFactory
{
    MySqlConnection CreateConnection(string? database = null);
    string GetConnectionString(string? database = null);
    IReadOnlyList<string> GetRegisteredDatabases();
}