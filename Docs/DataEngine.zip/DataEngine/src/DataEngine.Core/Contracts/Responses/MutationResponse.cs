// DataEngine.Core/Contracts/Responses/MutationResponse.cs
namespace DataEngine.Core.Contracts.Responses;

public sealed record MutationResponse
{
    public bool Success { get; init; }
    public int AffectedRows { get; init; }
    public long? InsertedId { get; init; }     // last_insert_id()
    public IReadOnlyList<long>? InsertedIds { get; init; }  // bulk
    public string? Error { get; init; }
    public TimeSpan ExecutionTime { get; init; }
    
    public static MutationResponse Failed(string error) =>
        new() { Success = false, Error = error };
}