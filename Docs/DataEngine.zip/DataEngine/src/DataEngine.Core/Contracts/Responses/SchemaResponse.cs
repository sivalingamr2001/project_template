// DataEngine.Core/Contracts/Responses/SchemaResponse.cs
namespace DataEngine.Core.Contracts.Responses;

/// <summary>
/// Schema metadata for a single table.
/// Useful for dynamic UI generation — e.g. building AG Grid column definitions
/// from live database schema without hardcoding field names.
/// </summary>
public sealed record SchemaResponse
{
    public bool Success { get; init; }
    public string? Error { get; init; }

    public string? TableName { get; init; }
    public string? DatabaseName { get; init; }

    public IReadOnlyList<ColumnInfo>? Columns { get; init; }
    public IReadOnlyList<string>? PrimaryKeys { get; init; }

    public DateTimeOffset? CachedAt { get; init; }

    public static SchemaResponse NotFound(string tableName, string database) =>
        new()
        {
            Success = false,
            Error = $"Table '{tableName}' not found in database '{database}'."
        };
}