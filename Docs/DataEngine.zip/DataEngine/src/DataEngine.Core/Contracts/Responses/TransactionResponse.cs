// DataEngine.Core/Contracts/Responses/TransactionResponse.cs
namespace DataEngine.Core.Contracts.Responses;

/// <summary>
/// Result of a multi-operation transaction execution.
/// </summary>
public sealed record TransactionResponse
{
    public bool Success { get; init; }

    /// <summary>
    /// Number of individual operations that executed before commit (or before failure).
    /// On success this equals the total number of operations submitted.
    /// On failure this equals the number that ran before the rollback.
    /// </summary>
    public int OperationsExecuted { get; init; }

    public string? Error { get; init; }
    public TimeSpan ExecutionTime { get; init; }

    public static TransactionResponse Succeeded(int operationCount, TimeSpan elapsed) =>
        new()
        {
            Success = true,
            OperationsExecuted = operationCount,
            ExecutionTime = elapsed
        };

    public static TransactionResponse Failed(string error, int succeededCount, TimeSpan elapsed) =>
        new()
        {
            Success = false,
            Error = error,
            OperationsExecuted = succeededCount,
            ExecutionTime = elapsed
        };
}