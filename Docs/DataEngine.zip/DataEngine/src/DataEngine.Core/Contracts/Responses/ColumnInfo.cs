// DataEngine.Core/Contracts/Responses/ColumnInfo.cs
namespace DataEngine.Core.Contracts.Responses;

/// <summary>
/// Public-facing column descriptor returned by GetSchemaAsync().
/// Deliberately separate from the internal ColumnMetadata domain object —
/// the public contract should not expose internals like ResolvedDbType.
/// </summary>
public sealed record ColumnInfo
{
    public required string Name { get; init; }
    public required string DataType { get; init; }
    public required bool IsNullable { get; init; }
    public required bool IsAutoIncrement { get; init; }
    public required bool IsPrimaryKey { get; init; }
    public int? MaxLength { get; init; }
    public string? DefaultValue { get; init; }
}