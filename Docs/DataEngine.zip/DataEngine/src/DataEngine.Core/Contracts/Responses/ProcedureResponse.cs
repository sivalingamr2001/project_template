// DataEngine.Core/Contracts/Responses/ProcedureResponse.cs
namespace DataEngine.Core.Contracts.Responses;

public sealed record ProcedureResponse
{
    public bool Success { get; init; }
    
    /// <summary>Multiple result sets (Dapper QueryMultiple)</summary>
    public IReadOnlyList<IReadOnlyList<IReadOnlyDictionary<string, object?>>>? ResultSets { get; init; }
    
    /// <summary>OUTPUT parameter values keyed by parameter name</summary>
    public IReadOnlyDictionary<string, object?>? OutputParameters { get; init; }
    
    public int? AffectedRows { get; init; }
    public string? Error { get; init; }
    public TimeSpan ExecutionTime { get; init; }
}