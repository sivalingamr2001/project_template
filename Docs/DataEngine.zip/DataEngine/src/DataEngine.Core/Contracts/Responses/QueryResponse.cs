// DataEngine.Core/Contracts/Responses/QueryResponse.cs
namespace DataEngine.Core.Contracts.Responses;

public sealed record QueryResponse
{
    public required IReadOnlyList<IReadOnlyDictionary<string, object?>> Data { get; init; }
    public long? TotalCount { get; init; }
    public int PageCount => Pagination is null ? 1
        : TotalCount is null ? 0
        : (int)Math.Ceiling((double)TotalCount.Value / Pagination.PageSize);
    public PaginationClause? Pagination { get; init; }
    public bool Success { get; init; } = true;
    public string? Error { get; init; }
    public TimeSpan ExecutionTime { get; init; }
    
    public static QueryResponse Empty => new()
    {
        Data = Array.Empty<IReadOnlyDictionary<string, object?>>(),
        Success = true
    };
}