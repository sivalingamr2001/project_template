// DataEngine.Core/Contracts/Responses/ProcedureResult.cs
namespace DataEngine.Core.Contracts.Responses;

public sealed record ProcedureResult
{
    public bool Success { get; init; }
    public IReadOnlyList<IReadOnlyList<IReadOnlyDictionary<string, object?>>>? ResultSets { get; init; }
    public IReadOnlyDictionary<string, object?>? OutputParameters { get; init; }
    public int? AffectedRows { get; init; }
    public string? Error { get; init; }
    public TimeSpan ExecutionTime { get; init; }
}
