// DataEngine.Core/Contracts/Responses/TransactionResult.cs
namespace DataEngine.Core.Contracts.Responses;

public sealed record TransactionResult
{
    public bool Success { get; init; }
    public int TotalAffectedRows { get; init; }
    public int SucceededCount { get; init; }
    public string? Error { get; init; }
}
