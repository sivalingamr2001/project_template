// DataEngine.Core/Contracts/Requests/BulkUpdateRequest.cs
namespace DataEngine.Core.Contracts.Requests;

/// <summary>
/// Update multiple rows in a single atomic transaction.
/// Each row specifies its own Values (what to set) and Filters (which row to target).
///
/// Unlike BulkInsert which batches for performance,
/// BulkUpdate always executes as a single transaction — all succeed or all roll back.
/// </summary>
public sealed record BulkUpdateRequest
{
    public required string Table { get; init; }
    public string? Database { get; init; }

    /// <summary>
    /// Each entry is one UPDATE statement: Values = SET clause, Filters = WHERE clause.
    /// Every row MUST have at least one filter — enforced at orchestrator level.
    /// </summary>
    public required IReadOnlyList<BulkUpdateRow> Rows { get; init; }

    public string? ExecutedBy { get; init; }
    public string? CorrelationId { get; init; }
}

/// <summary>
/// A single row in a BulkUpdateRequest.
/// Maps to: UPDATE {Table} SET {Values} WHERE {Filters}
/// </summary>
public sealed record BulkUpdateRow
{
    /// <summary>Column → value pairs to SET.</summary>
    public required IReadOnlyDictionary<string, object?> Values { get; init; }

    /// <summary>
    /// Filter clauses for the WHERE clause.
    /// At least one required — enforced in WriteOrchestrator.
    /// </summary>
    public required IReadOnlyList<FilterClause> Filters { get; init; }
}