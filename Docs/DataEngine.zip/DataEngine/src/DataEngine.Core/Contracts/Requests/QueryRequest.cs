// DataEngine.Core/Contracts/Requests/QueryRequest.cs
namespace DataEngine.Core.Contracts.Requests;

public sealed record QueryRequest
{
    public required string Table { get; init; }
    public string? Database { get; init; }
    
    // Projections — null = SELECT *
    public IReadOnlyList<string>? Columns { get; init; }
    
    // Filtering
    public IReadOnlyList<FilterClause>? Filters { get; init; }
    
    // Sorting
    public IReadOnlyList<SortClause>? Sort { get; init; }
    
    // Pagination
    public PaginationClause? Pagination { get; init; }
    
    // Joins
    public IReadOnlyList<JoinClause>? Joins { get; init; }
    
    // Optimization hints
    public bool IncludeCount { get; init; } = false;
    public int? CommandTimeoutSeconds { get; init; }
}

public sealed record SortClause
{
    public required string Column { get; init; }
    public SortDirection Direction { get; init; } = SortDirection.Ascending;
}

public enum SortDirection { Ascending, Descending }

public sealed record PaginationClause
{
    public int Page { get; init; } = 1;
    public int PageSize { get; init; } = 20;
    
    public int Offset => (Page - 1) * PageSize;
    
    public static PaginationClause Default => new() { Page = 1, PageSize = 20 };
}

public sealed record JoinClause
{
    public required string Table { get; init; }
    public required string LeftColumn { get; init; }
    public required string RightColumn { get; init; }
    public JoinType Type { get; init; } = JoinType.Inner;
    public string? Alias { get; init; }
}

public enum JoinType { Inner, Left, Right }