// DataEngine.Core/Contracts/Requests/BulkInsertRequest.cs
namespace DataEngine.Core.Contracts.Requests;

public sealed record BulkInsertRequest
{
    public required string Table { get; init; }
    public string? Database { get; init; }
    public required IReadOnlyList<IReadOnlyDictionary<string, object?>> Rows { get; init; }
    
    /// <summary>Batch size per transaction. Default 500.</summary>
    public int BatchSize { get; init; } = 500;
    
    public ConflictResolution OnConflict { get; init; } = ConflictResolution.Abort;
    public string? ExecutedBy { get; init; }
}

public enum ConflictResolution
{
    Abort,          // Default: fail the batch
    Ignore,         // INSERT IGNORE
    Replace         // REPLACE INTO (use carefully)
}