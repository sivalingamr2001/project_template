// DataEngine.Core/Contracts/Requests/InsertRequest.cs
namespace DataEngine.Core.Contracts.Requests;

public sealed record InsertRequest
{
    public required string Table { get; init; }
    public string? Database { get; init; }
    public required IReadOnlyDictionary<string, object?> Values { get; init; }
    public bool ReturnInsertedId { get; init; } = true;
    public string? ExecutedBy { get; init; }
    public string? CorrelationId { get; init; }
}