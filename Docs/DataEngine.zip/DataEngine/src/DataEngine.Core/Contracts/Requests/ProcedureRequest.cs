// DataEngine.Core/Contracts/Requests/ProcedureRequest.cs
using System.Data;

namespace DataEngine.Core.Contracts.Requests;

public sealed record ProcedureRequest
{
    public required string ProcedureName { get; init; }
    public string? Database { get; init; }
    public IReadOnlyList<ProcedureParameter>? Parameters { get; init; }
    public ProcedureType Type { get; init; } = ProcedureType.Read;
    public int? CommandTimeoutSeconds { get; init; }
}

public sealed record ProcedureParameter
{
    public required string Name { get; init; }
    public object? Value { get; init; }
    public ParameterDirection Direction { get; init; } = ParameterDirection.Input;
    public DbType? DbType { get; init; }
    public int? Size { get; init; }
}

public enum ProcedureType { Read, Write }
