// DataEngine.Core/Contracts/Requests/UpdateRequest.cs
namespace DataEngine.Core.Contracts.Requests;

public sealed record UpdateRequest
{
    public required string Table { get; init; }
    public string? Database { get; init; }
    public required IReadOnlyDictionary<string, object?> Values { get; init; }
    public required IReadOnlyList<FilterClause> Filters { get; init; }  // REQUIRED — no blind updates
    public bool CaptureOldValues { get; init; } = false;  // for audit
    public string? ExecutedBy { get; init; }
    public string? CorrelationId { get; init; }
}