// DataEngine.Core/Contracts/Requests/TransactionRequest.cs
using System.Data;

namespace DataEngine.Core.Contracts.Requests;

public sealed record TransactionRequest
{
    public required IReadOnlyList<TransactionOperation> Operations { get; init; }
    public string? Database { get; init; }
    public string? ExecutedBy { get; init; }
    public string? CorrelationId { get; init; }
    public IsolationLevel IsolationLevel { get; init; } = IsolationLevel.ReadCommitted;
}

public sealed record TransactionOperation
{
    public required OperationType Type { get; init; }
    public required string Table { get; init; }
    public IReadOnlyDictionary<string, object?>? Values { get; init; }
    public IReadOnlyList<FilterClause>? Filters { get; init; }
    public int Order { get; init; }  // execution sequence
}

public enum OperationType { Insert, Update, Delete }