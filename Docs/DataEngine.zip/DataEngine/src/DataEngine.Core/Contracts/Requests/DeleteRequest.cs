// DataEngine.Core/Contracts/Requests/DeleteRequest.cs
namespace DataEngine.Core.Contracts.Requests;

public sealed record DeleteRequest
{
    public required string Table { get; init; }
    public string? Database { get; init; }
    public required IReadOnlyList<FilterClause> Filters { get; init; }  // REQUIRED — no blind deletes
    public string? ExecutedBy { get; init; }
    public string? CorrelationId { get; init; }
}