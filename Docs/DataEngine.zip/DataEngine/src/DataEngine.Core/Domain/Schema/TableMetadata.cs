// DataEngine.Core/Domain/Schema/TableMetadata.cs
namespace DataEngine.Core.Domain.Schema;

public sealed record TableMetadata
{
    public required string TableName { get; init; }
    public required string DatabaseName { get; init; }
    public required IReadOnlyDictionary<string, ColumnMetadata> Columns { get; init; }
    public required IReadOnlyList<string> PrimaryKeys { get; init; }
    public DateTimeOffset CachedAt { get; init; } = DateTimeOffset.UtcNow;
    
    public bool HasColumn(string name) =>
        Columns.ContainsKey(name);

    public ColumnMetadata GetColumn(string name) =>
        Columns.TryGetValue(name, out var col)
            ? col
            : throw new SchemaValidationException($"Column '{name}' not found in table '{TableName}'.");
    
    public IEnumerable<ColumnMetadata> WritableColumns =>
        Columns.Values.Where(c => !c.IsAutoIncrement);
    
    public IEnumerable<ColumnMetadata> NonPkWritableColumns =>
        WritableColumns.Where(c => !c.IsPrimaryKey);
}