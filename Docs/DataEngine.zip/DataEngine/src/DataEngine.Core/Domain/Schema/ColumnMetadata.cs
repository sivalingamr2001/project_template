// DataEngine.Core/Domain/Schema/ColumnMetadata.cs
namespace DataEngine.Core.Domain.Schema;

public sealed record ColumnMetadata
{
    public required string ColumnName { get; init; }
    public required string DataType { get; init; }
    public required bool IsNullable { get; init; }
    public required bool IsAutoIncrement { get; init; }
    public required bool IsPrimaryKey { get; init; }
    public int? CharacterMaxLength { get; init; }
    public string? ColumnDefault { get; init; }
    public required int OrdinalPosition { get; init; }
    
    // Derived: safe for parameterized use
    public MySqlDbType ResolvedDbType => DataTypeMapper.Resolve(DataType, CharacterMaxLength);
}