// DataEngine.Core/Domain/Schema/DataTypeMapper.cs
namespace DataEngine.Core.Domain.Schema;

internal static class DataTypeMapper
{
    private static readonly Dictionary<string, MySqlDbType> TypeMap =
        new(StringComparer.OrdinalIgnoreCase)
        {
            ["tinyint"]   = MySqlDbType.Byte,
            ["smallint"]  = MySqlDbType.Int16,
            ["mediumint"] = MySqlDbType.Int24,
            ["int"]       = MySqlDbType.Int32,
            ["integer"]   = MySqlDbType.Int32,
            ["bigint"]    = MySqlDbType.Int64,

            ["float"]     = MySqlDbType.Float,
            ["double"]    = MySqlDbType.Double,
            ["decimal"]   = MySqlDbType.Decimal,
            ["numeric"]   = MySqlDbType.Decimal,

            ["char"]      = MySqlDbType.String,
            ["varchar"]   = MySqlDbType.VarChar,
            ["tinytext"]  = MySqlDbType.TinyText,
            ["text"]      = MySqlDbType.Text,
            ["mediumtext"]= MySqlDbType.MediumText,
            ["longtext"]  = MySqlDbType.LongText,
            ["enum"]      = MySqlDbType.Enum,
            ["set"]       = MySqlDbType.Set,

            ["binary"]    = MySqlDbType.Binary,
            ["varbinary"] = MySqlDbType.VarBinary,
            ["tinyblob"]  = MySqlDbType.TinyBlob,
            ["blob"]      = MySqlDbType.Blob,
            ["mediumblob"]= MySqlDbType.MediumBlob,
            ["longblob"]  = MySqlDbType.LongBlob,

            ["date"]      = MySqlDbType.Date,
            ["datetime"]  = MySqlDbType.DateTime,
            ["timestamp"] = MySqlDbType.Timestamp,
            ["time"]      = MySqlDbType.Time,
            ["year"]      = MySqlDbType.Year,

            ["bit"]       = MySqlDbType.Bit,
            ["json"]      = MySqlDbType.JSON,
            ["geometry"]  = MySqlDbType.Geometry,
        };

    public static MySqlDbType Resolve(string dataType, int? charMaxLength)
    {
        if (TypeMap.TryGetValue(dataType, out var dbType))
            return dbType;

        return charMaxLength.HasValue
            ? MySqlDbType.VarChar
            : MySqlDbType.Text;
    }
}
