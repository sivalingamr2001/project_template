// DataEngine.Core/Domain/Schema/SchemaMetadataSnapshot.cs
namespace DataEngine.Core.Domain.Schema;

/// <summary>
/// Immutable point-in-time snapshot of all known tables.
/// Replaced atomically on refresh — never mutated.
/// </summary>
public sealed record SchemaMetadataSnapshot
{
    public required IReadOnlyDictionary<string, TableMetadata> Tables { get; init; }
    public required string DatabaseName { get; init; }
    public DateTimeOffset SnapshotAt { get; init; } = DateTimeOffset.UtcNow;
    
    public bool TableExists(string tableName) =>
        Tables.ContainsKey(tableName.ToLowerInvariant());

    public TableMetadata GetTable(string tableName) =>
        Tables.TryGetValue(tableName.ToLowerInvariant(), out var t)
            ? t
            : throw new TableNotFoundException(tableName, DatabaseName);
}