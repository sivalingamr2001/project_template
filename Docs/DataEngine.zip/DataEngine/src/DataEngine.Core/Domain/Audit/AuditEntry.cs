// DataEngine.Core/Domain/Audit/AuditEntry.cs
namespace DataEngine.Core.Domain.Audit;

public sealed record AuditEntry
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public required string Operation { get; init; }   // INSERT | UPDATE | DELETE
    public required string TableName { get; init; }
    public required string DatabaseName { get; init; }
    public string? RecordId { get; init; }
    public string? OldValues { get; init; }           // JSON
    public string? NewValues { get; init; }           // JSON
    public string? ExecutedBy { get; init; }
    public DateTimeOffset ExecutedAt { get; init; } = DateTimeOffset.UtcNow;
    public string? CorrelationId { get; init; }
}