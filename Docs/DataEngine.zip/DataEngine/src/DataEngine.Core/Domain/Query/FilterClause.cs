// DataEngine.Core/Domain/Query/FilterClause.cs
namespace DataEngine.Core.Domain.Query;

public sealed record FilterClause
{
    public required string Column { get; init; }
    public required FilterOperator Operator { get; init; }
    public required object? Value { get; init; }
    public LogicalOperator Logic { get; init; } = LogicalOperator.And;
}

public enum FilterOperator
{
    Equals, NotEquals,
    GreaterThan, GreaterThanOrEqual,
    LessThan, LessThanOrEqual,
    Like, NotLike,
    In, NotIn,
    IsNull, IsNotNull,
    Between
}

public enum LogicalOperator { And, Or }