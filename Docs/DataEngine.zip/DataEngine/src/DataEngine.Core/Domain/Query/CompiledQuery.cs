// DataEngine.Core/Domain/Query/CompiledQuery.cs
namespace DataEngine.Core.Domain.Query;

/// <summary>
/// Result of query compilation. Immutable. Safe to cache.
/// </summary>
public sealed record CompiledQuery
{
    public required string Sql { get; init; }
    public required IReadOnlyDictionary<string, object?> Parameters { get; init; }
    public required string TableName { get; init; }
    public DateTimeOffset CompiledAt { get; init; } = DateTimeOffset.UtcNow;
    
    // Cache key for compiled query store
    public string CacheKey { get; init; } = string.Empty;
}