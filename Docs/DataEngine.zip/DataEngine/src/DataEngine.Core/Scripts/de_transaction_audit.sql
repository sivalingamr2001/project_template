CREATE TABLE IF NOT EXISTS de_transaction_audit (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    table_name VARCHAR(150) NOT NULL,
    record_id VARCHAR(255) NULL,
    action_type VARCHAR(50) NOT NULL,
    old_values JSON NULL,
    new_values JSON NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);