CREATE TABLE IF NOT EXISTS de_field_mappings (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    connection_id BIGINT NOT NULL,
    table_name VARCHAR(150) NOT NULL,
    column_name VARCHAR(150) NOT NULL,
    api_field_name VARCHAR(150) NOT NULL
);