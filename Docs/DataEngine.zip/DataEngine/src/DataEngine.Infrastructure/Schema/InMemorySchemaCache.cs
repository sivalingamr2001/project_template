// DataEngine.Infrastructure/Schema/InMemorySchemaCache.cs
namespace DataEngine.Infrastructure.Schema;

/// <summary>
/// Thread-safe in-memory schema cache.
/// Uses ConcurrentDictionary for lock-free reads.
/// Snapshots are immutable records replaced atomically.
/// </summary>
public sealed class InMemorySchemaCache : ISchemaCache
{
    private readonly ConcurrentDictionary<string, SchemaMetadataSnapshot> _store = new(
        StringComparer.OrdinalIgnoreCase);
    
    private readonly DataEngineOptions _options;
    private readonly ILogger<InMemorySchemaCache> _logger;
    
    public InMemorySchemaCache(
        DataEngineOptions options,
        ILogger<InMemorySchemaCache> logger)
    {
        _options = options;
        _logger = logger;
    }
    
    public SchemaMetadataSnapshot? Get(string databaseName)
    {
        if (!_store.TryGetValue(databaseName, out var snapshot))
            return null;
        
        // TTL check — treat as miss if expired
        if (_options.SchemaCacheTtl.HasValue &&
            DateTimeOffset.UtcNow - snapshot.SnapshotAt > _options.SchemaCacheTtl.Value)
        {
            _logger.LogDebug(
                "Schema cache expired for {Database} (age: {Age}s). Will reload.",
                databaseName,
                (DateTimeOffset.UtcNow - snapshot.SnapshotAt).TotalSeconds);
            return null;
        }
        
        return snapshot;
    }
    
    public void Set(string databaseName, SchemaMetadataSnapshot snapshot)
    {
        _store[databaseName] = snapshot;
        _logger.LogInformation(
            "Schema cached for {Database}: {TableCount} tables at {Time}",
            databaseName, snapshot.Tables.Count, snapshot.SnapshotAt);
    }
    
    public void Invalidate(string databaseName)
    {
        _store.TryRemove(databaseName, out _);
        _logger.LogInformation("Schema cache invalidated for {Database}", databaseName);
    }
    
    public void InvalidateAll()
    {
        _store.Clear();
        _logger.LogInformation("Full schema cache invalidated");
    }
    
    public IEnumerable<string> GetCachedDatabases() => _store.Keys;
}