// DataEngine.Infrastructure/Schema/DataTypeMapper.cs
namespace DataEngine.Infrastructure.Schema;

/// <summary>
/// Maps MySQL INFORMATION_SCHEMA DATA_TYPE strings to MySqlDbType enum values.
/// Used when building MySqlParameters with explicit type hints for better performance.
/// </summary>
internal static class DataTypeMapper
{
    private static readonly Dictionary<string, MySqlDbType> TypeMap =
        new(StringComparer.OrdinalIgnoreCase)
        {
            // Integer types
            ["tinyint"]   = MySqlDbType.Byte,
            ["smallint"]  = MySqlDbType.Int16,
            ["mediumint"] = MySqlDbType.Int24,
            ["int"]       = MySqlDbType.Int32,
            ["integer"]   = MySqlDbType.Int32,
            ["bigint"]    = MySqlDbType.Int64,

            // Floating point
            ["float"]     = MySqlDbType.Float,
            ["double"]    = MySqlDbType.Double,
            ["decimal"]   = MySqlDbType.Decimal,
            ["numeric"]   = MySqlDbType.Decimal,

            // String types
            ["char"]      = MySqlDbType.String,
            ["varchar"]   = MySqlDbType.VarChar,
            ["tinytext"]  = MySqlDbType.TinyText,
            ["text"]      = MySqlDbType.Text,
            ["mediumtext"]= MySqlDbType.MediumText,
            ["longtext"]  = MySqlDbType.LongText,
            ["enum"]      = MySqlDbType.Enum,
            ["set"]       = MySqlDbType.Set,

            // Binary types
            ["binary"]    = MySqlDbType.Binary,
            ["varbinary"] = MySqlDbType.VarBinary,
            ["tinyblob"]  = MySqlDbType.TinyBlob,
            ["blob"]      = MySqlDbType.Blob,
            ["mediumblob"]= MySqlDbType.MediumBlob,
            ["longblob"]  = MySqlDbType.LongBlob,

            // Date/time types
            ["date"]      = MySqlDbType.Date,
            ["datetime"]  = MySqlDbType.DateTime,
            ["timestamp"] = MySqlDbType.Timestamp,
            ["time"]      = MySqlDbType.Time,
            ["year"]      = MySqlDbType.Year,

            // Other
            ["bit"]       = MySqlDbType.Bit,
            ["json"]      = MySqlDbType.JSON,
            ["geometry"]  = MySqlDbType.Geometry,
        };

    public static MySqlDbType Resolve(string dataType, int? charMaxLength)
    {
        if (TypeMap.TryGetValue(dataType, out var dbType))
            return dbType;

        // Fallback: use VarChar for unknown string-like types
        return charMaxLength.HasValue
            ? MySqlDbType.VarChar
            : MySqlDbType.Text;
    }
}