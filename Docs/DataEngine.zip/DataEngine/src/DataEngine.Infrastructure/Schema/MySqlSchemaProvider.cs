// DataEngine.Infrastructure/Schema/MySqlSchemaProvider.cs
namespace DataEngine.Infrastructure.Schema;

public sealed class MySqlSchemaProvider : ISchemaProvider
{
    private readonly ISchemaCache _cache;
    private readonly IConnectionFactory _connectionFactory;
    private readonly ILogger<MySqlSchemaProvider> _logger;
    
    // SemaphoreSlim per database to prevent thundering herd on cold start
    private readonly ConcurrentDictionary<string, SemaphoreSlim> _loadLocks = new();
    
    // SQL against INFORMATION_SCHEMA — parameterized, read-only, safe
    private const string ColumnsSql = """
        SELECT
            c.TABLE_NAME         AS TableName,
            c.COLUMN_NAME        AS ColumnName,
            c.DATA_TYPE          AS DataType,
            c.IS_NULLABLE        AS IsNullable,
            c.COLUMN_DEFAULT     AS ColumnDefault,
            c.CHARACTER_MAXIMUM_LENGTH AS CharacterMaxLength,
            c.ORDINAL_POSITION   AS OrdinalPosition,
            CASE WHEN c.EXTRA LIKE '%auto_increment%' THEN 1 ELSE 0 END AS IsAutoIncrement,
            CASE WHEN k.COLUMN_NAME IS NOT NULL THEN 1 ELSE 0 END AS IsPrimaryKey
        FROM INFORMATION_SCHEMA.COLUMNS c
        LEFT JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE k
            ON  k.TABLE_SCHEMA = c.TABLE_SCHEMA
            AND k.TABLE_NAME   = c.TABLE_NAME
            AND k.COLUMN_NAME  = c.COLUMN_NAME
            AND k.CONSTRAINT_NAME = 'PRIMARY'
        WHERE c.TABLE_SCHEMA = @DatabaseName
        ORDER BY c.TABLE_NAME, c.ORDINAL_POSITION;
        """;
    
    public MySqlSchemaProvider(
        ISchemaCache cache,
        IConnectionFactory connectionFactory,
        ILogger<MySqlSchemaProvider> logger)
    {
        _cache = cache;
        _connectionFactory = connectionFactory;
        _logger = logger;
    }
    
    public SchemaMetadataSnapshot? GetCachedSnapshot(string databaseName) =>
        _cache.Get(databaseName);
    
    public async Task<SchemaMetadataSnapshot> EnsureSnapshotAsync(
        string databaseName,
        CancellationToken ct = default)
    {
        var cached = _cache.Get(databaseName);
        if (cached is not null) return cached;
        
        return await LoadSchemaAsync(databaseName, ct);
    }
    
    public async Task<SchemaMetadataSnapshot> LoadSchemaAsync(
        string databaseName,
        CancellationToken ct = default)
    {
        // Per-database load lock — prevents concurrent DB queries for same schema
        var semaphore = _loadLocks.GetOrAdd(databaseName, _ => new SemaphoreSlim(1, 1));
        
        await semaphore.WaitAsync(ct);
        try
        {
            // Double-check after acquiring lock
            var cached = _cache.Get(databaseName);
            if (cached is not null) return cached;
            
            _logger.LogInformation("Loading schema from INFORMATION_SCHEMA for {Database}", databaseName);
            
            await using var conn = _connectionFactory.CreateConnection(databaseName);
            await conn.OpenAsync(ct);
            
            // Use Dapper for schema read (safe — parameterized, not user input)
            var rows = await conn.QueryAsync<SchemaRow>(
                ColumnsSql,
                new { DatabaseName = databaseName },
                commandTimeout: 30);
            
            var snapshot = BuildSnapshot(databaseName, rows);
            _cache.Set(databaseName, snapshot);
            
            return snapshot;
        }
        finally
        {
            semaphore.Release();
        }
    }
    
    private static SchemaMetadataSnapshot BuildSnapshot(
        string databaseName,
        IEnumerable<SchemaRow> rows)
    {
        var tables = rows
            .GroupBy(r => r.TableName, StringComparer.OrdinalIgnoreCase)
            .Select(g =>
            {
                var columns = g
                    .Select(r => new ColumnMetadata
                    {
                        ColumnName = r.ColumnName,
                        DataType = r.DataType,
                        IsNullable = r.IsNullable == "YES",
                        IsAutoIncrement = r.IsAutoIncrement,
                        IsPrimaryKey = r.IsPrimaryKey,
                        CharacterMaxLength = r.CharacterMaxLength,
                        ColumnDefault = r.ColumnDefault,
                        OrdinalPosition = r.OrdinalPosition
                    })
                    .ToDictionary(c => c.ColumnName, StringComparer.OrdinalIgnoreCase);
                
                var primaryKeys = columns.Values
                    .Where(c => c.IsPrimaryKey)
                    .OrderBy(c => c.OrdinalPosition)
                    .Select(c => c.ColumnName)
                    .ToList();
                
                return new TableMetadata
                {
                    TableName = g.Key,
                    DatabaseName = databaseName,
                    Columns = columns,
                    PrimaryKeys = primaryKeys
                };
            })
            .ToDictionary(t => t.TableName, StringComparer.OrdinalIgnoreCase);
        
        return new SchemaMetadataSnapshot
        {
            DatabaseName = databaseName,
            Tables = tables
        };
    }
    
    // Internal DTO for Dapper — never exposed
    private sealed class SchemaRow
    {
        public string TableName { get; set; } = default!;
        public string ColumnName { get; set; } = default!;
        public string DataType { get; set; } = default!;
        public string IsNullable { get; set; } = default!;
        public string? ColumnDefault { get; set; }
        public int? CharacterMaxLength { get; set; }
        public int OrdinalPosition { get; set; }
        public bool IsAutoIncrement { get; set; }
        public bool IsPrimaryKey { get; set; }
    }
}