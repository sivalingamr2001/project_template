// DataEngine.Infrastructure/Schema/SchemaRefreshService.cs
namespace DataEngine.Infrastructure.Schema;

/// <summary>
/// Background service that preloads schema on startup and optionally
/// refreshes it on a timer (if SchemaCacheTtl is configured).
///
/// Design: uses IServiceScopeFactory because ISchemaProvider is Scoped,
/// not Singleton. Never inject Scoped services directly into IHostedService.
/// </summary>
public sealed class SchemaRefreshService : BackgroundService
{
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly MySqlConnectionFactory _connectionFactory;
    private readonly DataEngineOptions _options;
    private readonly ILogger<SchemaRefreshService> _logger;

    public SchemaRefreshService(
        IServiceScopeFactory scopeFactory,
        MySqlConnectionFactory connectionFactory,
        DataEngineOptions options,
        ILogger<SchemaRefreshService> logger)
    {
        _scopeFactory = scopeFactory;
        _connectionFactory = connectionFactory;
        _options = options;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        // Preload schema for all registered databases at startup
        if (_options.PreloadSchemaOnStartup)
        {
            await PreloadAllAsync(stoppingToken);
        }

        // If TTL is configured, periodically refresh on 80% of TTL interval
        // (refresh before expiry to avoid cache miss on hot path)
        if (_options.SchemaCacheTtl.HasValue)
        {
            var refreshInterval = _options.SchemaCacheTtl.Value * 0.8;

            _logger.LogInformation(
                "Schema auto-refresh enabled. Interval: {Interval}",
                refreshInterval);

            while (!stoppingToken.IsCancellationRequested)
            {
                await Task.Delay(refreshInterval, stoppingToken);

                if (!stoppingToken.IsCancellationRequested)
                    await PreloadAllAsync(stoppingToken);
            }
        }
    }

    private async Task PreloadAllAsync(CancellationToken ct)
    {
        var databases = _connectionFactory.GetRegisteredDatabases();

        foreach (var dbAlias in databases)
        {
            try
            {
                // Resolve actual database name from connection string
                var cs = _connectionFactory.GetConnectionString(dbAlias);
                var builder = new MySqlConnectionStringBuilder(cs);
                var dbName = builder.Database;

                if (string.IsNullOrWhiteSpace(dbName)) continue;

                await using var scope = _scopeFactory.CreateAsyncScope();
                var provider = scope.ServiceProvider
                    .GetRequiredService<ISchemaProvider>();

                _logger.LogInformation(
                    "Preloading schema for database '{Database}'...", dbName);

                await provider.LoadSchemaAsync(dbName, ct);

                _logger.LogInformation(
                    "Schema preload complete for '{Database}'.", dbName);
            }
            catch (Exception ex) when (!ct.IsCancellationRequested)
            {
                // Log but don't crash the host — app should still start
                // even if schema preload fails (lazy loading will handle it)
                _logger.LogError(ex,
                    "Failed to preload schema for database alias '{Alias}'. " +
                    "Schema will be loaded on first request.", dbAlias);
            }
        }
    }
}