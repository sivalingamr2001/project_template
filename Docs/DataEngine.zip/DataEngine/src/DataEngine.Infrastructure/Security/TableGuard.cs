// DataEngine.Infrastructure/Security/TableGuard.cs
namespace DataEngine.Infrastructure.Security;

public sealed class TableGuard
{
    private static readonly HashSet<string> ForbiddenDatabases = new(StringComparer.OrdinalIgnoreCase)
    {
        "mysql", "information_schema", "performance_schema", "sys"
    };
    
    public void AssertAllowed(string tableName, string databaseName)
    {
        if (string.IsNullOrWhiteSpace(tableName))
            throw new SecurityViolationException("Table name cannot be empty.");
        
        if (ForbiddenDatabases.Contains(databaseName))
            throw new SecurityViolationException(
                $"Access to system database '{databaseName}' is forbidden.");
        
        // Prevent any injection attempts via table name
        if (tableName.Contains('`') || tableName.Contains(';') ||
            tableName.Contains(' ') || tableName.Contains('-'))
            throw new SecurityViolationException(
                $"Table name '{tableName}' contains invalid characters.");
    }
    
    public void AssertExists(string tableName, SchemaMetadataSnapshot snapshot)
    {
        if (!snapshot.TableExists(tableName))
            throw new TableNotFoundException(tableName, snapshot.DatabaseName);
    }
}