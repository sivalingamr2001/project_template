// DataEngine.Infrastructure/Security/ColumnGuard.cs
namespace DataEngine.Infrastructure.Security;

public sealed class ColumnGuard
{
    public void AssertExists(string columnName, TableMetadata schema)
    {
        if (!schema.HasColumn(columnName))
            throw new SchemaValidationException(
                $"Column '{columnName}' does not exist in table '{schema.TableName}'.");
    }
    
    public void AssertWritable(string columnName, TableMetadata schema)
    {
        AssertExists(columnName, schema);
        var col = schema.GetColumn(columnName);
        if (col.IsAutoIncrement)
            throw new SchemaValidationException(
                $"Column '{columnName}' is auto-increment and cannot be written explicitly.");
    }
}