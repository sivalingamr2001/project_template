// DataEngine.Infrastructure/Write/AdoNetWriteExecutor.cs
namespace DataEngine.Infrastructure.Write;

public sealed class AdoNetWriteExecutor
{
    private readonly ILogger<AdoNetWriteExecutor> _logger;
    
    public AdoNetWriteExecutor(ILogger<AdoNetWriteExecutor> logger)
    {
        _logger = logger;
    }
    
    public async Task<MutationResult> ExecuteInsertAsync(
        CompiledQuery query,
        string connectionString,
        CancellationToken ct = default)
    {
        var sw = Stopwatch.StartNew();
        await using var conn = new MySqlConnection(connectionString);
        await conn.OpenAsync(ct);
        
        await using var cmd = conn.CreateCommand();
        cmd.CommandText = query.Sql;
        cmd.CommandType = CommandType.Text;
        BindParameters(cmd, query.Parameters);
        
        long insertedId = 0;
        int affectedRows = 0;
        
        await using var reader = await cmd.ExecuteReaderAsync(ct);
        affectedRows = reader.RecordsAffected;
        
        if (await reader.ReadAsync(ct))
            insertedId = reader.GetInt64(0);
        
        sw.Stop();
        _logger.LogDebug("INSERT on {Table}: {AffectedRows} row(s), id={Id} in {Ms}ms",
            query.TableName, affectedRows, insertedId, sw.ElapsedMilliseconds);
        
        return new MutationResult(affectedRows, insertedId);
    }
    
    public async Task<int> ExecuteNonQueryAsync(
        CompiledQuery query,
        string connectionString,
        CancellationToken ct = default)
    {
        await using var conn = new MySqlConnection(connectionString);
        await conn.OpenAsync(ct);
        
        await using var cmd = conn.CreateCommand();
        cmd.CommandText = query.Sql;
        cmd.CommandType = CommandType.Text;
        BindParameters(cmd, query.Parameters);
        
        return await cmd.ExecuteNonQueryAsync(ct);
    }
    
    /// <summary>
    /// Execute multiple commands within one transaction.
    /// Rolls back all on any failure.
    /// </summary>
    public async Task<TransactionResult> ExecuteTransactionAsync(
        IReadOnlyList<CompiledQuery> queries,
        string connectionString,
        IsolationLevel isolationLevel = IsolationLevel.ReadCommitted,
        CancellationToken ct = default)
    {
        await using var conn = new MySqlConnection(connectionString);
        await conn.OpenAsync(ct);
        await using var txn = await conn.BeginTransactionAsync(isolationLevel, ct);
        
        var results = new List<int>(queries.Count);
        
        try
        {
            foreach (var query in queries)
            {
                await using var cmd = conn.CreateCommand();
                cmd.Transaction = txn;
                cmd.CommandText = query.Sql;
                BindParameters(cmd, query.Parameters);
                results.Add(await cmd.ExecuteNonQueryAsync(ct));
            }
            
            await txn.CommitAsync(ct);
            return TransactionResult.CreateSuccess(results);
        }
        catch (Exception ex)
        {
            await txn.RollbackAsync(ct);
            _logger.LogError(ex, "Transaction rolled back after executing {Count}/{Total} queries",
                results.Count, queries.Count);
            return TransactionResult.CreateFailed(ex.Message);
        }
    }
    
    private static void BindParameters(MySqlCommand cmd, IReadOnlyDictionary<string, object?> parameters)
    {
        foreach (var (name, value) in parameters)
        {
            var param = cmd.CreateParameter();
            param.ParameterName = $"@{name}";
            param.Value = value ?? DBNull.Value;
            cmd.Parameters.Add(param);
        }
    }
}