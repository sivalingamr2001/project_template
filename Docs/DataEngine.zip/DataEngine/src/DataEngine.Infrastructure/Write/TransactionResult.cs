// DataEngine.Infrastructure/Write/TransactionResult.cs
namespace DataEngine.Infrastructure.Write;

public sealed record TransactionResult
{
    public bool Success { get; init; }
    public int TotalAffectedRows { get; init; }
    public int SucceededCount { get; init; }
    public string? Error { get; init; }

    public static TransactionResult CreateSuccess(IReadOnlyList<int> perQueryAffectedRows) =>
        new()
        {
            Success = true,
            TotalAffectedRows = perQueryAffectedRows.Sum(),
            SucceededCount = perQueryAffectedRows.Count
        };

    public static TransactionResult CreateFailed(string error, int succeededCount = 0) =>
        new()
        {
            Success = false,
            Error = error,
            SucceededCount = succeededCount
        };
}
