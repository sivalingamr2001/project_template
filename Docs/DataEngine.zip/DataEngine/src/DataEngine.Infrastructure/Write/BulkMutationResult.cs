// DataEngine.Infrastructure/Write/BulkMutationResult.cs
namespace DataEngine.Infrastructure.Write;

public sealed record BulkMutationResult
{
    public bool Success { get; init; }
    public int TotalAffectedRows { get; init; }
    public int BatchesExecuted { get; init; }
    public int TotalBatches { get; init; }
    public string? Error { get; init; }
    public TimeSpan ExecutionTime { get; init; }
}