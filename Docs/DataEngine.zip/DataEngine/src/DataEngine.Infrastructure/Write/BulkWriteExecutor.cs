// DataEngine.Infrastructure/Write/BulkWriteExecutor.cs
namespace DataEngine.Infrastructure.Write;

/// <summary>
/// Executes bulk INSERT operations in configurable batches.
///
/// Design: splits large row sets into batches, executes each batch
/// in its own transaction. If one batch fails, previous batches
/// are already committed — this is intentional for large imports.
/// For atomic bulk insert, use TransactionCoordinator instead with
/// a smaller row set.
/// </summary>
public sealed class BulkWriteExecutor
{
    private readonly ILogger<BulkWriteExecutor> _logger;

    public BulkWriteExecutor(ILogger<BulkWriteExecutor> logger)
    {
        _logger = logger;
    }

    public async Task<BulkMutationResult> ExecuteBulkInsertAsync(
        IReadOnlyList<CompiledQuery> batches,
        string connectionString,
        CancellationToken ct = default)
    {
        var sw = Stopwatch.StartNew();
        int totalAffected = 0;
        int batchesSucceeded = 0;
        var insertedIds = new List<long>();

        for (int i = 0; i < batches.Count; i++)
        {
            ct.ThrowIfCancellationRequested();

            try
            {
                var result = await ExecuteBatchAsync(batches[i], connectionString, ct);
                totalAffected += result.AffectedRows;
                batchesSucceeded++;

                _logger.LogDebug(
                    "Bulk insert batch {Batch}/{Total}: {Rows} rows affected",
                    i + 1, batches.Count, result.AffectedRows);
            }
            catch (Exception ex)
            {
                sw.Stop();
                _logger.LogError(ex,
                    "Bulk insert failed at batch {Batch}/{Total}. " +
                    "{Committed} batches committed before failure.",
                    i + 1, batches.Count, batchesSucceeded);

                return new BulkMutationResult
                {
                    Success = false,
                    TotalAffectedRows = totalAffected,
                    BatchesExecuted = batchesSucceeded,
                    TotalBatches = batches.Count,
                    Error = ex.Message,
                    ExecutionTime = sw.Elapsed
                };
            }
        }

        sw.Stop();
        return new BulkMutationResult
        {
            Success = true,
            TotalAffectedRows = totalAffected,
            BatchesExecuted = batchesSucceeded,
            TotalBatches = batches.Count,
            ExecutionTime = sw.Elapsed
        };
    }

    private static async Task<(int AffectedRows, long LastInsertId)> ExecuteBatchAsync(
        CompiledQuery batch,
        string connectionString,
        CancellationToken ct)
    {
        await using var conn = new MySqlConnection(connectionString);
        await conn.OpenAsync(ct);
        await using var txn = await conn.BeginTransactionAsync(ct);

        try
        {
            await using var cmd = conn.CreateCommand();
            cmd.Transaction = txn;
            cmd.CommandText = batch.Sql;
            cmd.CommandType = CommandType.Text;

            foreach (var (name, value) in batch.Parameters)
            {
                var p = cmd.CreateParameter();
                p.ParameterName = $"@{name}";
                p.Value = value ?? DBNull.Value;
                cmd.Parameters.Add(p);
            }

            int affected = await cmd.ExecuteNonQueryAsync(ct);
            long lastId = cmd.LastInsertedId;

            await txn.CommitAsync(ct);
            return (affected, lastId);
        }
        catch
        {
            await txn.RollbackAsync(ct);
            throw;
        }
    }

    /// <summary>
    /// Split a BulkInsertRequest into multiple CompiledQuery batches.
    /// Each batch contains at most <paramref name="batchSize"/> rows.
    /// </summary>
    public static IReadOnlyList<BulkInsertRequest> SplitIntoBatches(
        BulkInsertRequest request,
        int batchSize)
    {
        if (request.Rows.Count <= batchSize)
            return [request];

        return request.Rows
            .Select((row, idx) => (row, idx))
            .GroupBy(t => t.idx / batchSize)
            .Select(g => request with
            {
                Rows = g.Select(t => t.row).ToList().AsReadOnly()
            })
            .ToList()
            .AsReadOnly();
    }
}