// DataEngine.Infrastructure/Write/MutationResult.cs
namespace DataEngine.Infrastructure.Write;

public sealed record MutationResult(
    int AffectedRows,
    long InsertedId);