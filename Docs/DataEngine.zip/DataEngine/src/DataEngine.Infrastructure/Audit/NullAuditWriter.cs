// DataEngine.Infrastructure/Audit/NullAuditWriter.cs
namespace DataEngine.Infrastructure.Audit;

/// <summary>
/// No-op audit writer. Registered when EnableAudit = false.
/// Zero allocations, zero overhead.
/// </summary>
public sealed class NullAuditWriter : IAuditWriter
{
    public bool IsEnabled => false;

    public ValueTask WriteAsync(AuditEntry entry, CancellationToken ct = default)
        => ValueTask.CompletedTask;
}