// DataEngine.Infrastructure/Audit/TableAuditWriter.cs
namespace DataEngine.Infrastructure.Audit;

/// <summary>
/// Writes audit entries to the 'de_transaction_audit' table.
///
/// Design rules:
/// 1. Fire-and-forget style — audit failures must never surface to the caller.
///    The orchestrator catches exceptions from WriteAsync and logs them.
/// 2. Uses ADO.NET directly — no ORM, minimal allocation.
/// 3. Uses INSERT IGNORE to handle rare duplicate entry on retry.
/// </summary>
public sealed class TableAuditWriter : IAuditWriter
{
    public bool IsEnabled => true;

    private readonly IConnectionFactory _connectionFactory;
    private readonly ILogger<TableAuditWriter> _logger;

    private const string InsertSql = """
        INSERT IGNORE INTO de_transaction_audit
            (id, operation, table_name, database_name, record_id,
             old_values, new_values, executed_by, executed_at, correlation_id)
        VALUES
            (@Id, @Operation, @TableName, @DatabaseName, @RecordId,
             @OldValues, @NewValues, @ExecutedBy, @ExecutedAt, @CorrelationId);
        """;

    public TableAuditWriter(
        IConnectionFactory connectionFactory,
        ILogger<TableAuditWriter> logger)
    {
        _connectionFactory = connectionFactory;
        _logger = logger;
    }

    public async ValueTask WriteAsync(AuditEntry entry, CancellationToken ct = default)
    {
        try
        {
            await using var conn = _connectionFactory.CreateConnection();
            await conn.OpenAsync(ct);

            await using var cmd = conn.CreateCommand();
            cmd.CommandText = InsertSql;
            cmd.CommandType = CommandType.Text;

            AddParam(cmd, "@Id",            entry.Id.ToString("N"));
            AddParam(cmd, "@Operation",     entry.Operation);
            AddParam(cmd, "@TableName",     entry.TableName);
            AddParam(cmd, "@DatabaseName",  entry.DatabaseName);
            AddParam(cmd, "@RecordId",      entry.RecordId);
            AddParam(cmd, "@OldValues",     entry.OldValues);
            AddParam(cmd, "@NewValues",     entry.NewValues);
            AddParam(cmd, "@ExecutedBy",    entry.ExecutedBy);
            AddParam(cmd, "@ExecutedAt",    entry.ExecutedAt.UtcDateTime);
            AddParam(cmd, "@CorrelationId", entry.CorrelationId);

            await cmd.ExecuteNonQueryAsync(ct);
        }
        catch (Exception ex)
        {
            // Log only — audit failure must not propagate
            _logger.LogError(ex,
                "Audit write failed for {Op} on {Table} [{Id}]",
                entry.Operation, entry.TableName, entry.Id);
        }
    }

    private static void AddParam(MySqlCommand cmd, string name, object? value)
    {
        var p = cmd.CreateParameter();
        p.ParameterName = name;
        p.Value = value ?? DBNull.Value;
        cmd.Parameters.Add(p);
    }
}