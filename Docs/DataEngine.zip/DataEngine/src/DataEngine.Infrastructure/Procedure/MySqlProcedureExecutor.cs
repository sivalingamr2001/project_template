// DataEngine.Infrastructure/Procedure/MySqlProcedureExecutor.cs
namespace DataEngine.Infrastructure.Procedure;

public sealed class MySqlProcedureExecutor : IProcedureExecutor
{
    private readonly ILogger<MySqlProcedureExecutor> _logger;
    
    public MySqlProcedureExecutor(ILogger<MySqlProcedureExecutor> logger)
    {
        _logger = logger;
    }
    
    /// <summary>
    /// Use Dapper for read procedures — handles multiple result sets cleanly.
    /// </summary>
    public async Task<ProcedureResult> ExecuteReadAsync(
        ProcedureRequest request,
        string connectionString,
        CancellationToken ct = default)
    {
        var sw = Stopwatch.StartNew();
        await using var conn = new MySqlConnection(connectionString);
        await conn.OpenAsync(ct);
        
        var dp = new DynamicParameters();
        foreach (var p in request.Parameters ?? [])
        {
            if (p.Direction == ParameterDirection.Input)
                dp.Add(p.Name, p.Value);
            else
                dp.Add(p.Name, p.Value, p.DbType,
                    direction: p.Direction, size: p.Size);
        }
        
        using var multi = await conn.QueryMultipleAsync(
            request.ProcedureName,
            dp,
            commandType: CommandType.StoredProcedure,
            commandTimeout: request.CommandTimeoutSeconds ?? 30);
        
        var resultSets = new List<IReadOnlyList<IReadOnlyDictionary<string, object?>>>();
        
        while (!multi.IsConsumed)
        {
            var rows = (await multi.ReadAsync())
                .Select(row => (IReadOnlyDictionary<string, object?>)
                    ((IDictionary<string, object>)row)
                    .ToDictionary(k => k.Key, k => (object?)k.Value)
                    .AsReadOnly())
                .ToList()
                .AsReadOnly();
            resultSets.Add(rows);
        }
        
        // Collect OUTPUT parameters
        var outputParams = request.Parameters?
            .Where(p => p.Direction != ParameterDirection.Input)
            .ToDictionary(p => p.Name, p => dp.Get<object?>(p.Name));
        
        sw.Stop();
        return new ProcedureResult
        {
            Success = true,
            ResultSets = resultSets,
            OutputParameters = outputParams,
            ExecutionTime = sw.Elapsed
        };
    }
    
    /// <summary>
    /// Use ADO.NET for write procedures — full control over transaction scope.
    /// </summary>
    public async Task<ProcedureResult> ExecuteWriteAsync(
        ProcedureRequest request,
        string connectionString,
        CancellationToken ct = default)
    {
        var sw = Stopwatch.StartNew();
        await using var conn = new MySqlConnection(connectionString);
        await conn.OpenAsync(ct);
        
        await using var cmd = conn.CreateCommand();
        cmd.CommandText = request.ProcedureName;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandTimeout = request.CommandTimeoutSeconds ?? 30;
        
        var outputParamMap = new Dictionary<string, MySqlParameter>();
        
        foreach (var p in request.Parameters ?? [])
        {
            var mp = cmd.CreateParameter();
            mp.ParameterName = p.Name.StartsWith("@") ? p.Name : $"@{p.Name}";
            mp.Value = p.Value ?? DBNull.Value;
            mp.Direction = p.Direction;
            if (p.DbType.HasValue) mp.DbType = p.DbType.Value;
            if (p.Size.HasValue) mp.Size = p.Size.Value;
            cmd.Parameters.Add(mp);
            
            if (p.Direction != ParameterDirection.Input)
                outputParamMap[p.Name] = mp;
        }
        
        int affectedRows = await cmd.ExecuteNonQueryAsync(ct);
        
        var outputValues = outputParamMap
            .ToDictionary(
                kv => kv.Key,
                kv => kv.Value.Value == DBNull.Value ? (object?)null : kv.Value.Value);
        
        sw.Stop();
        return new ProcedureResult
        {
            Success = true,
            AffectedRows = affectedRows,
            OutputParameters = outputValues,
            ExecutionTime = sw.Elapsed
        };
    }
}