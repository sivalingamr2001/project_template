// DataEngine.Infrastructure/FieldMapping/NullFieldMapperProvider.cs
namespace DataEngine.Infrastructure.FieldMapping;

/// <summary>
/// No-op field mapper. Registered when EnableFieldMapping = false.
/// All resolution calls return null (use original name).
/// </summary>
public sealed class NullFieldMapperProvider : IFieldMapperProvider
{
    public bool IsAvailable => false;

    public ValueTask<string?> ResolveColumnAsync(
        string tableName,
        string alias,
        CancellationToken ct = default)
        => ValueTask.FromResult<string?>(null);

    public ValueTask<string?> ResolveAliasAsync(
        string tableName,
        string columnName,
        CancellationToken ct = default)
        => ValueTask.FromResult<string?>(null);
}