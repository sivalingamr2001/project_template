// DataEngine.Infrastructure/FieldMapping/FieldMapperProvider.cs
namespace DataEngine.Infrastructure.FieldMapping;

/// <summary>
/// Live field mapper backed by the 'de_field_mappings' table.
/// Results are cached per table per application lifetime.
/// Cache is invalidated when schema is invalidated.
///
/// Table structure:
///   table_name  | column_name | alias     | direction
///   orders      | cust_id     | customerId| both
///   orders      | qty         | quantity  | both
/// </summary>
public sealed class FieldMapperProvider : IFieldMapperProvider
{
    public bool IsAvailable => true;

    // Cache: tableName → (alias → columnName, columnName → alias)
    private readonly ConcurrentDictionary<string, TableMappings> _cache = new(
        StringComparer.OrdinalIgnoreCase);

    private readonly IConnectionFactory _connectionFactory;
    private readonly ILogger<FieldMapperProvider> _logger;

    private const string LoadSql = """
        SELECT column_name, alias, direction
        FROM de_field_mappings
        WHERE table_name = @TableName
          AND direction IN ('in', 'both', 'out');
        """;

    public FieldMapperProvider(
        IConnectionFactory connectionFactory,
        ILogger<FieldMapperProvider> logger)
    {
        _connectionFactory = connectionFactory;
        _logger = logger;
    }

    public async ValueTask<string?> ResolveColumnAsync(
        string tableName,
        string alias,
        CancellationToken ct = default)
    {
        var mappings = await GetMappingsAsync(tableName, ct);
        return mappings.AliasToColumn.TryGetValue(alias, out var col) ? col : null;
    }

    public async ValueTask<string?> ResolveAliasAsync(
        string tableName,
        string columnName,
        CancellationToken ct = default)
    {
        var mappings = await GetMappingsAsync(tableName, ct);
        return mappings.ColumnToAlias.TryGetValue(columnName, out var alias) ? alias : null;
    }

    private async ValueTask<TableMappings> GetMappingsAsync(
        string tableName,
        CancellationToken ct)
    {
        if (_cache.TryGetValue(tableName, out var cached))
            return cached;

        var mappings = await LoadFromDbAsync(tableName, ct);
        _cache[tableName] = mappings;
        return mappings;
    }

    private async Task<TableMappings> LoadFromDbAsync(
        string tableName,
        CancellationToken ct)
    {
        try
        {
            await using var conn = _connectionFactory.CreateConnection();
            await conn.OpenAsync(ct);

            var rows = await conn.QueryAsync<FieldMappingRow>(
                LoadSql, new { TableName = tableName });

            var aliasToColumn = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var columnToAlias = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

            foreach (var row in rows)
            {
                if (row.Direction is "in" or "both")
                    aliasToColumn[row.Alias] = row.ColumnName;
                if (row.Direction is "out" or "both")
                    columnToAlias[row.ColumnName] = row.Alias;
            }

            _logger.LogDebug(
                "Loaded {Count} field mappings for table '{Table}'",
                aliasToColumn.Count, tableName);

            return new TableMappings(aliasToColumn, columnToAlias);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex,
                "Failed to load field mappings for '{Table}'. Using no mappings.",
                tableName);
            return TableMappings.Empty;
        }
    }

    private sealed record TableMappings(
        IReadOnlyDictionary<string, string> AliasToColumn,
        IReadOnlyDictionary<string, string> ColumnToAlias)
    {
        public static TableMappings Empty => new(
            new Dictionary<string, string>(),
            new Dictionary<string, string>());
    }

    private sealed class FieldMappingRow
    {
        public string ColumnName { get; set; } = default!;
        public string Alias { get; set; } = default!;
        public string Direction { get; set; } = default!;
    }
}