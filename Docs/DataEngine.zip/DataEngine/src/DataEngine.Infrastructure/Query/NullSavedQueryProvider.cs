// DataEngine.Infrastructure/Query/NullSavedQueryProvider.cs
namespace DataEngine.Infrastructure.Query;

/// <summary>
/// No-op saved query provider. Registered when EnableSavedQueryDefinitions = false.
/// </summary>
public sealed class NullSavedQueryProvider : ISavedQueryProvider
{
    public bool IsAvailable => false;

    public ValueTask<QueryRequest?> ResolveAsync(
        string definitionKey,
        CancellationToken ct = default)
        => ValueTask.FromResult<QueryRequest?>(null);
}