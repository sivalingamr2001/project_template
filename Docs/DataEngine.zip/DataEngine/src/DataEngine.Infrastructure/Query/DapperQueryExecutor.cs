// DataEngine.Infrastructure/Query/DapperQueryExecutor.cs
namespace DataEngine.Infrastructure.Query;

public sealed class DapperQueryExecutor : IQueryExecutor
{
    private readonly ILogger<DapperQueryExecutor> _logger;
    
    public DapperQueryExecutor(ILogger<DapperQueryExecutor> logger)
    {
        _logger = logger;
    }
    
    public async Task<IReadOnlyList<IDictionary<string, object?>>> ExecuteQueryAsync(
        CompiledQuery query,
        string connectionString,
        CancellationToken ct = default)
    {
        await using var conn = new MySqlConnection(connectionString);
        await conn.OpenAsync(ct);
        
        _logger.LogDebug("Executing SELECT on {Table}: {Sql}", query.TableName, query.Sql);
        
        // Dapper returns IDictionary<string, object> for dynamic mapping
        var results = await conn.QueryAsync(
            query.Sql,
            query.Parameters.Count > 0 ? query.Parameters : null,
            commandType: CommandType.Text);
        
        return results
            .Select(row => (IDictionary<string, object?>)
                ((IDictionary<string, object>)row)
                .ToDictionary(k => k.Key, k => (object?)k.Value))
            .ToList()
            .AsReadOnly();
    }
    
    public async Task<long> ExecuteCountAsync(
        CompiledQuery query,
        string connectionString,
        CancellationToken ct = default)
    {
        // Wrap existing query as subquery for COUNT — avoids recompilation
        var countSql = $"SELECT COUNT(*) FROM ({query.Sql}) AS _count_wrapper";
        
        await using var conn = new MySqlConnection(connectionString);
        await conn.OpenAsync(ct);
        
        return await conn.ExecuteScalarAsync<long>(
            countSql,
            query.Parameters.Count > 0 ? query.Parameters : null);
    }
}