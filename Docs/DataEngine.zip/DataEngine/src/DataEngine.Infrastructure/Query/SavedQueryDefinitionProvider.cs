// DataEngine.Infrastructure/Query/SavedQueryDefinitionProvider.cs
namespace DataEngine.Infrastructure.Query;

/// <summary>
/// Resolves named query definitions from the 'de_query_definitions' table.
/// Definitions are stored as JSON (serialized QueryRequest) and cached in memory.
///
/// A saved query definition lets consumers execute pre-approved queries by key:
///   engine.QueryByDefinitionAsync("active-npd-projects")
///
/// instead of constructing QueryRequest objects in application code.
/// </summary>
public sealed class SavedQueryDefinitionProvider : ISavedQueryProvider
{
    public bool IsAvailable => true;

    private readonly ConcurrentDictionary<string, QueryRequest?> _cache = new(
        StringComparer.OrdinalIgnoreCase);

    private readonly IConnectionFactory _connectionFactory;
    private readonly ILogger<SavedQueryDefinitionProvider> _logger;

    private const string LoadSql = """
        SELECT table_name, query_json
        FROM de_query_definitions
        WHERE definition_key = @Key
          AND is_active = 1
        LIMIT 1;
        """;

    public SavedQueryDefinitionProvider(
        IConnectionFactory connectionFactory,
        ILogger<SavedQueryDefinitionProvider> logger)
    {
        _connectionFactory = connectionFactory;
        _logger = logger;
    }

    public async ValueTask<QueryRequest?> ResolveAsync(
        string definitionKey,
        CancellationToken ct = default)
    {
        // Check cache first — definitions don't change often
        if (_cache.TryGetValue(definitionKey, out var cached))
            return cached;

        var definition = await LoadFromDbAsync(definitionKey, ct);
        _cache[definitionKey] = definition;
        return definition;
    }

    private async Task<QueryRequest?> LoadFromDbAsync(
        string definitionKey,
        CancellationToken ct)
    {
        try
        {
            await using var conn = _connectionFactory.CreateConnection();
            await conn.OpenAsync(ct);

            var row = await conn.QueryFirstOrDefaultAsync<DefinitionRow>(
                LoadSql, new { Key = definitionKey });

            if (row is null)
            {
                _logger.LogWarning(
                    "Query definition '{Key}' not found or inactive.", definitionKey);
                return null;
            }

            // Deserialize the stored JSON back to QueryRequest
            // The stored JSON contains all query config except Table (stored separately)
            var partialRequest = JsonSerializer.Deserialize<QueryRequestJson>(row.QueryJson,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            if (partialRequest is null)
            {
                _logger.LogError(
                    "Failed to deserialize query definition '{Key}'.", definitionKey);
                return null;
            }

            return new QueryRequest
            {
                Table = row.TableName,
                Columns = partialRequest.Columns,
                Filters = partialRequest.Filters,
                Sort = partialRequest.Sort,
                Pagination = partialRequest.Pagination,
                IncludeCount = partialRequest.IncludeCount
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Error loading query definition '{Key}'.", definitionKey);
            return null;
        }
    }

    // Internal DTO for JSON deserialization — matches the stored query_json schema
    private sealed class QueryRequestJson
    {
        public IReadOnlyList<string>? Columns { get; set; }
        public IReadOnlyList<FilterClause>? Filters { get; set; }
        public IReadOnlyList<SortClause>? Sort { get; set; }
        public PaginationClause? Pagination { get; set; }
        public bool IncludeCount { get; set; }
    }

    private sealed class DefinitionRow
    {
        public string TableName { get; set; } = default!;
        public string QueryJson { get; set; } = default!;
    }
}