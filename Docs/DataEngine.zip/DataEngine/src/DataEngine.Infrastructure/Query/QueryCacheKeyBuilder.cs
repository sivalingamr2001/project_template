// DataEngine.Infrastructure/Query/QueryCacheKeyBuilder.cs
namespace DataEngine.Infrastructure.Query;

public static class QueryCacheKeyBuilder
{
    /// <summary>
    /// Deterministic cache key for compiled queries.
    /// Only structural elements — NOT values (values are parameters, never in cache key).
    /// </summary>
    public static string BuildSelectKey(QueryRequest req)
    {
        var sb = new StringBuilder(128);
        sb.Append($"SEL:{req.Database}:{req.Table}");
        
        if (req.Columns?.Count > 0)
            sb.Append($"|cols:{string.Join(",", req.Columns.OrderBy(c => c))}");
        
        if (req.Filters?.Count > 0)
            sb.Append($"|filters:{string.Join(",", req.Filters.Select(f => $"{f.Column}{f.Operator}"))}");
        
        if (req.Sort?.Count > 0)
            sb.Append($"|sort:{string.Join(",", req.Sort.Select(s => $"{s.Column}{s.Direction}"))}");
        
        if (req.Joins?.Count > 0)
            sb.Append($"|joins:{string.Join(",", req.Joins.Select(j => $"{j.Table}:{j.Type}"))}");
        
        if (req.Pagination is not null)
            sb.Append("|paged");
        
        return sb.ToString();
    }
}