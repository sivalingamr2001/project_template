// DataEngine.Infrastructure/Query/MySqlQueryCompiler.cs
namespace DataEngine.Infrastructure.Query;

/// <summary>
/// Compiles validated requests into parameterized SQL.
/// All SQL output uses backtick-quoted identifiers to handle reserved words.
/// Parameters are @p_columnname_index to avoid collisions.
/// </summary>
public sealed class MySqlQueryCompiler : IQueryCompiler
{
    private readonly TableGuard _tableGuard;
    private readonly ColumnGuard _columnGuard;
    
    public MySqlQueryCompiler(TableGuard tableGuard, ColumnGuard columnGuard)
    {
        _tableGuard = tableGuard;
        _columnGuard = columnGuard;
    }
    
    public CompiledQuery CompileSelect(QueryRequest request, TableMetadata schema)
    {
        var sb = new StringBuilder(256);
        var parameters = new Dictionary<string, object?>(StringComparer.Ordinal);
        
        // SELECT clause
        sb.Append("SELECT ");
        AppendProjection(sb, request.Columns, schema);
        
        // FROM clause
        sb.Append($"\nFROM `{schema.DatabaseName}`.`{schema.TableName}`");
        
        // JOIN clauses
        if (request.Joins?.Count > 0)
            AppendJoins(sb, request.Joins, schema);
        
        // WHERE clause
        if (request.Filters?.Count > 0)
            AppendWhere(sb, request.Filters, schema, parameters);
        
        // ORDER BY clause
        if (request.Sort?.Count > 0)
            AppendOrderBy(sb, request.Sort, schema);
        
        // LIMIT / OFFSET
        if (request.Pagination is not null)
            AppendPagination(sb, request.Pagination, parameters);
        
        return new CompiledQuery
        {
            Sql = sb.ToString(),
            Parameters = parameters,
            TableName = schema.TableName
        };
    }
    
    public CompiledQuery CompileInsert(InsertRequest request, TableMetadata schema)
    {
        var writableValues = request.Values
            .Where(kv => schema.HasColumn(kv.Key) &&
                         !schema.GetColumn(kv.Key).IsAutoIncrement)
            .ToList();
        
        if (writableValues.Count == 0)
            throw new DataEngineException("No writable columns found in insert request.");
        
        var columns = writableValues.Select(kv => $"`{kv.Key}`");
        var paramNames = writableValues.Select((kv, i) => $"@p_{i}");
        var parameters = writableValues
            .Select((kv, i) => ($"p_{i}", kv.Value))
            .ToDictionary(t => t.Item1, t => t.Value);
        
        var sql = $"""
            INSERT INTO `{schema.DatabaseName}`.`{schema.TableName}`
            ({string.Join(", ", columns)})
            VALUES ({string.Join(", ", paramNames)});
            SELECT LAST_INSERT_ID();
            """;
        
        return new CompiledQuery { Sql = sql, Parameters = parameters, TableName = schema.TableName };
    }
    
    public CompiledQuery CompileUpdate(UpdateRequest request, TableMetadata schema)
    {
        var sb = new StringBuilder(256);
        var parameters = new Dictionary<string, object?>(StringComparer.Ordinal);
        
        sb.Append($"UPDATE `{schema.DatabaseName}`.`{schema.TableName}` SET ");
        
        var setClauses = new List<string>();
        int paramIndex = 0;
        foreach (var (key, value) in request.Values)
        {
            _columnGuard.AssertWritable(key, schema);
            var paramName = $"p_set_{paramIndex++}";
            setClauses.Add($"`{key}` = @{paramName}");
            parameters[paramName] = value;
        }
        sb.Append(string.Join(", ", setClauses));
        
        AppendWhere(sb, request.Filters, schema, parameters, startIndex: paramIndex);
        
        return new CompiledQuery { Sql = sb.ToString(), Parameters = parameters, TableName = schema.TableName };
    }
    
    public CompiledQuery CompileDelete(DeleteRequest request, TableMetadata schema)
    {
        var sb = new StringBuilder(128);
        var parameters = new Dictionary<string, object?>(StringComparer.Ordinal);
        
        sb.Append($"DELETE FROM `{schema.DatabaseName}`.`{schema.TableName}`");
        AppendWhere(sb, request.Filters, schema, parameters);
        
        return new CompiledQuery { Sql = sb.ToString(), Parameters = parameters, TableName = schema.TableName };
    }
    
    public CompiledQuery CompileBulkInsert(BulkInsertRequest request, TableMetadata schema)
    {
        if (request.Rows.Count == 0)
            throw new DataEngineException("BulkInsert requires at least one row.");
        
        // Derive column set from first row (all rows must share same columns)
        var firstRow = request.Rows[0];
        var writableKeys = firstRow.Keys
            .Where(k => schema.HasColumn(k) && !schema.GetColumn(k).IsAutoIncrement)
            .ToList();
        
        var columns = string.Join(", ", writableKeys.Select(k => $"`{k}`"));
        var parameters = new Dictionary<string, object?>(StringComparer.Ordinal);
        var valueSets = new List<string>(request.Rows.Count);
        
        for (int rowIdx = 0; rowIdx < request.Rows.Count; rowIdx++)
        {
            var paramNames = writableKeys
                .Select((k, colIdx) =>
                {
                    var pName = $"r{rowIdx}_c{colIdx}";
                    parameters[pName] = request.Rows[rowIdx].TryGetValue(k, out var v) ? v : null;
                    return $"@{pName}";
                });
            valueSets.Add($"({string.Join(", ", paramNames)})");
        }
        
        var verb = request.OnConflict switch
        {
            ConflictResolution.Ignore => "INSERT IGNORE",
            ConflictResolution.Replace => "REPLACE",
            _ => "INSERT"
        };
        
        var sql = $"""
            {verb} INTO `{schema.DatabaseName}`.`{schema.TableName}`
            ({columns})
            VALUES {string.Join(",\n", valueSets)};
            """;
        
        return new CompiledQuery { Sql = sql, Parameters = parameters, TableName = schema.TableName };
    }
    
    // ── Private helpers ────────────────────────────────────────────────
    
    private void AppendProjection(StringBuilder sb, IReadOnlyList<string>? columns, TableMetadata schema)
    {
        if (columns is null || columns.Count == 0)
        {
            // SELECT all — use explicit column list (no SELECT *)
            sb.Append(string.Join(", ",
                schema.Columns.Values
                    .OrderBy(c => c.OrdinalPosition)
                    .Select(c => $"`{schema.TableName}`.`{c.ColumnName}`")));
        }
        else
        {
            foreach (var col in columns)
                _columnGuard.AssertExists(col, schema);
            
            sb.Append(string.Join(", ", columns.Select(c => $"`{schema.TableName}`.`{c}`")));
        }
    }
    
    private void AppendWhere(
        StringBuilder sb,
        IReadOnlyList<FilterClause> filters,
        TableMetadata schema,
        Dictionary<string, object?> parameters,
        int startIndex = 0)
    {
        sb.Append("\nWHERE ");
        int idx = startIndex;
        
        for (int i = 0; i < filters.Count; i++)
        {
            var filter = filters[i];
            _columnGuard.AssertExists(filter.Column, schema);
            
            if (i > 0)
                sb.Append(filter.Logic == LogicalOperator.Or ? " OR " : " AND ");
            
            AppendFilterExpression(sb, filter, parameters, ref idx);
        }
    }
    
    private static void AppendFilterExpression(
        StringBuilder sb,
        FilterClause filter,
        Dictionary<string, object?> parameters,
        ref int idx)
    {
        var col = $"`{filter.Column}`";
        
        switch (filter.Operator)
        {
            case FilterOperator.IsNull:
                sb.Append($"{col} IS NULL");
                break;
            case FilterOperator.IsNotNull:
                sb.Append($"{col} IS NOT NULL");
                break;
            case FilterOperator.In:
            case FilterOperator.NotIn:
            {
                var values = (IEnumerable<object?>)filter.Value!;
                var paramNames = new List<string>();
                foreach (var v in values)
                {
                    var pName = $"p_f_{idx++}";
                    parameters[pName] = v;
                    paramNames.Add($"@{pName}");
                }
                var not = filter.Operator == FilterOperator.NotIn ? "NOT " : "";
                sb.Append($"{col} {not}IN ({string.Join(", ", paramNames)})");
                break;
            }
            case FilterOperator.Between:
            {
                var between = (object?[])filter.Value!;
                var p1 = $"p_f_{idx++}"; var p2 = $"p_f_{idx++}";
                parameters[p1] = between[0]; parameters[p2] = between[1];
                sb.Append($"{col} BETWEEN @{p1} AND @{p2}");
                break;
            }
            default:
            {
                var op = filter.Operator switch
                {
                    FilterOperator.Equals => "=",
                    FilterOperator.NotEquals => "<>",
                    FilterOperator.GreaterThan => ">",
                    FilterOperator.GreaterThanOrEqual => ">=",
                    FilterOperator.LessThan => "<",
                    FilterOperator.LessThanOrEqual => "<=",
                    FilterOperator.Like => "LIKE",
                    FilterOperator.NotLike => "NOT LIKE",
                    _ => throw new DataEngineException($"Unknown operator: {filter.Operator}")
                };
                var pName = $"p_f_{idx++}";
                parameters[pName] = filter.Value;
                sb.Append($"{col} {op} @{pName}");
                break;
            }
        }
    }
    
    private void AppendOrderBy(StringBuilder sb, IReadOnlyList<SortClause> sort, TableMetadata schema)
    {
        sb.Append("\nORDER BY ");
        sb.Append(string.Join(", ", sort.Select(s =>
        {
            _columnGuard.AssertExists(s.Column, schema);
            return $"`{s.Column}` {(s.Direction == SortDirection.Descending ? "DESC" : "ASC")}";
        })));
    }
    
    private static void AppendPagination(
        StringBuilder sb, PaginationClause pagination,
        Dictionary<string, object?> parameters)
    {
        parameters["_limit"] = pagination.PageSize;
        parameters["_offset"] = pagination.Offset;
        sb.Append("\nLIMIT @_limit OFFSET @_offset");
    }
    
    private static void AppendJoins(StringBuilder sb, IReadOnlyList<JoinClause> joins, TableMetadata schema)
    {
        foreach (var join in joins)
        {
            var joinType = join.Type switch
            {
                JoinType.Left => "LEFT JOIN",
                JoinType.Right => "RIGHT JOIN",
                _ => "INNER JOIN"
            };
            var alias = join.Alias is not null ? $" AS `{join.Alias}`" : "";
            sb.Append($"\n{joinType} `{join.Table}`{alias} ON `{schema.TableName}`.`{join.LeftColumn}` = `{join.Table}`.`{join.RightColumn}`");
        }
    }
}