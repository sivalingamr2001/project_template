// DataEngine.Infrastructure/Connection/MultiDatabaseRouter.cs
namespace DataEngine.Infrastructure.Connection;

/// <summary>
/// Routes requests to the correct database connection.
/// Resolves the effective database name from a request
/// (explicit Database field → default database fallback).
///
/// This is a thin coordination layer — it does NOT open connections,
/// it only resolves which connection string to use.
/// </summary>
public sealed class MultiDatabaseRouter
{
    private readonly MySqlConnectionFactory _factory;

    public MultiDatabaseRouter(MySqlConnectionFactory factory)
    {
        _factory = factory;
    }

    /// <summary>
    /// Resolve the effective database name for a request.
    /// If the request specifies a database, validate it's registered.
    /// Otherwise, return the default database name.
    /// </summary>
    public string ResolveDatabase(string? requestedDatabase)
    {
        if (string.IsNullOrWhiteSpace(requestedDatabase))
            return _factory.GetDefaultDatabase();

        // Validate it's a known database — GetConnectionString throws if not
        _ = _factory.GetConnectionString(requestedDatabase);
        return requestedDatabase;
    }

    public string ResolveConnectionString(string? requestedDatabase) =>
        _factory.GetConnectionString(ResolveDatabase(requestedDatabase));
}