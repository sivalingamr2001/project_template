// DataEngine.Infrastructure/Connection/MySqlConnectionFactory.cs
namespace DataEngine.Infrastructure.Connection;

/// <summary>
/// Creates MySqlConnection instances for the default database
/// and any registered additional databases.
///
/// Design decision: connections are created on demand, not pooled here.
/// MySqlConnector manages the underlying connection pool via the connection string.
/// Never cache open connections — always create, use, dispose.
/// </summary>
public sealed class MySqlConnectionFactory : IConnectionFactory
{
    // Key: alias (or "default"), Value: resolved connection string
    private readonly Dictionary<string, string> _connectionStrings;
    private readonly string _defaultDatabase;

    public MySqlConnectionFactory(
        IConfiguration configuration,
        DataEngineOptions options)
    {
        _connectionStrings = new Dictionary<string, string>(
            StringComparer.OrdinalIgnoreCase);

        // Resolve default connection string
        var defaultCs = configuration.GetConnectionString(
            options.DefaultConnectionStringName);

        if (string.IsNullOrWhiteSpace(defaultCs))
            throw new ConnectionException(
                $"Connection string '{options.DefaultConnectionStringName}' not found " +
                $"in configuration. Add ConnectionStrings:{options.DefaultConnectionStringName} " +
                $"to your appsettings.json.");

        _connectionStrings["default"] = defaultCs;
        _defaultDatabase = ExtractDatabaseName(defaultCs);

        // Register additional named databases
        foreach (var (alias, csName) in options.AdditionalDatabases)
        {
            var cs = configuration.GetConnectionString(csName);
            if (string.IsNullOrWhiteSpace(cs))
                throw new ConnectionException(
                    $"Additional database '{alias}' references connection string '{csName}' " +
                    $"which was not found in configuration.");

            _connectionStrings[alias] = cs;
        }
    }

    public MySqlConnection CreateConnection(string? database = null)
    {
        var cs = GetConnectionString(database);
        return new MySqlConnection(cs);
    }

    public string GetConnectionString(string? database = null)
    {
        if (string.IsNullOrWhiteSpace(database) ||
            database.Equals(_defaultDatabase, StringComparison.OrdinalIgnoreCase))
            return _connectionStrings["default"];

        // Try alias match first, then database name match
        if (_connectionStrings.TryGetValue(database, out var cs))
            return cs;

        // Search by database name in connection strings
        foreach (var (_, connStr) in _connectionStrings)
        {
            if (ExtractDatabaseName(connStr)
                    .Equals(database, StringComparison.OrdinalIgnoreCase))
                return connStr;
        }

        throw new ConnectionException(
            $"No connection string found for database '{database}'. " +
            $"Registered aliases: {string.Join(", ", _connectionStrings.Keys)}. " +
            $"Register additional databases via DataEngineOptions.AdditionalDatabases.");
    }

    public IReadOnlyList<string> GetRegisteredDatabases()
    {
        return _connectionStrings.Keys.ToList().AsReadOnly();
    }

    public string GetDefaultDatabase() => _defaultDatabase;

    private static string ExtractDatabaseName(string connectionString)
    {
        // Parse Database= or Initial Catalog= from connection string
        var builder = new MySqlConnectionStringBuilder(connectionString);
        return builder.Database
            ?? throw new ConnectionException(
                "Connection string must contain a 'Database' parameter.");
    }
}