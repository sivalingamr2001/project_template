// DataEngine.Infrastructure/Extensions/OptionalTablesDetector.cs
namespace DataEngine.Infrastructure.Extensions;

/// <summary>
/// Detects which optional DataEngine extension tables exist at runtime.
/// Result is cached for the lifetime of the application.
///
/// Called once during DI setup via a singleton AvailableExtensions instance.
/// </summary>
public sealed class OptionalTablesDetector
{
    public sealed record AvailableExtensions(
        bool HasFieldMappings,
        bool HasQueryDefinitions,
        bool HasTransactionAudit,
        bool HasProceduresTable)
    {
        public static AvailableExtensions None => new(false, false, false, false);
    }

    private readonly IConnectionFactory _connectionFactory;
    private readonly ILogger<OptionalTablesDetector> _logger;

    public OptionalTablesDetector(
        IConnectionFactory connectionFactory,
        ILogger<OptionalTablesDetector> logger)
    {
        _connectionFactory = connectionFactory;
        _logger = logger;
    }

    public async Task<AvailableExtensions> DetectAsync(
        CancellationToken ct = default)
    {
        const string sql = """
            SELECT TABLE_NAME
            FROM INFORMATION_SCHEMA.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME IN (
                'de_field_mappings',
                'de_query_definitions',
                'de_transaction_audit',
                'de_procedures'
              );
            """;

        try
        {
            await using var conn = _connectionFactory.CreateConnection();
            await conn.OpenAsync(ct);

            var tables = (await conn.QueryAsync<string>(sql))
                .ToHashSet(StringComparer.OrdinalIgnoreCase);

            var result = new AvailableExtensions(
                tables.Contains("de_field_mappings"),
                tables.Contains("de_query_definitions"),
                tables.Contains("de_transaction_audit"),
                tables.Contains("de_procedures"));

            _logger.LogInformation(
                "Optional extension tables detected — " +
                "FieldMappings:{FM} QueryDefs:{QD} Audit:{AU} Procedures:{PR}",
                result.HasFieldMappings,
                result.HasQueryDefinitions,
                result.HasTransactionAudit,
                result.HasProceduresTable);

            return result;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex,
                "Could not detect optional extension tables. " +
                "Defaulting to no optional features.");
            return AvailableExtensions.None;
        }
    }
}