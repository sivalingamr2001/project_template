// DataEngine.Application/QueryOrchestrator.cs
namespace DataEngine.Application;

/// <summary>
/// Orchestrates the full read pipeline:
/// Security → Schema → FieldMapping → Compile → Cache → Execute → Un-map
///
/// This class owns the read side of DataEngine.
/// All filtering, sorting, pagination, joins, projections flow through here.
/// </summary>
public sealed class QueryOrchestrator
{
    private readonly ISchemaProvider _schemaProvider;
    private readonly IQueryCompiler _compiler;
    private readonly IQueryExecutor _executor;
    private readonly IFieldMapperProvider _fieldMapper;
    private readonly ISavedQueryProvider _savedQueryProvider;
    private readonly MultiDatabaseRouter _router;
    private readonly TableGuard _tableGuard;
    private readonly DataEngineOptions _options;

    // Compiled query cache — keyed by structural shape, not values
    private readonly ConcurrentDictionary<string, CompiledQuery> _queryCache = new();

    private readonly ILogger<QueryOrchestrator> _logger;

    public QueryOrchestrator(
        ISchemaProvider schemaProvider,
        IQueryCompiler compiler,
        IQueryExecutor executor,
        IFieldMapperProvider fieldMapper,
        ISavedQueryProvider savedQueryProvider,
        MultiDatabaseRouter router,
        TableGuard tableGuard,
        DataEngineOptions options,
        ILogger<QueryOrchestrator> logger)
    {
        _schemaProvider = schemaProvider;
        _compiler = compiler;
        _executor = executor;
        _fieldMapper = fieldMapper;
        _savedQueryProvider = savedQueryProvider;
        _router = router;
        _tableGuard = tableGuard;
        _options = options;
        _logger = logger;
    }

    public async Task<QueryResponse> ExecuteAsync(
        QueryRequest request,
        CancellationToken ct)
    {
        var sw = Stopwatch.StartNew();

        // [1] Resolve database
        var database = _router.ResolveDatabase(request.Database);

        // [2] Security: reject system databases
        _tableGuard.AssertAllowed(request.Table, database);

        // [3] Schema resolution
        var snapshot = await _schemaProvider.EnsureSnapshotAsync(database, ct);
        var tableSchema = snapshot.GetTable(request.Table);

        // [4] Field mapping: translate incoming aliases to real column names
        var mappedRequest = await ApplyInboundMappingAsync(request, tableSchema, ct);

        // [5] Enforce page size cap
        mappedRequest = EnforcePaginationLimits(mappedRequest);

        // [6] Compile or retrieve from cache
        var cacheKey = QueryCacheKeyBuilder.BuildSelectKey(mappedRequest);
        var compiled = _queryCache.GetOrAdd(cacheKey,
            _ => _compiler.CompileSelect(mappedRequest, tableSchema));

        // IMPORTANT: update parameters on cached query — structure is cached, values are not
        compiled = compiled with { Parameters = ExtractParameters(mappedRequest, tableSchema) };

        // [7] Execute
        var connString = _router.ResolveConnectionString(database);
        var rows = await _executor.ExecuteQueryAsync(compiled, connString, ct);

        // [8] Count (if requested)
        long? totalCount = null;
        if (request.IncludeCount)
        {
            var countQuery = compiled with
            {
                Sql = BuildCountSql(compiled.Sql)
            };
            totalCount = await _executor.ExecuteCountAsync(countQuery, connString, ct);
        }

        // [9] Apply outbound field mapping (column name → alias)
        var mappedRows = await ApplyOutboundMappingAsync(rows, request.Table, ct);

        sw.Stop();

        _logger.LogDebug(
            "Query on {Table}: {RowCount} rows in {Ms}ms",
            request.Table, rows.Count, sw.ElapsedMilliseconds);

        return new QueryResponse
        {
            Data = mappedRows,
            TotalCount = totalCount,
            Pagination = request.Pagination,
            Success = true,
            ExecutionTime = sw.Elapsed
        };
    }

    public async Task<QueryResponse> ExecuteByDefinitionAsync(
        string definitionKey,
        IReadOnlyDictionary<string, object?>? parameters,
        CancellationToken ct)
    {
        if (!_savedQueryProvider.IsAvailable)
            throw new DataEngineException(
                "Saved query definitions are not enabled. " +
                "Set DataEngineOptions.EnableSavedQueryDefinitions = true and " +
                "ensure the 'de_query_definitions' table exists.");

        var definition = await _savedQueryProvider.ResolveAsync(definitionKey, ct)
            ?? throw new DataEngineException(
                $"Query definition '{definitionKey}' was not found or is inactive.");

        // Merge runtime parameters into the saved filter values
        if (parameters?.Count > 0 && definition.Filters is not null)
        {
            definition = MergeParameters(definition, parameters);
        }

        return await ExecuteAsync(definition, ct);
    }

    // ── Private helpers ────────────────────────────────────────────────

    private async Task<QueryRequest> ApplyInboundMappingAsync(
        QueryRequest request,
        TableMetadata schema,
        CancellationToken ct)
    {
        if (!_fieldMapper.IsAvailable) return request;

        // Map column projections
        List<string>? mappedColumns = null;
        if (request.Columns?.Count > 0)
        {
            mappedColumns = new List<string>(request.Columns.Count);
            foreach (var col in request.Columns)
            {
                var resolved = await _fieldMapper.ResolveColumnAsync(schema.TableName, col, ct);
                mappedColumns.Add(resolved ?? col);
            }
        }

        // Map filter columns
        List<FilterClause>? mappedFilters = null;
        if (request.Filters?.Count > 0)
        {
            mappedFilters = new List<FilterClause>(request.Filters.Count);
            foreach (var f in request.Filters)
            {
                var resolved = await _fieldMapper.ResolveColumnAsync(schema.TableName, f.Column, ct);
                mappedFilters.Add(resolved is not null ? f with { Column = resolved } : f);
            }
        }

        // Map sort columns
        List<SortClause>? mappedSort = null;
        if (request.Sort?.Count > 0)
        {
            mappedSort = new List<SortClause>(request.Sort.Count);
            foreach (var s in request.Sort)
            {
                var resolved = await _fieldMapper.ResolveColumnAsync(schema.TableName, s.Column, ct);
                mappedSort.Add(resolved is not null ? s with { Column = resolved } : s);
            }
        }

        return request with
        {
            Columns = mappedColumns ?? request.Columns,
            Filters = mappedFilters ?? request.Filters,
            Sort = mappedSort ?? request.Sort
        };
    }

    private async Task<IReadOnlyList<IReadOnlyDictionary<string, object?>>> ApplyOutboundMappingAsync(
        IReadOnlyList<IDictionary<string, object?>> rows,
        string tableName,
        CancellationToken ct)
    {
        if (!_fieldMapper.IsAvailable || rows.Count == 0)
            return rows.Select(r => (IReadOnlyDictionary<string, object?>)
                new ReadOnlyDictionary<string, object?>(r)).ToList().AsReadOnly();

        var result = new List<IReadOnlyDictionary<string, object?>>(rows.Count);

        // Build alias map once for all rows (avoid per-row async calls)
        var aliasMap = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var key in rows[0].Keys)
        {
            var alias = await _fieldMapper.ResolveAliasAsync(tableName, key, ct);
            if (alias is not null && alias != key)
                aliasMap[key] = alias;
        }

        foreach (var row in rows)
        {
            if (aliasMap.Count == 0)
            {
                result.Add(new ReadOnlyDictionary<string, object?>(
                    new Dictionary<string, object?>(row)));
                continue;
            }

            var mapped = new Dictionary<string, object?>(row.Count);
            foreach (var (k, v) in row)
                mapped[aliasMap.TryGetValue(k, out var alias) ? alias : k] = v;

            result.Add(new ReadOnlyDictionary<string, object?>(mapped));
        }

        return result.AsReadOnly();
    }

    private QueryRequest EnforcePaginationLimits(QueryRequest request)
    {
        if (request.Pagination is null) return request;

        var pageSize = Math.Min(request.Pagination.PageSize, _options.MaxPageSize);
        if (pageSize == request.Pagination.PageSize) return request;

        _logger.LogWarning(
            "Requested page size {Requested} exceeds MaxPageSize {Max}. Capping.",
            request.Pagination.PageSize, _options.MaxPageSize);

        return request with
        {
            Pagination = request.Pagination with { PageSize = pageSize }
        };
    }

    // Re-extract parameter values from request for use with cached compiled SQL
    private static IReadOnlyDictionary<string, object?> ExtractParameters(
        QueryRequest request,
        TableMetadata schema)
    {
        // Parameters are always re-extracted from the live request
        // The cached query only provides the SQL template
        // This method mirrors what CompileSelect would produce for parameters only
        var parameters = new Dictionary<string, object?>(StringComparer.Ordinal);
        int idx = 0;

        if (request.Filters is not null)
        {
            foreach (var filter in request.Filters)
            {
                switch (filter.Operator)
                {
                    case FilterOperator.IsNull:
                    case FilterOperator.IsNotNull:
                        break;
                    case FilterOperator.In:
                    case FilterOperator.NotIn:
                        foreach (var v in (IEnumerable<object?>)filter.Value!)
                            parameters[$"p_f_{idx++}"] = v;
                        break;
                    case FilterOperator.Between:
                        var between = (object?[])filter.Value!;
                        parameters[$"p_f_{idx++}"] = between[0];
                        parameters[$"p_f_{idx++}"] = between[1];
                        break;
                    default:
                        parameters[$"p_f_{idx++}"] = filter.Value;
                        break;
                }
            }
        }

        if (request.Pagination is not null)
        {
            parameters["_limit"] = request.Pagination.PageSize;
            parameters["_offset"] = request.Pagination.Offset;
        }

        return parameters;
    }

    private static string BuildCountSql(string originalSql)
    {
        // Strip ORDER BY and LIMIT from count query — they're irrelevant and slow
        var orderByIdx = originalSql.LastIndexOf("\nORDER BY", StringComparison.OrdinalIgnoreCase);
        var limitIdx = originalSql.LastIndexOf("\nLIMIT", StringComparison.OrdinalIgnoreCase);

        var truncateAt = new[] { orderByIdx, limitIdx }
            .Where(i => i > 0)
            .DefaultIfEmpty(-1)
            .Min();

        var baseSql = truncateAt > 0
            ? originalSql[..truncateAt]
            : originalSql;

        return $"SELECT COUNT(*) FROM ({baseSql}) AS _de_count";
    }

    private static QueryRequest MergeParameters(
        QueryRequest definition,
        IReadOnlyDictionary<string, object?> runtimeParams)
    {
        if (definition.Filters is null) return definition;

        var merged = definition.Filters
            .Select(f => runtimeParams.TryGetValue(f.Column, out var val)
                ? f with { Value = val }
                : f)
            .ToList()
            .AsReadOnly();

        return definition with { Filters = merged };
    }
}