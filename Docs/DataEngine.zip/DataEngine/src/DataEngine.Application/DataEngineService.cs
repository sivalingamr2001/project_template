// DataEngine.Application/DataEngineService.cs
namespace DataEngine.Application;

/// <summary>
/// The primary implementation of IDataEngine.
/// Acts as a clean façade over the three orchestrators.
///
/// Design: this class contains NO business logic. It:
///   1. Routes calls to the correct orchestrator
///   2. Wraps exceptions in consistent DataEngineException
///   3. Provides the public API surface to consumers
///
/// Scoped lifetime: one instance per HTTP request / DI scope.
/// </summary>
public sealed class DataEngineService : IDataEngine
{
    private readonly QueryOrchestrator _queryOrchestrator;
    private readonly WriteOrchestrator _writeOrchestrator;
    private readonly ProcedureOrchestrator _procedureOrchestrator;
    private readonly ISchemaProvider _schemaProvider;
    private readonly ISchemaCache _schemaCache;
    private readonly MultiDatabaseRouter _router;
    private readonly ILogger<DataEngineService> _logger;

    public DataEngineService(
        QueryOrchestrator queryOrchestrator,
        WriteOrchestrator writeOrchestrator,
        ProcedureOrchestrator procedureOrchestrator,
        ISchemaProvider schemaProvider,
        ISchemaCache schemaCache,
        MultiDatabaseRouter router,
        ILogger<DataEngineService> logger)
    {
        _queryOrchestrator = queryOrchestrator;
        _writeOrchestrator = writeOrchestrator;
        _procedureOrchestrator = procedureOrchestrator;
        _schemaProvider = schemaProvider;
        _schemaCache = schemaCache;
        _router = router;
        _logger = logger;
    }

    // ── Reads ──────────────────────────────────────────────────────────

    public Task<QueryResponse> QueryAsync(
        QueryRequest request,
        CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(request);
        ArgumentException.ThrowIfNullOrWhiteSpace(request.Table);
        return _queryOrchestrator.ExecuteAsync(request, ct);
    }

    public Task<QueryResponse> QueryByDefinitionAsync(
        string definitionKey,
        IReadOnlyDictionary<string, object?>? parameters = null,
        CancellationToken ct = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(definitionKey);
        return _queryOrchestrator.ExecuteByDefinitionAsync(definitionKey, parameters, ct);
    }

    // ── Single-row writes ──────────────────────────────────────────────

    public Task<MutationResponse> InsertAsync(
        InsertRequest request,
        CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(request);
        ArgumentException.ThrowIfNullOrWhiteSpace(request.Table);
        if (request.Values is null || request.Values.Count == 0)
            throw new DataEngineException("InsertRequest.Values cannot be null or empty.");
        return _writeOrchestrator.InsertAsync(request, ct);
    }

    public Task<MutationResponse> UpdateAsync(
        UpdateRequest request,
        CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(request);
        ArgumentException.ThrowIfNullOrWhiteSpace(request.Table);
        return _writeOrchestrator.UpdateAsync(request, ct);
    }

    public Task<MutationResponse> DeleteAsync(
        DeleteRequest request,
        CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(request);
        ArgumentException.ThrowIfNullOrWhiteSpace(request.Table);
        return _writeOrchestrator.DeleteAsync(request, ct);
    }

    // ── Bulk operations ────────────────────────────────────────────────

    public Task<MutationResponse> BulkInsertAsync(
        BulkInsertRequest request,
        CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(request);
        ArgumentException.ThrowIfNullOrWhiteSpace(request.Table);
        return _writeOrchestrator.BulkInsertAsync(request, ct);
    }

    public Task<MutationResponse> BulkUpdateAsync(
        BulkUpdateRequest request,
        CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(request);
        ArgumentException.ThrowIfNullOrWhiteSpace(request.Table);
        return _writeOrchestrator.BulkUpdateAsync(request, ct);
    }

    // ── Transaction scope ──────────────────────────────────────────────

    public Task<TransactionResponse> ExecuteTransactionAsync(
        TransactionRequest request,
        CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(request);
        if (request.Operations is null || request.Operations.Count == 0)
            throw new DataEngineException(
                "TransactionRequest must contain at least one operation.");
        return _writeOrchestrator.ExecuteTransactionAsync(request, ct);
    }

    // ── Stored procedures ──────────────────────────────────────────────

    public Task<ProcedureResponse> ExecuteProcedureAsync(
        ProcedureRequest request,
        CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(request);
        ArgumentException.ThrowIfNullOrWhiteSpace(request.ProcedureName);
        return _procedureOrchestrator.ExecuteAsync(request, ct);
    }

    // ── Schema operations ──────────────────────────────────────────────

    public async Task<SchemaResponse> GetSchemaAsync(
        string tableName,
        string? database = null,
        CancellationToken ct = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(tableName);

        var resolvedDb = _router.ResolveDatabase(database);
        var snapshot = await _schemaProvider.EnsureSnapshotAsync(resolvedDb, ct);

        if (!snapshot.TableExists(tableName))
            return new SchemaResponse
            {
                Success = false,
                Error = $"Table '{tableName}' not found in database '{resolvedDb}'."
            };

        var table = snapshot.GetTable(tableName);

        return new SchemaResponse
        {
            Success = true,
            TableName = table.TableName,
            DatabaseName = table.DatabaseName,
            Columns = table.Columns.Values
                .OrderBy(c => c.OrdinalPosition)
                .Select(c => new ColumnInfo
                {
                    Name = c.ColumnName,
                    DataType = c.DataType,
                    IsNullable = c.IsNullable,
                    IsAutoIncrement = c.IsAutoIncrement,
                    IsPrimaryKey = c.IsPrimaryKey,
                    MaxLength = c.CharacterMaxLength,
                    DefaultValue = c.ColumnDefault
                })
                .ToList()
                .AsReadOnly(),
            PrimaryKeys = table.PrimaryKeys,
            CachedAt = table.CachedAt
        };
    }

    public async Task InvalidateSchemaAsync(
        string? tableName = null,
        string? database = null,
        CancellationToken ct = default)
    {
        var resolvedDb = _router.ResolveDatabase(database);

        if (tableName is not null)
        {
            // Invalidate entire database snapshot — schema cache stores per-database,
            // not per-table. A table change invalidates the whole DB snapshot.
            _logger.LogInformation(
                "Schema invalidation requested for table '{Table}' in '{Database}'. " +
                "Invalidating entire database snapshot.",
                tableName, resolvedDb);
        }

        _schemaCache.Invalidate(resolvedDb);

        // Immediately reload if invalidating for a specific reason
        // (prevents cold-start latency on next request)
        await _schemaProvider.LoadSchemaAsync(resolvedDb, ct);

        _logger.LogInformation(
            "Schema invalidated and reloaded for '{Database}'.", resolvedDb);
    }
}