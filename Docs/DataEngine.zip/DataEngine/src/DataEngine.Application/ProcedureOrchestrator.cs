// DataEngine.Application/ProcedureOrchestrator.cs
namespace DataEngine.Application;

/// <summary>
/// Orchestrates stored procedure execution.
/// Routes to Dapper (reads) or ADO.NET (writes) based on ProcedureType.
/// Validates procedure names against injection patterns before executing.
/// </summary>
public sealed class ProcedureOrchestrator
{
    private readonly IProcedureExecutor _executor;
    private readonly MultiDatabaseRouter _router;
    private readonly DataEngineOptions _options;
    private readonly TableGuard _tableGuard;
    private readonly ILogger<ProcedureOrchestrator> _logger;

    // Characters that are never valid in a stored procedure name
    private static readonly char[] InvalidProcNameChars = [';', ' ', '\'', '"', '`', '-', '\n', '\r'];

    public ProcedureOrchestrator(
        IProcedureExecutor executor,
        MultiDatabaseRouter router,
        DataEngineOptions options,
        TableGuard tableGuard,
        ILogger<ProcedureOrchestrator> logger)
    {
        _executor = executor;
        _router = router;
        _options = options;
        _tableGuard = tableGuard;
        _logger = logger;
    }

    public async Task<ProcedureResponse> ExecuteAsync(
        ProcedureRequest request,
        CancellationToken ct)
    {
        // Feature gate
        if (!_options.AllowStoredProcedures)
            throw new DataEngineException(
                "Stored procedure execution is disabled. " +
                "Set DataEngineOptions.AllowStoredProcedures = true to enable.");

        // Validate procedure name — no injection via proc name
        ValidateProcedureName(request.ProcedureName);

        var database = _router.ResolveDatabase(request.Database);
        var connString = _router.ResolveConnectionString(database);

        // Block access to system-level procedures
        _tableGuard.AssertAllowed(request.ProcedureName, database);

        var sw = Stopwatch.StartNew();

        try
        {
            ProcedureResult result;

            if (request.Type == ProcedureType.Read)
            {
                _logger.LogDebug("Executing READ procedure '{Proc}' on '{Database}'",
                    request.ProcedureName, database);
                result = await _executor.ExecuteReadAsync(request, connString, ct);
            }
            else
            {
                _logger.LogDebug("Executing WRITE procedure '{Proc}' on '{Database}'",
                    request.ProcedureName, database);
                result = await _executor.ExecuteWriteAsync(request, connString, ct);
            }

            sw.Stop();

            _logger.LogInformation(
                "Procedure '{Proc}': {Success} in {Ms}ms",
                request.ProcedureName,
                result.Success ? "success" : "failed",
                sw.ElapsedMilliseconds);

            return new ProcedureResponse
            {
                Success = result.Success,
                ResultSets = result.ResultSets,
                OutputParameters = result.OutputParameters,
                AffectedRows = result.AffectedRows,
                Error = result.Error,
                ExecutionTime = sw.Elapsed
            };
        }
        catch (MySqlException ex) when (ex.Number == 1305)
        {
            // MySQL error 1305 = PROCEDURE does not exist
            sw.Stop();
            throw new ProcedureNotFoundException(request.ProcedureName, database);
        }
        catch (Exception ex)
        {
            sw.Stop();
            _logger.LogError(ex, "Procedure '{Proc}' failed after {Ms}ms",
                request.ProcedureName, sw.ElapsedMilliseconds);

            return new ProcedureResponse
            {
                Success = false,
                Error = ex.Message,
                ExecutionTime = sw.Elapsed
            };
        }
    }

    private static void ValidateProcedureName(string name)
    {
        if (string.IsNullOrWhiteSpace(name))
            throw new SecurityViolationException(
                "Procedure name cannot be empty.");

        if (name.IndexOfAny(InvalidProcNameChars) >= 0)
            throw new SecurityViolationException(
                $"Procedure name '{name}' contains invalid characters. " +
                $"Only alphanumeric characters, underscores, and dots are permitted.");

        if (name.Length > 256)
            throw new SecurityViolationException(
                "Procedure name exceeds maximum length of 256 characters.");
    }
}