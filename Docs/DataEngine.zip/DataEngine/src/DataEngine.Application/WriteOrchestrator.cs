// DataEngine.Application/WriteOrchestrator.cs
namespace DataEngine.Application;

/// <summary>
/// Orchestrates all write operations: INSERT, UPDATE, DELETE, BulkInsert, Transactions.
///
/// Pipeline for every write:
/// Security → Schema → FieldMapping → Validate → Compile → Execute → Audit
/// </summary>
public sealed class WriteOrchestrator
{
    private readonly ISchemaProvider _schemaProvider;
    private readonly IQueryCompiler _compiler;
    private readonly AdoNetWriteExecutor _writeExecutor;
    private readonly BulkWriteExecutor _bulkExecutor;
    private readonly IFieldMapperProvider _fieldMapper;
    private readonly IAuditWriter _auditWriter;
    private readonly MultiDatabaseRouter _router;
    private readonly TableGuard _tableGuard;
    private readonly ColumnGuard _columnGuard;
    private readonly DataEngineOptions _options;
    private readonly ILogger<WriteOrchestrator> _logger;

    public WriteOrchestrator(
        ISchemaProvider schemaProvider,
        IQueryCompiler compiler,
        AdoNetWriteExecutor writeExecutor,
        BulkWriteExecutor bulkExecutor,
        IFieldMapperProvider fieldMapper,
        IAuditWriter auditWriter,
        MultiDatabaseRouter router,
        TableGuard tableGuard,
        ColumnGuard columnGuard,
        DataEngineOptions options,
        ILogger<WriteOrchestrator> logger)
    {
        _schemaProvider = schemaProvider;
        _compiler = compiler;
        _writeExecutor = writeExecutor;
        _bulkExecutor = bulkExecutor;
        _fieldMapper = fieldMapper;
        _auditWriter = auditWriter;
        _router = router;
        _tableGuard = tableGuard;
        _columnGuard = columnGuard;
        _options = options;
        _logger = logger;
    }

    // ── INSERT ─────────────────────────────────────────────────────────

    public async Task<MutationResponse> InsertAsync(
        InsertRequest request,
        CancellationToken ct)
    {
        var sw = Stopwatch.StartNew();
        var database = _router.ResolveDatabase(request.Database);

        _tableGuard.AssertAllowed(request.Table, database);

        var snapshot = await _schemaProvider.EnsureSnapshotAsync(database, ct);
        var schema = snapshot.GetTable(request.Table);

        var mappedValues = await MapInboundValuesAsync(request.Values, schema, ct);
        ValidateWriteValues(mappedValues, schema, allowAutoIncrement: false);

        var mapped = request with { Values = mappedValues, Database = database };
        var compiled = _compiler.CompileInsert(mapped, schema);

        var connString = _router.ResolveConnectionString(database);
        var result = await _writeExecutor.ExecuteInsertAsync(compiled, connString, ct);

        sw.Stop();

        await WriteAuditAsync(new AuditEntry
        {
            Operation = "INSERT",
            TableName = request.Table,
            DatabaseName = database,
            RecordId = result.InsertedId.ToString(),
            NewValues = JsonSerializer.Serialize(request.Values),
            ExecutedBy = request.ExecutedBy,
            CorrelationId = request.CorrelationId
        }, ct);

        _logger.LogDebug("INSERT on {Table}: id={Id} in {Ms}ms",
            request.Table, result.InsertedId, sw.ElapsedMilliseconds);

        return new MutationResponse
        {
            Success = true,
            AffectedRows = result.AffectedRows,
            InsertedId = result.InsertedId,
            ExecutionTime = sw.Elapsed
        };
    }

    // ── UPDATE ─────────────────────────────────────────────────────────

    public async Task<MutationResponse> UpdateAsync(
        UpdateRequest request,
        CancellationToken ct)
    {
        var sw = Stopwatch.StartNew();

        // Hard guard — UPDATE with no filters is never allowed
        if (request.Filters is null || request.Filters.Count == 0)
            throw new DataEngineException(
                "UPDATE requires at least one filter clause. " +
                "Unfiltered updates are not permitted by DataEngine's safety policy.");

        var database = _router.ResolveDatabase(request.Database);
        _tableGuard.AssertAllowed(request.Table, database);

        var snapshot = await _schemaProvider.EnsureSnapshotAsync(database, ct);
        var schema = snapshot.GetTable(request.Table);

        var mappedValues = await MapInboundValuesAsync(request.Values, schema, ct);
        ValidateWriteValues(mappedValues, schema, allowAutoIncrement: false);

        var mapped = request with { Values = mappedValues, Database = database };
        var compiled = _compiler.CompileUpdate(mapped, schema);

        var connString = _router.ResolveConnectionString(database);
        int affected = await _writeExecutor.ExecuteNonQueryAsync(compiled, connString, ct);

        sw.Stop();

        await WriteAuditAsync(new AuditEntry
        {
            Operation = "UPDATE",
            TableName = request.Table,
            DatabaseName = database,
            NewValues = JsonSerializer.Serialize(request.Values),
            ExecutedBy = request.ExecutedBy,
            CorrelationId = request.CorrelationId
        }, ct);

        _logger.LogDebug("UPDATE on {Table}: {Rows} row(s) in {Ms}ms",
            request.Table, affected, sw.ElapsedMilliseconds);

        return new MutationResponse
        {
            Success = true,
            AffectedRows = affected,
            ExecutionTime = sw.Elapsed
        };
    }

    // ── DELETE ─────────────────────────────────────────────────────────

    public async Task<MutationResponse> DeleteAsync(
        DeleteRequest request,
        CancellationToken ct)
    {
        var sw = Stopwatch.StartNew();

        // Hard guard — DELETE with no filters is never allowed
        if (request.Filters is null || request.Filters.Count == 0)
            throw new DataEngineException(
                "DELETE requires at least one filter clause. " +
                "Unfiltered deletes are not permitted by DataEngine's safety policy.");

        var database = _router.ResolveDatabase(request.Database);
        _tableGuard.AssertAllowed(request.Table, database);

        var snapshot = await _schemaProvider.EnsureSnapshotAsync(database, ct);
        var schema = snapshot.GetTable(request.Table);

        var compiled = _compiler.CompileDelete(request with { Database = database }, schema);
        var connString = _router.ResolveConnectionString(database);
        int affected = await _writeExecutor.ExecuteNonQueryAsync(compiled, connString, ct);

        sw.Stop();

        await WriteAuditAsync(new AuditEntry
        {
            Operation = "DELETE",
            TableName = request.Table,
            DatabaseName = database,
            ExecutedBy = request.ExecutedBy,
            CorrelationId = request.CorrelationId
        }, ct);

        _logger.LogDebug("DELETE on {Table}: {Rows} row(s) in {Ms}ms",
            request.Table, affected, sw.ElapsedMilliseconds);

        return new MutationResponse
        {
            Success = true,
            AffectedRows = affected,
            ExecutionTime = sw.Elapsed
        };
    }

    // ── BULK INSERT ────────────────────────────────────────────────────

    public async Task<MutationResponse> BulkInsertAsync(
        BulkInsertRequest request,
        CancellationToken ct)
    {
        if (request.Rows.Count == 0)
            return new MutationResponse { Success = true, AffectedRows = 0 };

        var sw = Stopwatch.StartNew();
        var database = _router.ResolveDatabase(request.Database);
        _tableGuard.AssertAllowed(request.Table, database);

        var snapshot = await _schemaProvider.EnsureSnapshotAsync(database, ct);
        var schema = snapshot.GetTable(request.Table);

        // Split into batches
        int batchSize = request.BatchSize > 0
            ? request.BatchSize
            : _options.BulkInsertBatchSize;

        var batches = BulkWriteExecutor.SplitIntoBatches(request, batchSize);
        var connString = _router.ResolveConnectionString(database);

        // Compile each batch
        var compiledBatches = batches
            .Select(b => _compiler.CompileBulkInsert(b with { Database = database }, schema))
            .ToList()
            .AsReadOnly();

        var result = await _bulkExecutor.ExecuteBulkInsertAsync(compiledBatches, connString, ct);

        sw.Stop();

        _logger.LogInformation(
            "BulkInsert on {Table}: {Rows} rows in {Batches} batches, {Ms}ms",
            request.Table, result.TotalAffectedRows,
            result.BatchesExecuted, sw.ElapsedMilliseconds);

        return new MutationResponse
        {
            Success = result.Success,
            AffectedRows = result.TotalAffectedRows,
            Error = result.Error,
            ExecutionTime = sw.Elapsed
        };
    }

    // ── BULK UPDATE ────────────────────────────────────────────────────

    public async Task<MutationResponse> BulkUpdateAsync(
        BulkUpdateRequest request,
        CancellationToken ct)
    {
        if (request.Rows.Count == 0)
            return new MutationResponse { Success = true, AffectedRows = 0 };

        var sw = Stopwatch.StartNew();
        var database = _router.ResolveDatabase(request.Database);
        _tableGuard.AssertAllowed(request.Table, database);

        var snapshot = await _schemaProvider.EnsureSnapshotAsync(database, ct);
        var schema = snapshot.GetTable(request.Table);
        var connString = _router.ResolveConnectionString(database);

        // Compile all update statements and execute in one transaction
        var compiled = request.Rows
            .Select(row => _compiler.CompileUpdate(
                new UpdateRequest
                {
                    Table = request.Table,
                    Database = database,
                    Values = row.Values,
                    Filters = row.Filters
                },
                schema))
            .ToList()
            .AsReadOnly();

        var txResult = await _writeExecutor.ExecuteTransactionAsync(
            compiled, connString, ct: ct);

        sw.Stop();

        return new MutationResponse
        {
            Success = txResult.Success,
            AffectedRows = txResult.TotalAffectedRows,
            Error = txResult.Error,
            ExecutionTime = sw.Elapsed
        };
    }

    // ── TRANSACTION ────────────────────────────────────────────────────

    public async Task<TransactionResponse> ExecuteTransactionAsync(
        TransactionRequest request,
        CancellationToken ct)
    {
        var sw = Stopwatch.StartNew();
        var database = _router.ResolveDatabase(request.Database);
        var connString = _router.ResolveConnectionString(database);

        // Sort by Order property
        var orderedOps = request.Operations.OrderBy(op => op.Order).ToList();

        // Pre-validate ALL operations before any DB call
        var compiledQueries = new List<CompiledQuery>(orderedOps.Count);

        foreach (var op in orderedOps)
        {
            _tableGuard.AssertAllowed(op.Table, database);

            var snapshot = await _schemaProvider.EnsureSnapshotAsync(database, ct);
            var schema = snapshot.GetTable(op.Table);

            CompiledQuery compiled = op.Type switch
            {
                OperationType.Insert when op.Values is not null =>
                    _compiler.CompileInsert(new InsertRequest
                    {
                        Table = op.Table, Database = database, Values = op.Values
                    }, schema),

                OperationType.Update when op.Values is not null && op.Filters?.Count > 0 =>
                    _compiler.CompileUpdate(new UpdateRequest
                    {
                        Table = op.Table, Database = database,
                        Values = op.Values, Filters = op.Filters
                    }, schema),

                OperationType.Delete when op.Filters?.Count > 0 =>
                    _compiler.CompileDelete(new DeleteRequest
                    {
                        Table = op.Table, Database = database, Filters = op.Filters
                    }, schema),

                OperationType.Update =>
                    throw new DataEngineException(
                        $"Transaction UPDATE on '{op.Table}' requires both Values and Filters."),

                OperationType.Delete =>
                    throw new DataEngineException(
                        $"Transaction DELETE on '{op.Table}' requires Filters."),

                _ => throw new DataEngineException(
                    $"Unknown operation type '{op.Type}' for table '{op.Table}'.")
            };

            compiledQueries.Add(compiled);
        }

        // Execute entire set as one DB transaction
        var txResult = await _writeExecutor.ExecuteTransactionAsync(
            compiledQueries, connString, request.IsolationLevel, ct);

        sw.Stop();

        // Audit all operations if transaction succeeded
        if (txResult.Success && _auditWriter.IsEnabled)
        {
            foreach (var op in orderedOps)
            {
                await WriteAuditAsync(new AuditEntry
                {
                    Operation = op.Type.ToString().ToUpperInvariant(),
                    TableName = op.Table,
                    DatabaseName = database,
                    NewValues = op.Values is not null
                        ? JsonSerializer.Serialize(op.Values)
                        : null,
                    ExecutedBy = request.ExecutedBy,
                    CorrelationId = request.CorrelationId
                }, ct);
            }
        }

        _logger.LogInformation(
            "Transaction: {Success} — {Ops} ops in {Ms}ms",
            txResult.Success ? "committed" : "rolled back",
            orderedOps.Count,
            sw.ElapsedMilliseconds);

        return new TransactionResponse
        {
            Success = txResult.Success,
            OperationsExecuted = txResult.Success ? orderedOps.Count : txResult.SucceededCount,
            Error = txResult.Error,
            ExecutionTime = sw.Elapsed
        };
    }

    // ── Private helpers ────────────────────────────────────────────────

    private async Task<IReadOnlyDictionary<string, object?>> MapInboundValuesAsync(
        IReadOnlyDictionary<string, object?> values,
        TableMetadata schema,
        CancellationToken ct)
    {
        if (!_fieldMapper.IsAvailable) return values;

        var mapped = new Dictionary<string, object?>(values.Count, StringComparer.OrdinalIgnoreCase);
        foreach (var (key, value) in values)
        {
            var resolved = await _fieldMapper.ResolveColumnAsync(schema.TableName, key, ct);
            mapped[resolved ?? key] = value;
        }
        return mapped;
    }

    private void ValidateWriteValues(
        IReadOnlyDictionary<string, object?> values,
        TableMetadata schema,
        bool allowAutoIncrement)
    {
        foreach (var key in values.Keys)
        {
            if (!allowAutoIncrement)
                _columnGuard.AssertWritable(key, schema);
            else
                _columnGuard.AssertExists(key, schema);
        }
    }

    private async ValueTask WriteAuditAsync(AuditEntry entry, CancellationToken ct)
    {
        if (!_auditWriter.IsEnabled) return;

        try
        {
            await _auditWriter.WriteAsync(entry, ct);
        }
        catch (Exception ex)
        {
            // Audit failures must NEVER fail the primary operation
            _logger.LogError(ex,
                "Audit write failed for {Operation} on {Table}. " +
                "Primary operation was successful.",
                entry.Operation, entry.TableName);
        }
    }
}