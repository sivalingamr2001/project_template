// DataEngine.Extensions.DependencyInjection/DataEngineOptions.cs
namespace DataEngine.Extensions.DependencyInjection;

public sealed class DataEngineOptions
{
    // ── Connection ─────────────────────────────────────────────────────
    
    /// <summary>Default connection string key in IConfiguration.</summary>
    public string DefaultConnectionStringName { get; set; } = "DefaultConnection";
    
    /// <summary>Named additional databases. Key = alias, Value = conn string name.</summary>
    public Dictionary<string, string> AdditionalDatabases { get; set; } = [];
    
    // ── Schema cache ───────────────────────────────────────────────────
    
    public TimeSpan? SchemaCacheTtl { get; set; } = TimeSpan.FromMinutes(30);
    
    /// <summary>Preload schema for default database at startup.</summary>
    public bool PreloadSchemaOnStartup { get; set; } = true;
    
    // ── Security ───────────────────────────────────────────────────────
    
    /// <summary>Allow raw SQL. FALSE by default — never set true in production.</summary>
    public bool AllowRawSql { get; set; } = false;
    
    public bool AllowStoredProcedures { get; set; } = true;
    
    // ── Optional features ──────────────────────────────────────────────
    
    public bool EnableAudit { get; set; } = false;
    public bool EnableFieldMapping { get; set; } = false;
    public bool EnableSavedQueryDefinitions { get; set; } = false;
    
    // ── Performance ────────────────────────────────────────────────────
    
    public int DefaultCommandTimeoutSeconds { get; set; } = 30;
    public int DefaultPageSize { get; set; } = 20;
    public int MaxPageSize { get; set; } = 1000;
    public int BulkInsertBatchSize { get; set; } = 500;
}