// DataEngine.Extensions.DependencyInjection/DataEngineServiceCollectionExtensions.cs
namespace DataEngine.Extensions.DependencyInjection;

public static class DataEngineServiceCollectionExtensions
{
    /// <summary>
    /// Add DataEngine with default configuration.
    /// Reads ConnectionStrings:DefaultConnection from appsettings.
    /// Returns DataEngineBuilder for optional fluent configuration.
    /// </summary>
    public static DataEngineBuilder AddDataEngine(
        this IServiceCollection services,
        IConfiguration configuration)
        => services.AddDataEngine(configuration, _ => { });

    /// <summary>
    /// Add DataEngine with configuration delegate.
    /// </summary>
    public static DataEngineBuilder AddDataEngine(
        this IServiceCollection services,
        IConfiguration configuration,
        Action<DataEngineOptions> configure)
    {
        // ── Build options ──────────────────────────────────────────────
        var options = new DataEngineOptions();
        configuration.GetSection("DataEngine").Bind(options);
        configure(options);
        services.AddSingleton(options);

        // ── Infrastructure dependencies ────────────────────────────────
        services.AddMemoryCache();
        services.AddLogging();

        // ── Connection layer ───────────────────────────────────────────
        // Singleton: connection strings don't change at runtime
        services.AddSingleton<MySqlConnectionFactory>(sp =>
            new MySqlConnectionFactory(
                configuration,
                sp.GetRequiredService<DataEngineOptions>()));

        // IConnectionFactory points to MySqlConnectionFactory
        services.AddSingleton<IConnectionFactory>(sp =>
            sp.GetRequiredService<MySqlConnectionFactory>());

        // Router uses the factory — also Singleton
        services.AddSingleton<MultiDatabaseRouter>();

        // ── Schema layer ───────────────────────────────────────────────
        // Cache is Singleton — shared across all requests
        services.AddSingleton<ISchemaCache, InMemorySchemaCache>();

        // Provider is Scoped — creates connections per scope
        services.AddScoped<ISchemaProvider, MySqlSchemaProvider>();

        // ── Security ───────────────────────────────────────────────────
        // Guards are Singleton — stateless, thread-safe
        services.AddSingleton<TableGuard>();
        services.AddSingleton<ColumnGuard>();

        // ── Query layer ────────────────────────────────────────────────
        // Compiler is Singleton — pure functions, no state
        services.AddSingleton<IQueryCompiler, MySqlQueryCompiler>();

        // Executor is Scoped — creates connections per request
        services.AddScoped<IQueryExecutor, DapperQueryExecutor>();

        // ── Write layer ────────────────────────────────────────────────
        services.AddScoped<AdoNetWriteExecutor>();
        services.AddScoped<BulkWriteExecutor>();

        // ── Procedure layer ────────────────────────────────────────────
        services.AddScoped<IProcedureExecutor, MySqlProcedureExecutor>();

        // ── Optional features — Null Object defaults ───────────────────
        // These can be replaced by DataEngineBuilder.With*() calls
        services.AddSingleton<IAuditWriter, NullAuditWriter>();
        services.AddSingleton<IFieldMapperProvider, NullFieldMapperProvider>();
        services.AddSingleton<ISavedQueryProvider, NullSavedQueryProvider>();

        // ── Orchestrators ──────────────────────────────────────────────
        // Scoped: each request gets its own orchestrator chain
        services.AddScoped<QueryOrchestrator>();
        services.AddScoped<WriteOrchestrator>();
        services.AddScoped<ProcedureOrchestrator>();

        // ── Main entry point ───────────────────────────────────────────
        services.AddScoped<IDataEngine, DataEngineService>();

        // ── Background services ────────────────────────────────────────
        if (options.PreloadSchemaOnStartup)
            services.AddHostedService<SchemaRefreshService>();

        // ── Optional tables detector ───────────────────────────────────
        services.AddSingleton<OptionalTablesDetector>();

        return new DataEngineBuilder(services, options, configuration);
    }
}