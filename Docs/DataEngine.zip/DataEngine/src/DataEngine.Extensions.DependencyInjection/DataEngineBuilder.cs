// DataEngine.Extensions.DependencyInjection/DataEngineBuilder.cs
namespace DataEngine.Extensions.DependencyInjection;

/// <summary>
/// Fluent builder returned by AddDataEngine().
/// Allows chaining optional configuration after the core registration.
///
/// Usage:
///   builder.Services
///       .AddDataEngine(config)
///       .WithAudit()
///       .WithFieldMapping()
///       .WithSavedQueries()
///       .WithDatabase("reporting", "ReportingConnection");
/// </summary>
public sealed class DataEngineBuilder
{
    internal IServiceCollection Services { get; }
    internal DataEngineOptions Options { get; }
    internal IConfiguration Configuration { get; }

    internal DataEngineBuilder(
        IServiceCollection services,
        DataEngineOptions options,
        IConfiguration configuration)
    {
        Services = services;
        Options = options;
        Configuration = configuration;
    }

    /// <summary>
    /// Enable audit trail. Requires 'de_transaction_audit' table.
    /// </summary>
    public DataEngineBuilder WithAudit()
    {
        Options.EnableAudit = true;

        // Replace NullAuditWriter with real implementation
        var existing = Services.FirstOrDefault(
            s => s.ServiceType == typeof(IAuditWriter));
        if (existing != null) Services.Remove(existing);

        Services.AddScoped<IAuditWriter, TableAuditWriter>();
        return this;
    }

    /// <summary>
    /// Enable field alias mapping. Requires 'de_field_mappings' table.
    /// </summary>
    public DataEngineBuilder WithFieldMapping()
    {
        Options.EnableFieldMapping = true;

        var existing = Services.FirstOrDefault(
            s => s.ServiceType == typeof(IFieldMapperProvider));
        if (existing != null) Services.Remove(existing);

        Services.AddScoped<IFieldMapperProvider, FieldMapperProvider>();
        return this;
    }

    /// <summary>
    /// Enable saved query definitions. Requires 'de_query_definitions' table.
    /// </summary>
    public DataEngineBuilder WithSavedQueries()
    {
        Options.EnableSavedQueryDefinitions = true;

        var existing = Services.FirstOrDefault(
            s => s.ServiceType == typeof(ISavedQueryProvider));
        if (existing != null) Services.Remove(existing);

        Services.AddScoped<ISavedQueryProvider, SavedQueryDefinitionProvider>();
        return this;
    }

    /// <summary>
    /// Register an additional database by alias.
    /// </summary>
    public DataEngineBuilder WithDatabase(string alias, string connectionStringName)
    {
        Options.AdditionalDatabases[alias] = connectionStringName;
        return this;
    }

    /// <summary>
    /// Override the default page size.
    /// </summary>
    public DataEngineBuilder WithPageSize(int defaultSize, int maxSize)
    {
        Options.DefaultPageSize = defaultSize;
        Options.MaxPageSize = maxSize;
        return this;
    }

    /// <summary>
    /// Override the schema cache TTL.
    /// </summary>
    public DataEngineBuilder WithSchemaCacheTtl(TimeSpan ttl)
    {
        Options.SchemaCacheTtl = ttl;
        return this;
    }

    /// <summary>
    /// Disable schema preloading at startup.
    /// Schema will be loaded lazily on first request.
    /// </summary>
    public DataEngineBuilder WithLazySchemaLoading()
    {
        Options.PreloadSchemaOnStartup = false;
        return this;
    }
}