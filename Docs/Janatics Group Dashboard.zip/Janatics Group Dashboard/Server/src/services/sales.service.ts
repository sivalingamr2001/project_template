import oracledb from 'oracledb';
import { getConnection } from '../db/pool';
import { SALES_DATA_SQL, SALES_SUMMARY_SQL } from '../db/queries';

export interface SalesFilter {
  fromDate?: string;
  region?:   string;
}

// Updated interfaces to match your new view: JAN_ALL_OU_ORD_SALES_V
export interface SaleRecord {
  OU_NAME:   string;
  YR:        string;
  SALE_VAL:  number;
}

export interface SummaryRecord {
  OU_NAME:      string;
  YR:           string;
  PEND_ORD_VAL: number;
}

export interface SalesResult {
  sales:   SaleRecord[];
  summary: SummaryRecord[];
}

const FETCH_ARRAY_SIZE = 200;
const PREFETCH_ROWS    = 201;

export async function fetchSales(filter: SalesFilter): Promise<SalesResult> {
  const conn = await getConnection();

  try {
    // If no fromDate is provided by the client, default to your view baseline date
    const targetDate = filter.fromDate ?? '2025-04-01';
    const targetRegion = filter.region ?? null;

    // Maps 1:1 with the tokens in SALES_DATA_SQL
    const dataBinds = {
      fromDate1: targetDate,
      region1:   targetRegion,
      region2:   targetRegion,
    };

    // Maps 1:1 with the tokens in SALES_SUMMARY_SQL
    const summaryBinds = {
      fromDate2: targetDate,
      region3:   targetRegion,
      region4:   targetRegion,
    };

    const [dataResult, summaryResult] = await Promise.all([
      conn.execute<SaleRecord>(SALES_DATA_SQL, dataBinds, {
        outFormat:      oracledb.OUT_FORMAT_OBJECT,
        fetchArraySize: FETCH_ARRAY_SIZE,
        prefetchRows:   PREFETCH_ROWS,
      }),
      conn.execute<SummaryRecord>(SALES_SUMMARY_SQL, summaryBinds, { 
        outFormat: oracledb.OUT_FORMAT_OBJECT 
      }),
    ]);

    console.log('Data Query Binds:', dataResult.rows);
    console.log('Summary Query Binds:', summaryResult.rows);

    return {
      sales:   dataResult.rows ?? [],      
      summary: summaryResult.rows ?? [],
    };
  } finally {
    await conn.close();
  }
}
