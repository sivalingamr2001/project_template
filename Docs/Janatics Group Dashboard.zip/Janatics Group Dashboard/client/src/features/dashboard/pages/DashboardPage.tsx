import { TOTALS_ROW, OPERATING_UNITS_DATA } from "@/features/dashboard/api/dashboardApi"
import { useDashboard } from "@/features/dashboard/hooks/useDashboard"
import { DashboardHeader } from "../components/DashboardHeader"
import { KpiCards } from "../components/KpiCards"
import { OperatingUnitsTable } from "../components/OperatingUnitsTable"

export const DashboardPage = () => {
  const { inclIntraSales, handleToggleIntraSales } = useDashboard()

  return (
    <main className="min-h-screen bg-[#f8fafc] p-6 md:p-8">
      <div className="mx-auto max-w-8xl">
        <DashboardHeader
          inclIntraSales={inclIntraSales}
          onToggleIntraSales={handleToggleIntraSales}
        />
        <KpiCards totals={TOTALS_ROW} />
        <OperatingUnitsTable
          rows={OPERATING_UNITS_DATA}
          totals={TOTALS_ROW}
        />
      </div>
    </main>
  )
}
