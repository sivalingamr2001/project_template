import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const DATA = Array.from({ length: 12 }, (_, i) => ({
  day: `D${i + 1}`,
  count: Math.floor(20 + Math.random() * 30),
}));

export function CertificationTrendChart() {
  return (
    <div className="card p-5">
      <h3 className="text-sm font-semibold text-slate-800 mb-4">Certifications (90 days)</h3>
      <ResponsiveContainer width="100%" height={240}>
        <LineChart data={DATA}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
          <XAxis dataKey="day" tick={{ fontSize: 11 }} />
          <YAxis tick={{ fontSize: 11 }} />
          <Tooltip />
          <Line type="monotone" dataKey="count" stroke="#2563eb" strokeWidth={2} dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
