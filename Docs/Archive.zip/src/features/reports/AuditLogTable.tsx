import { useState } from 'react';
import { useReports } from './hooks/useReports';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { CategoryBadge } from '@/components/ui/CategoryBadge';
import { formatDate } from '@/lib/utils/date';
import { cn } from '@/lib/utils/cn';
import { TableSkeleton } from '@/components/ui/LoadingSkeleton';
import type { ReportFilters } from '@/lib/types/report.types';

export function AuditLogTable({ className }: { className?: string }) {
  const [filters] = useState<ReportFilters>({
    vendor: '',
    status: 'all',
    category: '',
    dateFrom: '',
    dateTo: '',
  });
  const { data: entries = [], isLoading } = useReports(filters);

  if (isLoading) return <TableSkeleton rows={5} />;

  return (
    <div className={cn('card overflow-hidden', className)}>
      <div id="audit-log-table" className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-blue-50 text-xs text-blue-800 uppercase">
            <tr>
              <th className="px-4 py-3 text-left">Request ID</th>
              <th className="px-4 py-3 text-left">Vendor</th>
              <th className="px-4 py-3 text-left">Item</th>
              <th className="px-4 py-3 text-left">Category</th>
              <th className="px-4 py-3 text-left">Cert. Date</th>
              <th className="px-4 py-3 text-left">Expiry</th>
              <th className="px-4 py-3 text-left">Status</th>
              <th className="px-4 py-3 text-left">Remarks</th>
            </tr>
          </thead>
          <tbody>
            {entries.map((e) => (
              <tr key={e.id} className="border-t border-slate-100 hover:bg-slate-50">
                <td className="px-4 py-3 font-mono text-xs">{e.requestId}</td>
                <td className="px-4 py-3">
                  <p className="font-medium">{e.vendorName}</p>
                  <p className="text-xs text-slate-400">{e.vendorCode}</p>
                </td>
                <td className="px-4 py-3">
                  <p className="font-mono text-xs">{e.itemCode}</p>
                  <p className="text-xs text-slate-500">{e.itemName}</p>
                </td>
                <td className="px-4 py-3">
                  <CategoryBadge category={e.category} />
                </td>
                <td className="px-4 py-3">{formatDate(e.certificationDate)}</td>
                <td className="px-4 py-3">{formatDate(e.certificationExpiry)}</td>
                <td className="px-4 py-3">
                  <StatusBadge status={e.status} />
                </td>
                <td className="px-4 py-3 text-xs text-slate-600 max-w-xs">{e.remarks}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
