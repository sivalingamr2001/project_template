import { StatCard } from '@/components/ui/StatCard';
import { cn } from '@/lib/utils/cn';

export function ReportKPIRow({ className }: { className?: string }) {
  return (
    <div className={cn('grid grid-cols-2 lg:grid-cols-4 gap-4', className)}>
      <StatCard label="Total" value="1,247" color="text-slate-700" bgColor="bg-slate-50" />
      <StatCard label="Approved" value="1,089" color="text-emerald-600" bgColor="bg-emerald-50" to="/reports?status=approved" />
      <StatCard label="Pending" value="42" color="text-orange-600" bgColor="bg-orange-50" to="/approvals" pulse />
      <StatCard label="Rejected" value="116" color="text-red-600" bgColor="bg-red-50" to="/reports?status=rejected" />
    </div>
  );
}
