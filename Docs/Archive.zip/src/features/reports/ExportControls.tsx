import { Download, FileSpreadsheet, FileText } from 'lucide-react';
import { exportToCSV, exportToXLSX, exportToPDF } from '@/lib/utils/export';
import { toast } from 'sonner';

interface ExportControlsProps {
  data?: Record<string, unknown>[];
}

export function ExportControls({ data = [] }: ExportControlsProps) {
  const filename = `gcc-report-${new Date().toISOString().split('T')[0]}`;

  return (
    <div className="flex items-center gap-2">
      <button
        type="button"
        onClick={() => {
          exportToCSV(data.length ? data : [{ message: 'No data' }], filename);
          toast.success('CSV exported');
        }}
        className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium border border-slate-200 rounded-lg hover:bg-slate-50 min-h-0 min-w-0"
      >
        <Download size={14} />
        CSV
      </button>
      <button
        type="button"
        onClick={() => {
          exportToXLSX(data.length ? data : [{ message: 'No data' }], filename);
          toast.success('XLSX exported');
        }}
        className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium border border-slate-200 rounded-lg hover:bg-slate-50 min-h-0 min-w-0"
      >
        <FileSpreadsheet size={14} />
        XLSX
      </button>
      <button
        type="button"
        onClick={() => {
          exportToPDF('audit-log-table', filename);
          toast.success('PDF print dialog opened');
        }}
        className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium border border-slate-200 rounded-lg hover:bg-slate-50 min-h-0 min-w-0"
      >
        <FileText size={14} />
        PDF
      </button>
    </div>
  );
}
