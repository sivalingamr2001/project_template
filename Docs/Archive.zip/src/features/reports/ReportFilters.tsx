import { useState } from 'react';
import type { ReportFilters as Filters } from '@/lib/types/report.types';

const PRESETS = [
  { label: 'Today', days: 0 },
  { label: 'This Week', days: 7 },
  { label: 'This Month', days: 30 },
];

export function ReportFilters({
  filters,
  onChange,
}: {
  filters?: Filters;
  onChange?: (f: Filters) => void;
}) {
  const [local, setLocal] = useState<Filters>(
    filters ?? { vendor: '', status: 'all', category: '', dateFrom: '', dateTo: '' }
  );

  const update = (patch: Partial<Filters>) => {
    const next = { ...local, ...patch };
    setLocal(next);
    onChange?.(next);
  };

  const applyPreset = (days: number) => {
    const to = new Date();
    const from = new Date();
    from.setDate(from.getDate() - days);
    update({
      dateFrom: from.toISOString().split('T')[0],
      dateTo: to.toISOString().split('T')[0],
    });
  };

  return (
    <div className="card p-4 space-y-3">
      <div className="flex flex-wrap gap-2">
        {PRESETS.map((p) => (
          <button
            key={p.label}
            type="button"
            onClick={() => applyPreset(p.days)}
            className="px-3 py-1.5 text-xs font-medium border border-slate-200 rounded-lg hover:bg-slate-50 min-h-0 min-w-0"
          >
            {p.label}
          </button>
        ))}
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <input
          placeholder="Vendor..."
          value={local.vendor}
          onChange={(e) => update({ vendor: e.target.value })}
          className="px-3 py-2 border border-slate-300 rounded-lg text-sm"
        />
        <select
          value={local.status}
          onChange={(e) => update({ status: e.target.value })}
          className="px-3 py-2 border border-slate-300 rounded-lg text-sm"
        >
          <option value="all">All statuses</option>
          <option value="pending">Pending</option>
          <option value="approved">Approved</option>
          <option value="rejected">Rejected</option>
        </select>
        <input
          type="date"
          value={local.dateFrom}
          onChange={(e) => update({ dateFrom: e.target.value })}
          className="px-3 py-2 border border-slate-300 rounded-lg text-sm"
        />
        <input
          type="date"
          value={local.dateTo}
          onChange={(e) => update({ dateTo: e.target.value })}
          className="px-3 py-2 border border-slate-300 rounded-lg text-sm"
        />
      </div>
    </div>
  );
}

