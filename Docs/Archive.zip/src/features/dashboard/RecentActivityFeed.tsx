import { MOCK_AUDIT_EVENTS } from '@/lib/mock/data';
import { formatDateTime } from '@/lib/utils/date';
import { FileCheck, XCircle, Upload } from 'lucide-react';
import { Link } from 'react-router-dom';

const EVENT_ICONS = {
  submission: Upload,
  approval: FileCheck,
  rejection: XCircle,
  'bulk-approve': FileCheck,
  edit: Upload,
  deletion: XCircle,
};

export function RecentActivityFeed() {
  const events = MOCK_AUDIT_EVENTS.slice(0, 5);

  return (
    <div className="card p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-slate-800">Recent Activity</h3>
        <Link to="/audit" className="text-xs text-blue-600 hover:text-blue-700 font-medium min-h-0 min-w-0">
          View all
        </Link>
      </div>
      <ul className="space-y-3">
        {events.map((e) => {
          const Icon = EVENT_ICONS[e.eventType] ?? Upload;
          return (
            <li key={e.id} className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center shrink-0">
                <Icon size={14} className="text-slate-500" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-slate-800">
                  <span className="font-medium">{e.actor}</span>{' '}
                  <span className="text-slate-500">{e.eventType}</span>{' '}
                  <span className="font-mono text-xs">{e.targetRequestId}</span>
                </p>
                <p className="text-xs text-slate-400 mt-0.5">{formatDateTime(e.timestamp)}</p>
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
