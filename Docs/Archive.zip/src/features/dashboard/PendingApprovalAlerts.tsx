import { useApprovals } from '@/features/approvals/hooks/useApprovals';
import { SLATimer } from '@/components/ui/SLATimer';
import { isSlaBreached } from '@/lib/utils/date';
import { Link } from 'react-router-dom';
import { AlertTriangle } from 'lucide-react';
import { LoadingSkeleton } from '@/components/ui/LoadingSkeleton';

export function PendingApprovalAlerts() {
  const { data: approvals = [], isLoading } = useApprovals({
    vendor: '',
    category: '',
    status: 'pending',
    dateFrom: '',
    dateTo: '',
  });

  const pending = approvals.filter((a) => a.status === 'pending');

  return (
    <div className="card p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-slate-800">Pending Approvals</h3>
        <Link to="/approvals" className="text-xs text-blue-600 hover:text-blue-700 font-medium min-h-0 min-w-0">
          Review all
        </Link>
      </div>
      {isLoading ? (
        <LoadingSkeleton className="h-20 w-full" />
      ) : pending.length === 0 ? (
        <p className="text-sm text-slate-500 py-4 text-center">No pending approvals</p>
      ) : (
        <ul className="space-y-3">
          {pending.map((a) => {
            const slaBreached = isSlaBreached(a.submittedAt);
            return (
              <li
                key={a.requestId}
                className={`p-3 rounded-lg border ${slaBreached ? 'bg-amber-50 border-amber-200' : 'bg-slate-50 border-slate-100'}`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-sm font-medium text-slate-800">{a.vendorName}</p>
                    <p className="text-xs text-slate-500 font-mono mt-0.5">
                      {a.requestId} · {a.itemCode}
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    {slaBreached && (
                      <span className="flex items-center gap-1 text-xs text-amber-600 font-medium mb-1">
                        <AlertTriangle size={12} />
                        SLA
                      </span>
                    )}
                    <SLATimer submittedAt={a.submittedAt} />
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

