import type { AuditEvent } from '@/lib/types/report.types';
import { formatDateTime } from '@/lib/utils/date';
import { FileCheck, XCircle, Upload, Trash2, Edit } from 'lucide-react';
import { cn } from '@/lib/utils/cn';

const EVENT_CONFIG = {
  submission: { icon: Upload, color: 'bg-blue-50 text-blue-700 border-blue-200', label: 'Submission' },
  approval: { icon: FileCheck, color: 'bg-emerald-50 text-emerald-700 border-emerald-200', label: 'Approval' },
  rejection: { icon: XCircle, color: 'bg-red-50 text-red-700 border-red-200', label: 'Rejection' },
  'bulk-approve': { icon: FileCheck, color: 'bg-emerald-50 text-emerald-700 border-emerald-200', label: 'Bulk Approve' },
  edit: { icon: Edit, color: 'bg-slate-50 text-slate-700 border-slate-200', label: 'Edit' },
  deletion: { icon: Trash2, color: 'bg-red-50 text-red-700 border-red-200', label: 'Deletion' },
};

export function AuditEventRow({ event }: { event: AuditEvent }) {
  const config = EVENT_CONFIG[event.eventType];
  const Icon = config.icon;

  return (
    <li className="flex gap-4 p-4 border-b border-slate-100 last:border-0">
      <div
        className={cn(
          'w-10 h-10 rounded-full flex items-center justify-center shrink-0 border',
          config.color
        )}
      >
        <Icon size={18} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex flex-wrap items-center gap-2">
          <span className={cn('text-xs font-semibold px-2 py-0.5 rounded border', config.color)}>
            {config.label}
          </span>
          <span className="text-xs text-slate-400">{formatDateTime(event.timestamp)}</span>
        </div>
        <p className="text-sm text-slate-800 mt-1">
          <span className="font-medium">{event.actor}</span>
          <span className="text-slate-500"> ({event.actorRole})</span>
        </p>
        <p className="text-xs text-slate-500 mt-0.5 font-mono">
          {event.targetRequestId} · {event.targetItemCode}
        </p>
        {(event.beforeState || event.afterState) && (
          <p className="text-xs text-slate-600 mt-1">
            {event.beforeState && <span className="line-through text-slate-400">{event.beforeState}</span>}
            {event.beforeState && event.afterState && ' → '}
            {event.afterState && <span className="font-medium">{event.afterState}</span>}
          </p>
        )}
        {event.remarks && <p className="text-xs text-slate-500 mt-1">{event.remarks}</p>}
        <p className="text-[10px] text-slate-400 mt-2">
          IP: {event.ipAddress.replace(/\d+$/, 'x.x')} · Session: {event.sessionId}
        </p>
      </div>
    </li>
  );
}
