import { cn } from '@/lib/utils/cn';
import type { AuditTrailFilters } from './hooks/useAuditTrail';

const EVENT_TYPES = [
  { value: 'all', label: 'All Events' },
  { value: 'submission', label: 'Submission' },
  { value: 'approval', label: 'Approval' },
  { value: 'rejection', label: 'Rejection' },
  { value: 'bulk-approve', label: 'Bulk Approve' },
];

export function AuditFilters({
  filters,
  onChange,
  className,
}: {
  filters: AuditTrailFilters;
  onChange: (f: AuditTrailFilters) => void;
  className?: string;
}) {
  return (
    <div className={cn('card p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3', className)}>
      <select
        value={filters.eventType}
        onChange={(e) => onChange({ ...filters, eventType: e.target.value })}
        className="px-3 py-2 border border-slate-300 rounded-lg text-sm"
      >
        {EVENT_TYPES.map((t) => (
          <option key={t.value} value={t.value}>
            {t.label}
          </option>
        ))}
      </select>
      <input
        placeholder="Actor name..."
        value={filters.actor}
        onChange={(e) => onChange({ ...filters, actor: e.target.value })}
        className="px-3 py-2 border border-slate-300 rounded-lg text-sm"
      />
      <input
        placeholder="Request ID..."
        value={filters.requestId}
        onChange={(e) => onChange({ ...filters, requestId: e.target.value })}
        className="px-3 py-2 border border-slate-300 rounded-lg text-sm font-mono"
      />
      <input
        type="date"
        value={filters.dateFrom}
        onChange={(e) => onChange({ ...filters, dateFrom: e.target.value })}
        className="px-3 py-2 border border-slate-300 rounded-lg text-sm"
      />
    </div>
  );
}
