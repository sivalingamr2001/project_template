import { useState, useCallback } from 'react';
import { PageWrapper } from '@/components/layout/PageWrapper';
import { ApprovalQueueTable } from './ApprovalQueueTable';
import { ApprovalCardList } from './ApprovalCardList';
import { BulkActionBar } from './BulkActionBar';
import { ApprovalFilters } from './ApprovalFilters';
import { ApproveModal } from './ApproveModal';
import { RejectModal } from './RejectModal';
import {
  useApprovals,
  useApproveMutation,
  useRejectMutation,
} from './hooks/useApprovals';
import { useMediaQuery } from '@/lib/hooks/useMediaQuery';
import type { ApprovalItem } from '@/lib/types/approval.types';
import type { RejectionReason } from '@/lib/types/approval.types';
import type { ApprovalFilters as Filters } from '@/lib/api/approvals';
import { toast } from 'sonner';

export function ApprovalsPage() {
  const isMobile = useMediaQuery('(max-width: 1024px)');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [approveItem, setApproveItem] = useState<ApprovalItem | null>(null);
  const [rejectItem, setRejectItem] = useState<ApprovalItem | null>(null);
  const [filters, setFilters] = useState<Filters>({
    vendor: '',
    category: '',
    status: 'pending',
    dateFrom: '',
    dateTo: '',
  });

  const { data: approvals = [], isLoading, refetch } = useApprovals(filters);
  const approveMutation = useApproveMutation();
  const rejectMutation = useRejectMutation();

  const pendingCount = approvals.filter((a) => a.status === 'pending').length;

  const handleApprove = useCallback(
    async (remarks: string) => {
      if (!approveItem) return;
      await approveMutation.mutateAsync({ requestId: approveItem.requestId, remarks });
      toast.success(`Approved ${approveItem.requestId}`);
      setApproveItem(null);
      refetch();
    },
    [approveItem, approveMutation, refetch]
  );

  const handleReject = useCallback(
    async (reason: RejectionReason, remarks: string) => {
      if (!rejectItem) return;
      await rejectMutation.mutateAsync({ requestId: rejectItem.requestId, reason, remarks });
      toast.success(`Rejected ${rejectItem.requestId}. Vendor will be notified.`);
      setRejectItem(null);
      refetch();
    },
    [rejectItem, rejectMutation, refetch]
  );

  return (
    <PageWrapper
      title="Approvals"
      description="Review and approve Green Channel certification requests. Approved items will be enabled in Oracle ERP."
      badge={pendingCount}
    >
      <ApprovalFilters filters={filters} onChange={setFilters} />

      <BulkActionBar
        selectedCount={selectedIds.length}
        totalCount={approvals.length}
        onSelectAll={() => setSelectedIds(approvals.map((a) => a.requestId))}
        onDeselectAll={() => setSelectedIds([])}
        onBulkApprove={() => {}}
        onBulkReject={() => {}}
        className="mt-4"
      />

      {isMobile ? (
        <ApprovalCardList
          items={approvals}
          isLoading={isLoading}
          onApprove={setApproveItem}
          onReject={setRejectItem}
          selectedIds={selectedIds}
          onToggleSelect={(id) =>
            setSelectedIds((prev) =>
              prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
            )
          }
          className="mt-4"
        />
      ) : (
        <ApprovalQueueTable
          items={approvals}
          isLoading={isLoading}
          selectedIds={selectedIds}
          onSelectionChange={setSelectedIds}
          onApprove={setApproveItem}
          onReject={setRejectItem}
          className="mt-4"
        />
      )}

      <ApproveModal
        item={approveItem}
        onClose={() => setApproveItem(null)}
        onConfirm={handleApprove}
      />

      <RejectModal
        item={rejectItem}
        onClose={() => setRejectItem(null)}
        onConfirm={handleReject}
      />
    </PageWrapper>
  );
}
