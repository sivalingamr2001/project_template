import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { CharCountTextarea } from '@/components/ui/CharCountTextarea';
import { Button } from '@/components/ui/button';
import type { ApprovalItem } from '@/lib/types/approval.types';
import { formatDate } from '@/lib/utils/date';
import { CheckCircle2 } from 'lucide-react';

interface ApproveModalProps {
  item: ApprovalItem | null;
  onClose: () => void;
  onConfirm: (remarks: string) => Promise<void>;
}

export function ApproveModal({ item, onClose, onConfirm }: ApproveModalProps) {
  const [remarks, setRemarks] = useState('');
  const [loading, setLoading] = useState(false);

  if (!item) return null;

  const handleConfirm = async () => {
    setLoading(true);
    try {
      await onConfirm(remarks);
      setRemarks('');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={!!item} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-emerald-700">
            <CheckCircle2 size={20} />
            Approve Certification
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-3 text-sm">
          <p>
            <span className="text-slate-500">Request:</span>{' '}
            <span className="font-mono font-medium">{item.requestId}</span>
          </p>
          <p>
            <span className="text-slate-500">Item:</span> {item.itemCode} — {item.itemName}
          </p>
          <p>
            <span className="text-slate-500">Cert. Date:</span> {formatDate(item.certificationDate)} →{' '}
            {formatDate(item.certificationExpiry)}
          </p>
        </div>
        <CharCountTextarea
          label="Approval Remarks (optional)"
          value={remarks}
          onChange={setRemarks}
          maxLength={500}
          placeholder="Optional notes for the approval record..."
        />
        <div className="flex gap-3 justify-end">
          <Button variant="outline" onClick={onClose} disabled={loading}>
            Cancel
          </Button>
          <Button variant="success" onClick={handleConfirm} disabled={loading}>
            {loading ? 'Approving...' : 'Confirm Approval'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
