import { useVendor } from '@/lib/api/vendors';
import { cn } from '@/lib/utils/cn';

export function CertificationStatusBar({
  vendorId,
  className,
}: {
  vendorId: string;
  className?: string;
}) {
  const { data: vendor } = useVendor(vendorId);
  if (!vendor) return null;

  const { totalEligible, alreadyCertified, remaining } = vendor.certificationStats;
  const pct = totalEligible > 0 ? Math.round((alreadyCertified / totalEligible) * 100) : 0;

  return (
    <div className={cn('grid grid-cols-3 gap-3', className)}>
      {[
        { label: 'Total Eligible', value: totalEligible, color: 'text-slate-700', bg: 'bg-slate-50' },
        { label: 'Already Certified', value: alreadyCertified, color: 'text-emerald-700', bg: 'bg-emerald-50' },
        { label: 'Remaining', value: remaining, color: 'text-blue-700', bg: 'bg-blue-50' },
      ].map(({ label, value, color, bg }) => (
        <div key={label} className={cn('rounded-xl border border-slate-200 p-4 text-center', bg)}>
          <p className={cn('text-2xl font-bold tabular-nums', color)}>{value}</p>
          <p className="text-xs text-slate-500 mt-1">{label}</p>
        </div>
      ))}
      <div className="col-span-3">
        <div className="flex justify-between text-xs text-slate-500 mb-1">
          <span>Certification progress</span>
          <span>{pct}%</span>
        </div>
        <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
          <div
            className="h-full bg-blue-600 rounded-full transition-all"
            style={{ width: `${pct}%` }}
          />
        </div>
      </div>
    </div>
  );
}

