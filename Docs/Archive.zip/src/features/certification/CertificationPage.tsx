import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { PageWrapper } from '@/components/layout/PageWrapper';
import { WorkflowProgress } from '@/components/ui/WorkflowProgress';
import { VendorSearchCombobox } from '@/components/shared/VendorSearchCombobox';
import { VendorDetailCard } from './VendorDetailCard';
import { CertificationStatusBar } from './CertificationStatusBar';
import { ItemEntryForm } from './ItemEntryForm';
import { SelectedItemsTable } from './SelectedItemsTable';
import { BulkUploadModal } from '@/components/shared/BulkUploadModal';
import { useCertificationDraft } from './hooks/useCertificationDraft';
import { toast } from 'sonner';
import { Upload, Eye } from 'lucide-react';

const WORKFLOW_STEPS = ['Select Vendor', 'Add Items', 'Preview', 'Submit'];

export function CertificationPage() {
  const navigate = useNavigate();
  const { draft, setVendor, addItem, removeItem, clearDraft } = useCertificationDraft();
  const [bulkUploadOpen, setBulkUploadOpen] = useState(false);

  const currentStep = !draft.vendorId ? 0 : draft.items.length > 0 ? 1 : 0;

  const handlePreview = () => {
    if (draft.items.length === 0) {
      toast.error('Add at least one item before previewing');
      return;
    }
    navigate('/certifications/preview');
  };

  return (
    <PageWrapper
      title="Green Channel Certification"
      description="Certify vendor items to enable self-certification and skip factory inspection"
    >
      <WorkflowProgress steps={WORKFLOW_STEPS} currentStep={currentStep} />

      <section className="mt-6">
        <VendorSearchCombobox
          value={draft.vendorId}
          onChange={(vendor) => {
            setVendor(vendor);
            toast.success(`Vendor selected: ${vendor.name}`);
          }}
        />
      </section>

      {draft.vendorId && (
        <>
          <VendorDetailCard vendorId={draft.vendorId} className="mt-4" />
          <CertificationStatusBar vendorId={draft.vendorId} className="mt-4" />

          <div className="mt-6 bg-white rounded-xl border border-slate-200 overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
              <h3 className="text-sm font-semibold text-slate-800">Add Items for Certification</h3>
              <button
                type="button"
                onClick={() => setBulkUploadOpen(true)}
                className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors min-h-0 min-w-0"
              >
                <Upload size={14} />
                Bulk Upload from Excel
              </button>
            </div>
            <div className="p-5">
              <ItemEntryForm
                vendorId={draft.vendorId}
                existingItems={draft.items}
                onAdd={addItem}
              />
            </div>
          </div>

          {draft.items.length > 0 && (
            <SelectedItemsTable
              items={draft.items}
              onRemove={removeItem}
              className="mt-4"
            />
          )}

          <div className="flex flex-col sm:flex-row gap-3 mt-6">
            <button
              type="button"
              onClick={() => {
                clearDraft();
                toast.info('Certification cleared');
              }}
              className="flex-1 sm:flex-none px-4 py-2.5 text-sm font-medium text-slate-600 bg-white border border-slate-300 hover:bg-slate-50 rounded-xl"
            >
              Clear All
            </button>
            <button
              type="button"
              onClick={handlePreview}
              disabled={draft.items.length === 0}
              className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-6 py-2.5 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl"
            >
              <Eye size={16} />
              Preview Submission
            </button>
          </div>
        </>
      )}

      <BulkUploadModal
        open={bulkUploadOpen}
        onClose={() => setBulkUploadOpen(false)}
        vendorId={draft.vendorId}
        onUploadComplete={(items) => {
          items.forEach(addItem);
          setBulkUploadOpen(false);
          toast.success(`${items.length} items added from upload`);
        }}
      />
    </PageWrapper>
  );
}
