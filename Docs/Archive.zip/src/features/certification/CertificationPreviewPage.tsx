import { useNavigate } from 'react-router-dom';
import { PageWrapper } from '@/components/layout/PageWrapper';
import { useCertificationDraft } from './hooks/useCertificationDraft';
import { SelectedItemsTable } from './SelectedItemsTable';
import { VendorDetailCard } from './VendorDetailCard';
import { submitCertification } from '@/lib/api/certifications';
import { toast } from 'sonner';
import { useState } from 'react';
import { ArrowLeft, Send } from 'lucide-react';

export function CertificationPreviewPage() {
  const navigate = useNavigate();
  const { draft, clearDraft } = useCertificationDraft();
  const [submitting, setSubmitting] = useState(false);

  if (!draft.vendorId || draft.items.length === 0) {
    navigate('/certifications');
    return null;
  }

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      const result = await submitCertification(
        draft.vendorId,
        draft.vendorCode,
        draft.vendorName,
        draft.items
      );
      clearDraft();
      toast.success(`Certification submitted: ${result.requestId}`);
      navigate('/approvals');
    } catch {
      toast.error('Submission failed. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <PageWrapper
      title="Preview Submission"
      description="Review all items before submitting for approval"
    >
      <button
        type="button"
        onClick={() => navigate('/certifications')}
        className="flex items-center gap-2 text-sm text-slate-600 hover:text-slate-800 mb-4 min-h-0 min-w-0"
      >
        <ArrowLeft size={16} />
        Back to edit
      </button>

      <VendorDetailCard vendorId={draft.vendorId} />
      <SelectedItemsTable items={draft.items} onRemove={() => {}} className="mt-4" />

      <div className="mt-6 p-4 bg-blue-50 border border-blue-100 rounded-xl">
        <p className="text-sm text-blue-800">
          Submitting <strong>{draft.items.length}</strong> item(s) for vendor{' '}
          <strong>{draft.vendorName}</strong>. Approved items will be enabled in Oracle ERP.
        </p>
      </div>

      <div className="flex gap-3 mt-6">
        <button
          type="button"
          onClick={() => navigate('/certifications')}
          className="btn-secondary flex-1 sm:flex-none"
        >
          Edit Items
        </button>
        <button
          type="button"
          onClick={handleSubmit}
          disabled={submitting}
          className="btn-primary flex-1 sm:flex-none flex items-center justify-center gap-2"
        >
          <Send size={16} />
          {submitting ? 'Submitting...' : 'Submit for Approval'}
        </button>
      </div>
    </PageWrapper>
  );
}
