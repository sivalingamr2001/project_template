import { useCertificationStore } from '@/store/certificationStore';

export function useCertificationDraft() {
  const draft = useCertificationStore((s) => s.draft);
  const setVendor = useCertificationStore((s) => s.setVendor);
  const addItem = useCertificationStore((s) => s.addItem);
  const removeItem = useCertificationStore((s) => s.removeItem);
  const clearDraft = useCertificationStore((s) => s.clearDraft);
  const updateItem = useCertificationStore((s) => s.updateItem);

  return { draft, setVendor, addItem, removeItem, clearDraft, updateItem };
}
