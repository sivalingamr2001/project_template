export interface Vendor {
  id: string;
  code: string;
  name: string;
  city: string;
  address: string;
  gstNumber: string;
  contactPerson: string;
  contactEmail: string;
  contactPhone: string;
  tier: 'gold' | 'silver' | 'standard';
  certificationStats: {
    totalEligible: number;
    alreadyCertified: number;
    remaining: number;
  };
}

export interface VendorItem {
  id: string;
  code: string;
  name: string;
  category: ItemCategory;
  isEligible: boolean;
  isCertified: boolean;
  lastCertifiedDate?: string;
  certificationExpiry?: string;
}

export type ItemCategory =
  | 'Bearings'
  | 'Fasteners'
  | 'Sealing'
  | 'Shafts'
  | 'Springs'
  | 'Pneumatics'
  | 'Other';
