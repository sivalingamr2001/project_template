import { format, parseISO, isValid } from 'date-fns';

export function formatDate(dateStr: string | undefined | null): string {
  if (!dateStr) return '—';
  const d = dateStr.includes('T') ? parseISO(dateStr) : new Date(dateStr);
  if (!isValid(d)) return '—';
  return format(d, 'dd/MM/yyyy');
}

export function formatDateTime(dateStr: string | undefined | null): string {
  if (!dateStr) return '—';
  const d = parseISO(dateStr);
  if (!isValid(d)) return '—';
  return format(d, 'dd/MM/yyyy HH:mm:ss');
}

export function formatPendingDuration(submittedAt: string): string {
  const ms = Date.now() - new Date(submittedAt).getTime();
  const hours = Math.floor(ms / (1000 * 60 * 60));
  const minutes = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60));
  if (hours > 0) return `${hours}h ${minutes}m`;
  return `${minutes}m`;
}

export function isSlaBreached(submittedAt: string, thresholdHours = 4): boolean {
  const ms = Date.now() - new Date(submittedAt).getTime();
  return ms > thresholdHours * 60 * 60 * 1000;
}
