import * as XLSX from 'xlsx';

export function exportToCSV(data: Record<string, unknown>[], filename: string) {
  const ws = XLSX.utils.json_to_sheet(data);
  const csv = XLSX.utils.sheet_to_csv(ws);
  downloadFile(csv, `${filename}.csv`, 'text/csv');
}

export function exportToXLSX(
  data: Record<string, unknown>[],
  filename: string,
  sheetName = 'Report'
) {
  const ws = XLSX.utils.json_to_sheet(data);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, sheetName);
  XLSX.writeFile(wb, `${filename}.xlsx`);
}

export function exportToPDF(tableId: string, filename: string) {
  const printWindow = window.open('', '_blank');
  if (!printWindow) return;
  const content = document.getElementById(tableId)?.outerHTML ?? '';
  printWindow.document.write(`
    <html>
      <head>
        <title>${filename}</title>
        <style>
          body { font-family: 'Segoe UI', sans-serif; font-size: 11px; }
          table { width: 100%; border-collapse: collapse; }
          th { background: #1e40af; color: white; padding: 6px 8px; text-align: left; font-size: 10px; }
          td { padding: 5px 8px; border-bottom: 0.5px solid #e2e8f0; }
          tr:nth-child(even) { background: #f8fafc; }
          @page { margin: 12mm; size: A4 landscape; }
        </style>
      </head>
      <body>${content}</body>
    </html>
  `);
  printWindow.document.close();
  printWindow.print();
}

function downloadFile(content: string, filename: string, mimeType: string) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
