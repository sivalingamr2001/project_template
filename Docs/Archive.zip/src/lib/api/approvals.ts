import { MOCK_APPROVALS } from '@/lib/mock/data';
import type { ApprovalItem } from '@/lib/types/approval.types';
import type { RejectionReason } from '@/lib/types/approval.types';
import { formatPendingDuration } from '@/lib/utils/date';

export interface ApprovalFilters {
  vendor: string;
  category: string;
  status: string;
  dateFrom: string;
  dateTo: string;
}

let approvalsStore = [...MOCK_APPROVALS];

export async function fetchApprovals(filters: ApprovalFilters): Promise<ApprovalItem[]> {
  await delay(300);
  return approvalsStore
    .filter((a) => {
      if (filters.status && filters.status !== 'all' && a.status !== filters.status) return false;
      if (filters.vendor && !a.vendorName.toLowerCase().includes(filters.vendor.toLowerCase())) return false;
      if (filters.category && a.category !== filters.category) return false;
      return true;
    })
    .map((a) => ({
      ...a,
      pendingDuration: a.status === 'pending' ? formatPendingDuration(a.submittedAt) : a.pendingDuration,
    }));
}

export async function fetchPendingCount(): Promise<number> {
  await delay(100);
  return approvalsStore.filter((a) => a.status === 'pending').length;
}

export async function approveRequest(requestId: string, remarks: string): Promise<void> {
  await delay(400);
  approvalsStore = approvalsStore.map((a) =>
    a.requestId === requestId
      ? {
          ...a,
          status: 'approved' as const,
          approvedAt: new Date().toISOString(),
          approvedBy: 'Shiva Kumar',
          approvalRemarks: remarks,
        }
      : a
  );
}

export async function rejectRequest(
  requestId: string,
  reason: RejectionReason,
  remarks: string
): Promise<void> {
  await delay(400);
  approvalsStore = approvalsStore.map((a) =>
    a.requestId === requestId
      ? {
          ...a,
          status: 'rejected' as const,
          rejectionReason: reason,
          rejectionRemarks: remarks,
        }
      : a
  );
}

export async function bulkApprove(requestIds: string[], remarks: string): Promise<void> {
  await delay(500);
  for (const id of requestIds) {
    await approveRequest(id, remarks);
  }
}

export async function bulkReject(
  requestIds: string[],
  reason: RejectionReason,
  remarks: string
): Promise<void> {
  await delay(500);
  for (const id of requestIds) {
    await rejectRequest(id, reason, remarks);
  }
}

function delay(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}
