import { useQuery } from '@tanstack/react-query';
import { MOCK_VENDORS, MOCK_VENDOR_ITEMS } from '@/lib/mock/data';
import type { Vendor, VendorItem } from '@/lib/types/vendor.types';

export async function fetchVendors(search?: string): Promise<Vendor[]> {
  await delay(200);
  if (!search) return MOCK_VENDORS;
  const q = search.toLowerCase();
  return MOCK_VENDORS.filter(
    (v) =>
      v.name.toLowerCase().includes(q) ||
      v.code.toLowerCase().includes(q) ||
      v.city.toLowerCase().includes(q)
  );
}

export async function fetchVendorById(id: string): Promise<Vendor | undefined> {
  await delay(100);
  return MOCK_VENDORS.find((v) => v.id === id);
}

export async function fetchVendorItems(vendorId: string): Promise<VendorItem[]> {
  await delay(150);
  return MOCK_VENDOR_ITEMS[vendorId] ?? [];
}

export function useVendors(search?: string) {
  return useQuery({
    queryKey: ['vendors', search],
    queryFn: () => fetchVendors(search),
  });
}

export function useVendor(id: string) {
  return useQuery({
    queryKey: ['vendor', id],
    queryFn: () => fetchVendorById(id),
    enabled: !!id,
  });
}

export function useVendorItems(vendorId: string) {
  return useQuery({
    queryKey: ['vendor-items', vendorId],
    queryFn: () => fetchVendorItems(vendorId),
    enabled: !!vendorId,
  });
}

function delay(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}
