import { MOCK_AUDIT_LOG } from '@/lib/mock/data';
import type { AuditLogEntry } from '@/lib/types/report.types';
import type { ReportFilters } from '@/lib/types/report.types';

export async function fetchAuditLog(filters: ReportFilters): Promise<AuditLogEntry[]> {
  await delay(300);
  return MOCK_AUDIT_LOG.filter((entry) => {
    if (filters.vendor && !entry.vendorName.toLowerCase().includes(filters.vendor.toLowerCase()))
      return false;
    if (filters.status && filters.status !== 'all' && entry.status !== filters.status) return false;
    if (filters.category && entry.category !== filters.category) return false;
    return true;
  });
}

function delay(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}
