import { z } from 'zod';
import { addMonths, format } from 'date-fns';

export const itemEntrySchema = z
  .object({
    itemCode: z.string().min(1, 'Select an item code'),
    itemName: z.string().min(1, 'Item name is required'),
    category: z.string().min(1, 'Category required'),
    certificationDate: z
      .string()
      .min(1, 'Select a certification date')
      .refine((d) => new Date(d) >= new Date(new Date().toDateString()), {
        message: 'Certification date cannot be in the past',
      }),
    remarks: z
      .string()
      .min(20, 'Remarks must be at least 20 characters')
      .max(500, 'Remarks cannot exceed 500 characters'),
  })
  .transform((data) => ({
    ...data,
    certificationExpiry: format(
      addMonths(new Date(data.certificationDate), 12),
      'yyyy-MM-dd'
    ),
  }));

export const bulkUploadRowSchema = z.object({
  ItemCode: z.string().min(1, 'Item code required'),
  ItemName: z.string().min(1, 'Item name required'),
  CertificationDate: z.string().min(1, 'Date required'),
  Remarks: z.string().min(20, 'Remarks must be at least 20 characters'),
});
