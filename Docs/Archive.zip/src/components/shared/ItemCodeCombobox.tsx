import { useState, useRef, useEffect } from 'react';
import { useVendorItems } from '@/lib/api/vendors';
import type { VendorItem, ItemCategory } from '@/lib/types/vendor.types';
import { Search, CheckCircle2 } from 'lucide-react';
interface ItemCodeComboboxProps {
  vendorId: string;
  value: string;
  onSelect: (item: VendorItem) => void;
  existingCodes: string[];
}

export function ItemCodeCombobox({
  vendorId,
  value,
  onSelect,
  existingCodes,
}: ItemCodeComboboxProps) {
  const [search, setSearch] = useState('');
  const [open, setOpen] = useState(false);
  const { data: items = [] } = useVendorItems(vendorId);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const filtered = items.filter(
    (i) =>
      !existingCodes.includes(i.code) &&
      (i.code.toLowerCase().includes(search.toLowerCase()) ||
        i.name.toLowerCase().includes(search.toLowerCase()))
  );

  const grouped = filtered.reduce<Record<string, VendorItem[]>>((acc, item) => {
    const cat = item.category;
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(item);
    return acc;
  }, {});

  const selected = items.find((i) => i.code === value);

  return (
    <div ref={ref} className="relative">
      <label className="text-sm font-medium text-slate-700 mb-1.5 block">Item Code</label>
      <div className="relative">
        <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          value={open ? search : (selected?.code ?? '')}
          onChange={(e) => {
            setSearch(e.target.value);
            setOpen(true);
          }}
          onFocus={() => setOpen(true)}
          placeholder="Search item code..."
          className="w-full pl-9 pr-3 py-2.5 border border-slate-300 rounded-lg text-sm"
        />
      </div>
      {open && (
        <div className="absolute z-50 w-full mt-1 bg-white border border-slate-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
          {Object.entries(grouped).map(([category, catItems]) => (
            <div key={category}>
              <p className="px-3 py-1.5 text-xs font-semibold text-slate-400 bg-slate-50 sticky top-0">
                {category as ItemCategory}
              </p>
              {catItems.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    onSelect(item);
                    setOpen(false);
                    setSearch('');
                  }}
                  className="w-full px-3 py-2 text-left hover:bg-blue-50 flex items-center gap-2"
                >
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-mono font-medium text-slate-800">{item.code}</p>
                    <p className="text-xs text-slate-500 truncate">{item.name}</p>
                  </div>
                  {item.isCertified && (
                    <CheckCircle2 size={14} className="text-emerald-500 shrink-0" />
                  )}
                </button>
              ))}
            </div>
          ))}
          {filtered.length === 0 && (
            <p className="px-3 py-4 text-sm text-slate-500 text-center">No items found</p>
          )}
        </div>
      )}
    </div>
  );
}

