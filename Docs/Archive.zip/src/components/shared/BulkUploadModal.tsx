import { useState, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { parseAndValidateBulkUpload, downloadBulkUploadTemplate } from '@/lib/utils/sheetjs';
import { Upload, FileSpreadsheet, AlertCircle, Download } from 'lucide-react';
import { addMonths, format } from 'date-fns';
import type { CertificationItem } from '@/lib/types/certification.types';
import type { BulkUploadRow } from '@/lib/types/certification.types';
import type { ItemCategory } from '@/lib/types/vendor.types';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils/cn';

type UploadStep = 'select' | 'preview' | 'processing' | 'complete';

interface BulkUploadModalProps {
  open: boolean;
  onClose: () => void;
  vendorId: string;
  onUploadComplete: (items: CertificationItem[]) => void;
}

export function BulkUploadModal({
  open,
  onClose,
  vendorId,
  onUploadComplete,
}: BulkUploadModalProps) {
  const [step, setStep] = useState<UploadStep>('select');
  const [rows, setRows] = useState<BulkUploadRow[]>([]);
  const [fileName, setFileName] = useState('');

  const reset = () => {
    setStep('select');
    setRows([]);
    setFileName('');
  };

  const handleClose = () => {
    reset();
    onClose();
  };

  const handleFile = useCallback(async (file: File) => {
    if (file.size > 5 * 1024 * 1024) {
      alert('File must be under 5 MB');
      return;
    }
    setFileName(file.name);
    const buffer = await file.arrayBuffer();
    const parsed = parseAndValidateBulkUpload(buffer);
    setRows(parsed);
    setStep('preview');
  }, []);

  const validRows = rows.filter((r) => r._isValid);
  const invalidRows = rows.filter((r) => !r._isValid);

  const handleImport = async () => {
    setStep('processing');
    await new Promise((r) => setTimeout(r, 800));
    const items: CertificationItem[] = validRows.map((r) => ({
      itemCode: r.itemCode,
      itemName: r.itemName,
      category: 'Other' as ItemCategory,
      certificationDate: r.certificationDate,
      certificationExpiry: format(addMonths(new Date(r.certificationDate), 12), 'yyyy-MM-dd'),
      remarks: r.remarks,
    }));
    onUploadComplete(items);
    setStep('complete');
    setTimeout(handleClose, 500);
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && handleClose()}>
      <DialogContent className="sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>Bulk Upload from Excel</DialogTitle>
        </DialogHeader>

        {step === 'select' && (
          <div className="space-y-4">
            <div
              className="border-2 border-dashed border-slate-300 rounded-xl p-8 text-center hover:border-blue-400 transition-colors"
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                const file = e.dataTransfer.files[0];
                if (file) handleFile(file);
              }}
            >
              <Upload size={32} className="mx-auto text-slate-400 mb-3" />
              <p className="text-sm text-slate-600">Drag & drop .xlsx or .csv file</p>
              <p className="text-xs text-slate-400 mt-1">Max 5 MB</p>
              <label className="mt-4 inline-block">
                <input
                  type="file"
                  accept=".xlsx,.csv"
                  className="hidden"
                  onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
                />
                <span className="btn-primary cursor-pointer inline-flex items-center gap-2 px-4 py-2">
                  <FileSpreadsheet size={16} />
                  Choose File
                </span>
              </label>
            </div>
            <button
              type="button"
              onClick={downloadBulkUploadTemplate}
              className="flex items-center gap-2 text-sm text-blue-600 hover:text-blue-700"
            >
              <Download size={14} />
              Download Template
            </button>
          </div>
        )}

        {step === 'preview' && (
          <div className="space-y-4">
            <p className="text-sm text-slate-600">
              <span className="font-medium">{fileName}</span> — {rows.length} rows
            </p>
            <div
              className={cn(
                'flex items-center gap-2 px-3 py-2 rounded-lg text-sm',
                invalidRows.length > 0 ? 'bg-amber-50 text-amber-800' : 'bg-emerald-50 text-emerald-800'
              )}
            >
              <AlertCircle size={16} />
              {validRows.length} valid / {invalidRows.length} invalid — invalid rows will be skipped
            </div>
            <div className="overflow-x-auto max-h-48 border border-slate-200 rounded-lg">
              <table className="w-full text-xs">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="px-3 py-2 text-left">Row</th>
                    <th className="px-3 py-2 text-left">Item Code</th>
                    <th className="px-3 py-2 text-left">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.slice(0, 5).map((r) => (
                    <tr key={r._rowIndex} className={!r._isValid ? 'bg-red-50' : ''}>
                      <td className="px-3 py-2">{r._rowIndex}</td>
                      <td className="px-3 py-2 font-mono">{r.itemCode || '—'}</td>
                      <td className="px-3 py-2">
                        {r._isValid ? (
                          <span className="text-emerald-600">Valid</span>
                        ) : (
                          <span className="text-red-600">{r._errors.join(', ')}</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="flex gap-3 justify-end">
              <Button variant="outline" onClick={reset}>
                Back
              </Button>
              <Button onClick={handleImport} disabled={validRows.length === 0}>
                Import {validRows.length} Items
              </Button>
            </div>
          </div>
        )}

        {step === 'processing' && (
          <div className="py-8 text-center">
            <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
              <div className="bg-blue-600 h-2 rounded-full animate-pulse w-3/4" />
            </div>
            <p className="text-sm text-slate-600 mt-4">Processing upload for vendor {vendorId}...</p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

