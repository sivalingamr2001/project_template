import { Clock, CheckCircle2, XCircle, AlertCircle, Timer } from 'lucide-react';
import { cn } from '@/lib/utils/cn';

type Status = 'pending' | 'approved' | 'rejected' | 'expired' | 'draft';

const STATUS_CONFIG: Record<
  Status,
  { label: string; icon: React.ComponentType<{ size?: number; className?: string }>; className: string }
> = {
  pending: { label: 'Pending', icon: Clock, className: 'bg-orange-50 text-orange-700 border-orange-200' },
  approved: { label: 'Approved', icon: CheckCircle2, className: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
  rejected: { label: 'Rejected', icon: XCircle, className: 'bg-red-50 text-red-700 border-red-200' },
  expired: { label: 'Expired', icon: Timer, className: 'bg-slate-100 text-slate-600 border-slate-200' },
  draft: { label: 'Draft', icon: AlertCircle, className: 'bg-blue-50 text-blue-700 border-blue-200' },
};

export function StatusBadge({ status }: { status: Status }) {
  const { label, icon: Icon, className } = STATUS_CONFIG[status];
  return (
    <span
      role="status"
      aria-label={label}
      className={cn('inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border', className)}
    >
      <Icon size={12} aria-hidden="true" />
      {label}
    </span>
  );
}
