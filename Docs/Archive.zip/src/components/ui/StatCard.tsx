import { cn } from '@/lib/utils/cn';
import { useNavigate } from 'react-router-dom';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface StatCardProps {
  label: string;
  value: string | number;
  color: string;
  bgColor: string;
  to?: string;
  pulse?: boolean;
  trend?: number;
  suffix?: string;
}

export function StatCard({
  label,
  value,
  color,
  bgColor,
  to,
  pulse,
  trend,
  suffix,
}: StatCardProps) {
  const navigate = useNavigate();

  return (
    <button
      type="button"
      onClick={() => to && navigate(to)}
      className={cn(
        'card p-5 text-left w-full transition-shadow hover:shadow-md',
        to && 'cursor-pointer',
        pulse && 'ring-2 ring-orange-200'
      )}
    >
      <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">{label}</p>
      <div className="flex items-end justify-between mt-2">
        <p className={cn('text-3xl font-bold tabular-nums', color)}>
          {value}
          {suffix && <span className="text-lg ml-0.5">{suffix}</span>}
        </p>
        {trend !== undefined && (
          <span
            className={cn(
              'flex items-center gap-0.5 text-xs font-medium px-2 py-1 rounded-full',
              bgColor,
              trend >= 0 ? 'text-emerald-600' : 'text-red-600'
            )}
          >
            {trend >= 0 ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
            {Math.abs(trend)}%
          </span>
        )}
      </div>
    </button>
  );
}
