import { Outlet, NavLink, useLocation } from 'react-router-dom';
import { useState } from 'react';
import {
  LayoutDashboard,
  ClipboardCheck,
  CheckSquare,
  BarChart3,
  ScrollText,
  Menu,
  X,
  Bell,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { cn } from '@/lib/utils/cn';
import { useApprovalCount } from '@/features/approvals/hooks/useApprovals';

const NAV_ITEMS = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/certifications', label: 'Certifications', icon: ClipboardCheck },
  { to: '/approvals', label: 'Approvals', icon: CheckSquare, badge: true },
  { to: '/reports', label: 'Reports', icon: BarChart3 },
  { to: '/audit', label: 'Audit Trail', icon: ScrollText },
];

export function AppShell() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { data: pendingCount = 0 } = useApprovalCount();
  const location = useLocation();

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      <aside
        className={cn(
          'hidden lg:flex flex-col bg-white border-r border-slate-200',
          'transition-all duration-300 ease-in-out',
          sidebarOpen ? 'w-60' : 'w-16'
        )}
      >
        <div className="flex items-center justify-between px-4 py-5 border-b border-slate-100">
          {sidebarOpen && (
            <div>
              <span className="text-sm font-bold text-blue-700 tracking-tight">JANATICS</span>
              <p className="text-[10px] text-slate-400 mt-0.5 uppercase tracking-widest">Green Channel</p>
            </div>
          )}
          <button
            type="button"
            onClick={() => setSidebarOpen((prev) => !prev)}
            className="p-1.5 rounded-md hover:bg-slate-100 text-slate-500 transition-colors ml-auto"
            aria-label={sidebarOpen ? 'Collapse sidebar' : 'Expand sidebar'}
          >
            {sidebarOpen ? <ChevronLeft size={16} /> : <ChevronRight size={16} />}
          </button>
        </div>

        <nav className="flex-1 px-2 py-4 space-y-0.5 overflow-y-auto">
          {NAV_ITEMS.map(({ to, label, icon: Icon, badge }) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium',
                  'transition-all duration-150 relative group',
                  isActive
                    ? 'bg-blue-50 text-blue-700'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                )
              }
            >
              {({ isActive }) => (
                <>
                  <Icon
                    size={18}
                    className={cn(
                      isActive ? 'text-blue-600' : 'text-slate-400 group-hover:text-slate-600'
                    )}
                  />
                  {sidebarOpen && <span className="flex-1">{label}</span>}
                  {badge && pendingCount > 0 && sidebarOpen && (
                    <span className="bg-orange-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full min-w-[18px] text-center">
                      {pendingCount > 99 ? '99+' : pendingCount}
                    </span>
                  )}
                  {badge && pendingCount > 0 && !sidebarOpen && (
                    <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-orange-500 rounded-full" />
                  )}
                  {!sidebarOpen && (
                    <span className="absolute left-full ml-2 px-2 py-1 bg-slate-900 text-white text-xs rounded-md opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 transition-opacity">
                      {label}
                    </span>
                  )}
                </>
              )}
            </NavLink>
          ))}
        </nav>

        {sidebarOpen && (
          <div className="px-3 py-4 border-t border-slate-100">
            <div className="flex items-center gap-3 px-2 py-2 rounded-lg hover:bg-slate-50 cursor-pointer">
              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white text-xs font-bold shrink-0">
                SK
              </div>
              <div className="min-w-0">
                <p className="text-sm font-medium text-slate-800 truncate">Shiva Kumar</p>
                <p className="text-xs text-slate-500 truncate">Admin • Compliance Officer</p>
              </div>
            </div>
          </div>
        )}
      </aside>

      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header className="bg-white border-b border-slate-200 px-4 lg:px-6 py-3 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <button
              type="button"
              className="lg:hidden p-2 rounded-md hover:bg-slate-100 text-slate-500"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Open menu"
            >
              <Menu size={20} />
            </button>
            <div className="hidden lg:block">
              <BreadcrumbDisplay pathname={location.pathname} />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <NotificationBell count={pendingCount} />
            <div className="hidden sm:flex items-center gap-2 pl-2 border-l border-slate-200">
              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white text-xs font-bold">
                SK
              </div>
              <span className="text-sm font-medium text-slate-700 hidden md:block">Shiva Kumar</span>
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto pb-16 lg:pb-0">
          <Outlet />
        </main>
      </div>

      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-50">
          <div
            className="absolute inset-0 bg-black/40 backdrop-blur-sm"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="absolute left-0 top-0 bottom-0 w-72 bg-white shadow-2xl flex flex-col">
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
              <div>
                <span className="text-sm font-bold text-blue-700">JANATICS</span>
                <p className="text-[10px] text-slate-400 uppercase tracking-widest">
                  Green Channel Initiative
                </p>
              </div>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                className="p-1.5 rounded-md hover:bg-slate-100"
              >
                <X size={18} className="text-slate-500" />
              </button>
            </div>
            <nav className="flex-1 px-3 py-4 space-y-0.5">
              {NAV_ITEMS.map(({ to, label, icon: Icon, badge }) => (
                <NavLink
                  key={to}
                  to={to}
                  onClick={() => setMobileMenuOpen(false)}
                  className={({ isActive }) =>
                    cn(
                      'flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors',
                      isActive ? 'bg-blue-50 text-blue-700' : 'text-slate-600 hover:bg-slate-50'
                    )
                  }
                >
                  {({ isActive }) => (
                    <>
                      <Icon size={20} className={isActive ? 'text-blue-600' : 'text-slate-400'} />
                      <span className="flex-1">{label}</span>
                      {badge && pendingCount > 0 && (
                        <span className="bg-orange-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">
                          {pendingCount}
                        </span>
                      )}
                    </>
                  )}
                </NavLink>
              ))}
            </nav>
            <div className="px-4 py-4 border-t border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 bg-blue-600 rounded-full flex items-center justify-center text-white text-xs font-bold">
                  SK
                </div>
                <div>
                  <p className="text-sm font-semibold text-slate-800">Shiva Kumar</p>
                  <p className="text-xs text-slate-500">Admin · Compliance Officer</p>
                </div>
              </div>
            </div>
          </aside>
        </div>
      )}

      <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 flex z-40 safe-area-pb">
        {NAV_ITEMS.map(({ to, label, icon: Icon, badge }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              cn(
                'flex-1 flex flex-col items-center justify-center py-2.5 gap-0.5 text-[10px] font-medium relative min-h-0 min-w-0',
                isActive ? 'text-blue-600' : 'text-slate-500'
              )
            }
          >
            {({ isActive }) => (
              <>
                <div className="relative">
                  <Icon size={20} />
                  {badge && pendingCount > 0 && (
                    <span className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-orange-500 rounded-full text-[8px] text-white flex items-center justify-center font-bold">
                      {pendingCount > 9 ? '9+' : pendingCount}
                    </span>
                  )}
                </div>
                <span className={isActive ? 'text-blue-600' : ''}>{label.split(' ')[0]}</span>
              </>
            )}
          </NavLink>
        ))}
      </nav>
    </div>
  );
}

function BreadcrumbDisplay({ pathname }: { pathname: string }) {
  const segments = pathname.split('/').filter(Boolean);
  const labels: Record<string, string> = {
    dashboard: 'Dashboard',
    certifications: 'Certifications',
    preview: 'Preview',
    approvals: 'Approvals',
    reports: 'Reports',
    audit: 'Audit Trail',
  };
  return (
    <nav className="text-sm text-slate-500">
      <span className="text-slate-400">Home</span>
      {segments.map((seg) => (
        <span key={seg}>
          <span className="mx-1.5 text-slate-300">/</span>
          <span className="text-slate-700 font-medium">{labels[seg] ?? seg}</span>
        </span>
      ))}
    </nav>
  );
}

function NotificationBell({ count }: { count: number }) {
  return (
    <button
      type="button"
      className="relative p-2 rounded-md hover:bg-slate-100 text-slate-500"
      aria-label={`Notifications${count > 0 ? `, ${count} pending` : ''}`}
    >
      <Bell size={20} />
      {count > 0 && (
        <span className="absolute top-1 right-1 w-2 h-2 bg-orange-500 rounded-full" />
      )}
    </button>
  );
}

