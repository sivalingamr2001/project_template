import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import type { CertificationDraft, CertificationItem } from '@/lib/types/certification.types';
import type { Vendor } from '@/lib/types/vendor.types';

interface CertificationStore {
  draft: CertificationDraft;
  setVendor: (vendor: Vendor) => void;
  addItem: (item: CertificationItem) => void;
  updateItem: (itemCode: string, updates: Partial<CertificationItem>) => void;
  removeItem: (itemCode: string) => void;
  clearDraft: () => void;
  draftAge: () => number;
}

const EMPTY_DRAFT: CertificationDraft = {
  vendorId: '',
  vendorCode: '',
  vendorName: '',
  items: [],
  createdAt: '',
  isDirty: false,
};

export const useCertificationStore = create<CertificationStore>()(
  persist(
    (set, get) => ({
      draft: EMPTY_DRAFT,

      setVendor: (vendor) =>
        set({
          draft: {
            ...EMPTY_DRAFT,
            vendorId: vendor.id,
            vendorCode: vendor.code,
            vendorName: vendor.name,
            createdAt: new Date().toISOString(),
            isDirty: true,
            items: [],
          },
        }),

      addItem: (item) =>
        set((state) => ({
          draft: {
            ...state.draft,
            items: [...state.draft.items.filter((i) => i.itemCode !== item.itemCode), item],
            isDirty: true,
          },
        })),

      updateItem: (itemCode, updates) =>
        set((state) => ({
          draft: {
            ...state.draft,
            items: state.draft.items.map((i) =>
              i.itemCode === itemCode ? { ...i, ...updates } : i
            ),
            isDirty: true,
          },
        })),

      removeItem: (itemCode) =>
        set((state) => ({
          draft: {
            ...state.draft,
            items: state.draft.items.filter((i) => i.itemCode !== itemCode),
            isDirty: true,
          },
        })),

      clearDraft: () => set({ draft: EMPTY_DRAFT }),

      draftAge: () => {
        const { draft } = get();
        if (!draft.createdAt) return 0;
        return Date.now() - new Date(draft.createdAt).getTime();
      },
    }),
    {
      name: 'janatics-gcc-draft',
      storage: createJSONStorage(() => localStorage),
      onRehydrateStorage: () => (state) => {
        if (state?.draft.createdAt) {
          const age = Date.now() - new Date(state.draft.createdAt).getTime();
          if (age > 24 * 60 * 60 * 1000) {
            state.clearDraft();
          }
        }
      },
    }
  )
);
