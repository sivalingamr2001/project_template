export const mockBudgetData = [
  {
    id: 'budget-001',
    projectCode: 'PROJ-DUMMY',
    projectName: 'Sample R&D Project (Dummy Data)',
    productName: 'DUMMY-123',
    status: 'ON TRACK' as const,
    totalBudget: 650000,
    actualSpent: 595000,
    phase: 'Product development',
    department: 'Research and Development',
    lastUpdated: '2026-04-12',
    budgetId: 0,
    fiscalYear: 'FY 2025-26',
    lineItems: [
      {
        id: 'li-001',
        category: 'Product Design',
        name: 'Benchmarking sample',
        planned: 50000,
        actual: 45000,
      },
      {
        id: 'li-002',
        category: 'Product Design',
        name: 'FEA Analysis',
        planned: 120000,
        actual: 125000,
      },
      {
        id: 'li-003',
        category: 'Product Design',
        name: 'CFD Analysis',
        planned: 80000,
        actual: 0,
      },
      {
        id: 'li-004',
        category: 'Concept devpt.',
        name: '3D printing',
        planned: 35000,
        actual: 38000,
      },
      {
        id: 'li-005',
        category: 'Concept devpt.',
        name: 'Jigs & fixtures',
        planned: 95000,
        actual: 92000,
      },
      {
        id: 'li-006',
        category: 'Prototype devpt.',
        name: 'Machining components',
        planned: 250000,
        actual: 240000,
      },
      {
        id: 'li-007',
        category: 'Prototype devpt.',
        name: 'Testing',
        planned: 60000,
        actual: 55000,
      },
    ],
  },
  {
    id: 'budget-002',
    projectCode: 'NPD-2025-08',
    projectName: 'Advanced Hydraulic Pump System',
    productName: 'AHP-2000-X',
    status: 'AT RISK' as const,
    totalBudget: 62000,
    actualSpent: 58900,
    phase: 'Prototype development',
    department: 'Engineering',
    lastUpdated: '2026-03-28',
    budgetId: 1,
    fiscalYear: 'FY 2025-26',
    lineItems: [],
  },
  {
    id: 'budget-003',
    projectCode: 'NPD-2025-09',
    projectName: 'Smart Valve Controller',
    productName: 'SVC-IOT-01',
    status: 'ON TRACK' as const,
    totalBudget: 38000,
    actualSpent: 18500,
    phase: 'Concept development',
    department: 'R&D',
    lastUpdated: '2026-03-29',
    budgetId: 2,
    fiscalYear: 'FY 2025-26',
    lineItems: [],
  },
  {
    id: 'budget-004',
    projectCode: 'NPD-2025-10',
    projectName: 'Compact Pressure Regulator',
    productName: 'CPR-500-V',
    status: 'COMPLETED' as const,
    totalBudget: 28000,
    actualSpent: 27600,
    phase: 'Product testing',
    department: 'Quality Assurance',
    lastUpdated: '2026-03-15',
    budgetId: 3,
    fiscalYear: 'FY 2025-26',
    lineItems: [],
  },
];

export function getVariancePercentage(actual: number, planned: number): number {
  if (planned === 0) return 0;
  return ((actual - planned) / planned) * 100;
}

export function getStatusVariance(actual: number, planned: number): 'under' | 'on-track' | 'over' {
  const variance = getVariancePercentage(actual, planned);
  if (variance < -5) return 'under';
  if (variance > 5) return 'over';
  return 'on-track';
}
