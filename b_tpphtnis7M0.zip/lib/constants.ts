import { TrendingUp, TrendingDown, Zap, Clock } from 'lucide-react';

export const SUMMARY_CARDS = [
  {
    id: 'total-projects',
    label: 'Total Projects',
    value: 4,
    icon: Zap,
    color: 'from-blue-500 to-blue-600',
  },
  {
    id: 'active-budgets',
    label: 'Active Budgets',
    value: 3,
    icon: Clock,
    color: 'from-green-500 to-green-600',
  },
  {
    id: 'pending-approvals',
    label: 'Pending Approvals',
    value: 1,
    icon: TrendingUp,
    color: 'from-amber-500 to-amber-600',
  },
  {
    id: 'total-budget-value',
    label: 'Total Budget Value',
    value: '$173,000',
    icon: TrendingDown,
    color: 'from-purple-500 to-purple-600',
  },
];

export const TABLE_COLUMNS = [
  { key: 'projectCode', label: 'Project Code', width: 'w-24' },
  { key: 'projectName', label: 'Project Name', width: 'w-40' },
  { key: 'productName', label: 'Product Name', width: 'w-32' },
  { key: 'totalBudget', label: 'Budget Amount', width: 'w-28' },
  { key: 'status', label: 'Status', width: 'w-24' },
  { key: 'actions', label: 'Actions', width: 'w-20' },
];
