interface BudgetHeaderProps {
  projectName: string;
  projectCode: string;
  budgetId: number;
  fiscalYear: string;
  lastSaved?: string;
}

export function BudgetDetailHeader({
  projectName,
  projectCode,
  budgetId,
  fiscalYear,
  lastSaved,
}: BudgetHeaderProps) {
  return (
    <div className="border-b border-border bg-background">
      <div className="max-w-7xl mx-auto px-6 py-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold mb-1">{projectName}</h1>
            <p className="text-sm text-muted-foreground">
              Project: {projectCode} | Budget ID: {budgetId} | {fiscalYear}
            </p>
          </div>
          {lastSaved && (
            <div className="text-right text-xs text-muted-foreground">
              <p>Last saved</p>
              <p className="font-medium">{lastSaved}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
