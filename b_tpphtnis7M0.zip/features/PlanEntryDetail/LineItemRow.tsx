import { LineItem } from './hooks/useBudgetDetail';

interface LineItemRowProps {
  item: LineItem;
  onActualChange: (value: number) => void;
  isSubtotal?: boolean;
  isTotal?: boolean;
}

export function LineItemRow({
  item,
  onActualChange,
  isSubtotal = false,
  isTotal = false,
}: LineItemRowProps) {
  const variance = item.actual - item.planned;
  const varPercentage = item.planned === 0 ? 0 : ((variance / item.planned) * 100).toFixed(1);

  const baseClass = isTotal
    ? 'bg-muted/50 font-bold text-foreground'
    : isSubtotal
      ? 'bg-muted/25 font-semibold'
      : 'border-b border-border/50';

  return (
    <tr className={baseClass}>
      <td className="px-6 py-3 text-sm">{item.name}</td>
      <td className="px-6 py-3 text-right">
        <div className="flex items-center justify-end gap-1">
          <span className="text-xs text-muted-foreground">Rs.</span>
          <span className="font-mono">{item.planned.toLocaleString()}</span>
        </div>
      </td>
      <td className="px-6 py-3 text-right">
        <div className="flex items-center justify-end gap-2">
          <span className="text-xs text-muted-foreground">Rs.</span>
          <input
            type="number"
            value={item.actual}
            onChange={(e) => onActualChange(Number(e.target.value))}
            className="w-24 px-2 py-1 text-sm text-right border border-border rounded bg-background hover:bg-muted/50 focus:outline-none focus:ring-1 focus:ring-primary"
            disabled={isSubtotal || isTotal}
          />
        </div>
      </td>
      <td className="px-6 py-3 text-right">
        <div className="flex items-center justify-end gap-1">
          <span className="text-xs text-muted-foreground">Rs.</span>
          <span className={`font-mono ${variance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
            {variance >= 0 ? '+' : ''}{variance.toLocaleString()}
          </span>
        </div>
      </td>
      <td className={`px-6 py-3 text-right font-mono text-sm ${variance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
        {variance >= 0 ? '+' : ''}{varPercentage}%
      </td>
    </tr>
  );
}
