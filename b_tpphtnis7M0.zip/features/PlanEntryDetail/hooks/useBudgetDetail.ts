import { useState } from 'react';

export interface LineItem {
  id: string;
  category: string;
  name: string;
  planned: number;
  actual: number;
}

export interface UseBudgetDetailReturn {
  lineItems: LineItem[];
  updateLineItem: (id: string, actual: number) => void;
  calculateSubtotals: (category: string) => { planned: number; actual: number };
  calculateTotal: () => { planned: number; actual: number };
}

export function useBudgetDetail(initialItems: LineItem[]): UseBudgetDetailReturn {
  const [lineItems, setLineItems] = useState<LineItem[]>(initialItems);

  const updateLineItem = (id: string, actual: number) => {
    setLineItems((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, actual } : item
      )
    );
  };

  const calculateSubtotals = (category: string) => {
    return lineItems
      .filter((item) => item.category === category)
      .reduce(
        (acc, item) => ({
          planned: acc.planned + item.planned,
          actual: acc.actual + item.actual,
        }),
        { planned: 0, actual: 0 }
      );
  };

  const calculateTotal = () => {
    return lineItems.reduce(
      (acc, item) => ({
        planned: acc.planned + item.planned,
        actual: acc.actual + item.actual,
      }),
      { planned: 0, actual: 0 }
    );
  };

  return {
    lineItems,
    updateLineItem,
    calculateSubtotals,
    calculateTotal,
  };
}
