import { LineItem } from './hooks/useBudgetDetail';
import { LineItemRow } from './LineItemRow';

interface BudgetTableProps {
  lineItems: LineItem[];
  onUpdateLineItem: (id: string, actual: number) => void;
  calculateSubtotals: (category: string) => { planned: number; actual: number };
  calculateTotal: () => { planned: number; actual: number };
}

export function BudgetTable({
  lineItems,
  onUpdateLineItem,
  calculateSubtotals,
  calculateTotal,
}: BudgetTableProps) {
  const categories = Array.from(new Set(lineItems.map((item) => item.category)));
  const total = calculateTotal();

  return (
    <div className="bg-background rounded-lg border border-border overflow-hidden">
      <table className="w-full">
        <thead>
          <tr className="border-b border-border bg-muted/30">
            <th className="px-6 py-4 text-left text-sm font-semibold">Cost Item</th>
            <th className="px-6 py-4 text-right text-sm font-semibold">Planned (INR)</th>
            <th className="px-6 py-4 text-right text-sm font-semibold">Actual (INR)</th>
            <th className="px-6 py-4 text-right text-sm font-semibold">Variance</th>
            <th className="px-6 py-4 text-right text-sm font-semibold">Var %</th>
          </tr>
        </thead>
        <tbody>
          {categories.map((category) => {
            const categoryItems = lineItems.filter((item) => item.category === category);
            const subtotals = calculateSubtotals(category);

            return (
              <tbody key={category}>
                <tr className="bg-muted/5 font-semibold">
                  <td colSpan={5} className="px-6 py-3 text-sm">
                    {category}
                  </td>
                </tr>
                {categoryItems.map((item) => (
                  <LineItemRow
                    key={item.id}
                    item={item}
                    onActualChange={(value) => onUpdateLineItem(item.id, value)}
                  />
                ))}
                <LineItemRow
                  item={{
                    id: `${category}-subtotal`,
                    category,
                    name: `${category} subtotal`,
                    planned: subtotals.planned,
                    actual: subtotals.actual,
                  }}
                  onActualChange={() => {}}
                  isSubtotal
                />
              </tbody>
            );
          })}
          <LineItemRow
            item={{
              id: 'total',
              category: 'total',
              name: 'Total Cost, Rs.',
              planned: total.planned,
              actual: total.actual,
            }}
            onActualChange={() => {}}
            isTotal
          />
        </tbody>
      </table>
    </div>
  );
}
