import { Button } from '@/components/ui/button';
import { FileText, Save } from 'lucide-react';

interface ActionBarProps {
  onSave: () => void;
  onExport: () => void;
  isSaving?: boolean;
}

export function ActionBar({ onSave, onExport, isSaving = false }: ActionBarProps) {
  return (
    <div className="border-t border-border bg-background py-4">
      <div className="max-w-7xl mx-auto px-6 flex justify-end gap-3">
        <Button
          variant="outline"
          onClick={onExport}
          className="gap-2"
        >
          <FileText className="w-4 h-4" />
          Export CSV
        </Button>
        <Button
          onClick={onSave}
          disabled={isSaving}
          className="gap-2"
        >
          <Save className="w-4 h-4" />
          {isSaving ? 'Saving...' : 'Save'}
        </Button>
      </div>
    </div>
  );
}
