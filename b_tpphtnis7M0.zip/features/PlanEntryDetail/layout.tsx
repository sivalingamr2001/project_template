import { ReactNode } from 'react';

interface PlanEntryLayoutProps {
  children: ReactNode;
}

export function PlanEntryLayout({ children }: PlanEntryLayoutProps) {
  return (
    <div className="min-h-screen bg-background">
      {children}
    </div>
  );
}
