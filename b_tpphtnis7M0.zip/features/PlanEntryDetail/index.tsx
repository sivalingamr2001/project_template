'use client';

import { useState } from 'react';
import { useBudgetDetail } from './hooks/useBudgetDetail';
import { BudgetDetailHeader } from './BudgetDetailHeader';
import { PlanEntryTabs } from './PlanEntryTabs';
import { BudgetTable } from './BudgetTable';
import { ActionBar } from './ActionBar';

interface PlanEntryDetailProps {
  budget: {
    id: string;
    projectName: string;
    projectCode: string;
    budgetId: number;
    fiscalYear: string;
    lastUpdated: string;
    lineItems: Array<{
      id: string;
      category: string;
      name: string;
      planned: number;
      actual: number;
    }>;
  };
  onBack?: () => void;
}

export function PlanEntryDetail({ budget, onBack }: PlanEntryDetailProps) {
  const [activeTab, setActiveTab] = useState('budget-table');
  const [isSaving, setIsSaving] = useState(false);
  const { lineItems, updateLineItem, calculateSubtotals, calculateTotal } =
    useBudgetDetail(budget.lineItems);

  const handleSave = async () => {
    setIsSaving(true);
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 800));
    setIsSaving(false);
    // TODO: Show success toast
  };

  const handleExport = () => {
    // Generate CSV
    const headers = ['Cost Item', 'Planned (INR)', 'Actual (INR)', 'Variance', 'Var %'];
    const rows = lineItems.map((item) => {
      const variance = item.actual - item.planned;
      const varPercentage = item.planned === 0 ? 0 : ((variance / item.planned) * 100).toFixed(1);
      return [item.name, item.planned, item.actual, variance, varPercentage];
    });

    const csvContent = [headers, ...rows].map((row) => row.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${budget.projectCode}-budget.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-background">
      <BudgetDetailHeader
        projectName={budget.projectName}
        projectCode={budget.projectCode}
        budgetId={budget.budgetId}
        fiscalYear={budget.fiscalYear}
        lastSaved={budget.lastUpdated}
      />
      <PlanEntryTabs activeTab={activeTab} onTabChange={setActiveTab} />

      <div className="max-w-7xl mx-auto px-6 py-6">
        {activeTab === 'budget-table' && (
          <BudgetTable
            lineItems={lineItems}
            onUpdateLineItem={updateLineItem}
            calculateSubtotals={calculateSubtotals}
            calculateTotal={calculateTotal}
          />
        )}
        {activeTab === 'phase-timeline' && (
          <div className="text-center py-12 text-muted-foreground">
            Phase Timeline - Coming Soon
          </div>
        )}
        {activeTab === 'documents' && (
          <div className="text-center py-12 text-muted-foreground">
            Documents - Coming Soon
          </div>
        )}
      </div>

      <ActionBar onSave={handleSave} onExport={handleExport} isSaving={isSaving} />
    </div>
  );
}
