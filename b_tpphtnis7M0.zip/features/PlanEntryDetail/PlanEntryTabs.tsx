import { useState } from 'react';

interface TabsProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const TABS = [
  { id: 'budget-table', label: 'Budget Table' },
  { id: 'phase-timeline', label: 'Phase Timeline' },
  { id: 'documents', label: 'Documents' },
];

export function PlanEntryTabs({ activeTab, onTabChange }: TabsProps) {
  return (
    <div className="border-b border-border">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex gap-8">
          {TABS.map((tab) => (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`py-4 px-1 text-sm font-medium border-b-2 transition-colors ${
                activeTab === tab.id
                  ? 'border-primary text-primary'
                  : 'border-transparent text-muted-foreground hover:text-foreground'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
