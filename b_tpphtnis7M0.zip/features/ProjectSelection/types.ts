export interface Project {
  id: string;
  name: string;
  description: string;
  budget: number;
  currency: string;
  createdAt: Date;
}

export interface ProjectSelectionState {
  projects: Project[];
  selectedProjectId: string | null;
}
