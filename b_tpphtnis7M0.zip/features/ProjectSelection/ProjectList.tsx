'use client';

import { ProjectCard } from './ProjectCard';
import type { Project } from './types';

interface ProjectListProps {
  projects: Project[];
  selectedId: string | null;
  onSelectProject: (id: string) => void;
}

export function ProjectList({
  projects,
  selectedId,
  onSelectProject,
}: ProjectListProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {projects.map((project) => (
        <ProjectCard
          key={project.id}
          project={project}
          isSelected={selectedId === project.id}
          onSelect={onSelectProject}
        />
      ))}
    </div>
  );
}
