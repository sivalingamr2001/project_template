'use client';

import { ProjectList } from './ProjectList';
import type { Project } from './types';

interface ProjectSelectionProps {
  projects: Project[];
  selectedId: string | null;
  onSelectProject: (id: string) => void;
}

export default function ProjectSelection({
  projects,
  selectedId,
  onSelectProject,
}: ProjectSelectionProps) {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-balance">Select Project</h2>
        <p className="text-sm text-muted-foreground mt-1">
          Choose a project to view and manage its budget plans
        </p>
      </div>
      <ProjectList
        projects={projects}
        selectedId={selectedId}
        onSelectProject={onSelectProject}
      />
    </div>
  );
}
