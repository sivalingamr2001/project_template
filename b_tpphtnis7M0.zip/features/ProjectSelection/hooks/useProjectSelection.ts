import { useState, useCallback } from 'react';
import type { Project } from './types';

const MOCK_PROJECTS: Project[] = [
  {
    id: '1',
    name: 'Q1 Marketing Campaign',
    description: 'Digital marketing initiative',
    budget: 150000,
    currency: 'USD',
    createdAt: new Date('2024-01-15'),
  },
  {
    id: '2',
    name: 'Infrastructure Upgrade',
    description: 'Server and networking improvements',
    budget: 500000,
    currency: 'USD',
    createdAt: new Date('2024-01-20'),
  },
  {
    id: '3',
    name: 'Product Development',
    description: 'New feature implementation',
    budget: 250000,
    currency: 'USD',
    createdAt: new Date('2024-02-01'),
  },
];

export function useProjectSelection() {
  const [projects] = useState<Project[]>(MOCK_PROJECTS);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>('1');

  const selectProject = useCallback((projectId: string) => {
    setSelectedProjectId(projectId);
  }, []);

  const selectedProject = projects.find((p) => p.id === selectedProjectId);

  return {
    projects,
    selectedProject,
    selectedProjectId,
    selectProject,
  };
}
