import type { Project } from '../types';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

interface ProjectCardProps {
  project: Project;
  isSelected: boolean;
  onSelect: (id: string) => void;
}

export function ProjectCard({
  project,
  isSelected,
  onSelect,
}: ProjectCardProps) {
  return (
    <Card
      className={`p-4 cursor-pointer transition-all ${
        isSelected
          ? 'ring-2 ring-accent bg-accent/10'
          : 'hover:border-accent/50'
      }`}
      onClick={() => onSelect(project.id)}
    >
      <h3 className="font-semibold text-base text-balance">{project.name}</h3>
      <p className="text-sm text-muted-foreground mt-1">{project.description}</p>
      <div className="flex items-center justify-between mt-4">
        <span className="text-lg font-bold text-accent">
          {project.currency} {project.budget.toLocaleString()}
        </span>
        {isSelected && (
          <Button size="sm" className="bg-accent text-accent-foreground">
            Active
          </Button>
        )}
      </div>
    </Card>
  );
}
