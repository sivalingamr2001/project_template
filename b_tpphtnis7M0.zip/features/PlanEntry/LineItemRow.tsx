import { Input } from '@/components/ui/input';
import type { BudgetLineItem } from '../types';

interface LineItemRowProps {
  item: BudgetLineItem;
  onUpdateActual: (itemId: string, amount: number) => void;
}

export function LineItemRow({
  item,
  onUpdateActual,
}: LineItemRowProps) {
  const variance = (item.actualCost || 0) - item.estimatedCost;
  const isOverBudget = variance > 0;

  return (
    <div className="flex items-center gap-4 p-3 bg-card border border-border rounded-lg">
      <div className="flex-1">
        <p className="font-medium text-sm">{item.category}</p>
        <p className="text-xs text-muted-foreground">{item.description}</p>
      </div>

      <div className="flex items-center gap-3">
        <div className="text-right">
          <p className="text-xs text-muted-foreground">Est.</p>
          <p className="font-semibold">${item.estimatedCost.toLocaleString()}</p>
        </div>

        <Input
          type="number"
          placeholder="Actual"
          value={item.actualCost || ''}
          onChange={(e) => onUpdateActual(item.id, parseFloat(e.target.value) || 0)}
          className="w-32 text-right"
        />

        <div className={`text-right w-20 ${isOverBudget ? 'text-destructive' : 'text-accent'}`}>
          <p className="text-xs text-muted-foreground">Var.</p>
          <p className="font-semibold">${variance.toLocaleString()}</p>
        </div>
      </div>
    </div>
  );
}
