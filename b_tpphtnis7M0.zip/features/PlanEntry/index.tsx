'use client';

import { PlanTable } from './PlanTable';
import type { BudgetPlan } from './types';

interface PlanEntryProps {
  plan: BudgetPlan | null;
  onUpdateLineItem: (itemId: string, actualCost: number) => void;
}

export default function PlanEntry({
  plan,
  onUpdateLineItem,
}: PlanEntryProps) {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-balance">
          {plan?.name || 'Budget Plan'}
        </h2>
        <p className="text-sm text-muted-foreground mt-1">
          Enter actual costs to track budget variance
        </p>
      </div>
      <PlanTable plan={plan} onUpdateLineItem={onUpdateLineItem} />
    </div>
  );
}
