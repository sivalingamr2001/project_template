'use client';

import { LineItemRow } from './LineItemRow';
import { Card } from '@/components/ui/card';
import type { BudgetPlan } from './types';

interface PlanTableProps {
  plan: BudgetPlan | null;
  onUpdateLineItem: (itemId: string, actualCost: number) => void;
}

export function PlanTable({
  plan,
  onUpdateLineItem,
}: PlanTableProps) {
  if (!plan) {
    return (
      <Card className="p-8 text-center">
        <p className="text-muted-foreground">Select a project to view budget plan</p>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-4 gap-4 px-3 py-2 bg-secondary/20 rounded text-sm font-semibold text-secondary-foreground">
        <div>Item</div>
        <div className="text-right">Estimated</div>
        <div className="text-right">Actual</div>
        <div className="text-right">Variance</div>
      </div>

      <div className="space-y-2">
        {plan.lineItems.map((item) => (
          <LineItemRow
            key={item.id}
            item={item}
            onUpdateActual={onUpdateLineItem}
          />
        ))}
      </div>

      <div className="grid grid-cols-4 gap-4 p-3 bg-primary/20 rounded font-semibold">
        <div>Total</div>
        <div className="text-right">${plan.totalEstimated.toLocaleString()}</div>
        <div className="text-right">${plan.totalActual.toLocaleString()}</div>
        <div className="text-right">${(plan.totalActual - plan.totalEstimated).toLocaleString()}</div>
      </div>
    </div>
  );
}
