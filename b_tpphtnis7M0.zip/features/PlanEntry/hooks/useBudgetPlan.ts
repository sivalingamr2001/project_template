import { useState, useCallback } from 'react';
import type { BudgetPlan, BudgetLineItem } from './types';

const MOCK_PLANS: Record<string, BudgetPlan> = {
  '1': {
    id: 'plan-1',
    projectId: '1',
    name: 'Q1 Marketing Budget',
    lineItems: [
      {
        id: 'item-1',
        category: 'Digital Ads',
        description: 'Google & Meta campaigns',
        estimatedCost: 75000,
        actualCost: 68500,
      },
      {
        id: 'item-2',
        category: 'Content',
        description: 'Blog and video production',
        estimatedCost: 45000,
        actualCost: 43200,
      },
      {
        id: 'item-3',
        category: 'Tools',
        description: 'Marketing automation platform',
        estimatedCost: 30000,
        actualCost: 30000,
      },
    ],
    totalEstimated: 150000,
    totalActual: 141700,
    createdAt: new Date('2024-01-15'),
    updatedAt: new Date('2024-02-20'),
  },
};

export function useBudgetPlan(projectId: string | null) {
  const [plans, setPlans] = useState<Record<string, BudgetPlan>>(MOCK_PLANS);

  const currentPlan = projectId ? plans[projectId] : null;

  const updateLineItem = useCallback(
    (itemId: string, actualCost: number) => {
      if (!projectId || !currentPlan) return;

      setPlans((prev) => {
        const plan = prev[projectId];
        if (!plan) return prev;

        const updatedItems = plan.lineItems.map((item) =>
          item.id === itemId
            ? {
                ...item,
                actualCost,
                variance: actualCost - item.estimatedCost,
              }
            : item
        );

        const totalActual = updatedItems.reduce((sum, item) => sum + (item.actualCost || 0), 0);

        return {
          ...prev,
          [projectId]: {
            ...plan,
            lineItems: updatedItems,
            totalActual,
            updatedAt: new Date(),
          },
        };
      });
    },
    [projectId, currentPlan]
  );

  return {
    plan: currentPlan,
    updateLineItem,
  };
}
