export interface BudgetLineItem {
  id: string;
  category: string;
  description: string;
  estimatedCost: number;
  actualCost?: number;
  variance?: number;
}

export interface BudgetPlan {
  id: string;
  projectId: string;
  name: string;
  lineItems: BudgetLineItem[];
  totalEstimated: number;
  totalActual: number;
  createdAt: Date;
  updatedAt: Date;
}
