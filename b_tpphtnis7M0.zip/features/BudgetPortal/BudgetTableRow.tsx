import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Eye, FileEdit } from 'lucide-react';
import { Budget } from '../types';
import Link from 'next/link';

interface BudgetTableRowProps {
  budget: Budget;
  onView: (budget: Budget) => void;
}

export function BudgetTableRow({ budget, onView }: BudgetTableRowProps) {
  const statusColor =
    budget.status === 'ON TRACK'
      ? 'bg-green-100 text-green-800'
      : budget.status === 'AT RISK'
        ? 'bg-amber-100 text-amber-800'
        : 'bg-blue-100 text-blue-800';

  return (
    <tr className="border-b hover:bg-muted/50 transition-colors">
      <td className="px-4 py-3 text-sm font-medium">{budget.projectCode}</td>
      <td className="px-4 py-3 text-sm">{budget.projectName}</td>
      <td className="px-4 py-3 text-sm">{budget.productName}</td>
      <td className="px-4 py-3 text-sm font-semibold">${budget.totalBudget.toLocaleString()}</td>
      <td className="px-4 py-3">
        <Badge className={statusColor}>{budget.status}</Badge>
      </td>
      <td className="px-4 py-3">
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="ghost"
            onClick={() => onView(budget)}
            className="gap-2"
          >
            <Eye className="w-4 h-4" />
            View
          </Button>
          <Link href={`/plan-entry/${budget.id}`}>
            <Button
              size="sm"
              variant="outline"
              className="gap-2"
            >
              <FileEdit className="w-4 h-4" />
              Plan Entry
            </Button>
          </Link>
        </div>
      </td>
    </tr>
  );
}
