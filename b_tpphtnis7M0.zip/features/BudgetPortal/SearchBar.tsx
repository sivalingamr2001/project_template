import { Input } from '@/components/ui/input';
import { Search, X } from 'lucide-react';

interface SearchBarProps {
  query: string;
  onChange: (value: string) => void;
  placeholder?: string;
}

export function SearchBar({ query, onChange, placeholder = 'Search by project name or code...' }: SearchBarProps) {
  return (
    <div className="relative">
      <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
      <Input
        type="text"
        placeholder={placeholder}
        value={query}
        onChange={(e) => onChange(e.target.value)}
        className="pl-10 pr-10"
      />
      {query && (
        <button
          onClick={() => onChange('')}
          className="absolute right-3 top-3 text-muted-foreground hover:text-foreground"
        >
          <X className="w-4 h-4" />
        </button>
      )}
    </div>
  );
}
