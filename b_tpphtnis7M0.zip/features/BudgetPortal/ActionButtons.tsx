import { Button } from '@/components/ui/button';
import { Plus, Search } from 'lucide-react';

interface ActionButtonsProps {
  onCreateClick: () => void;
  onSearchClick: () => void;
}

export function ActionButtons({ onCreateClick, onSearchClick }: ActionButtonsProps) {
  return (
    <div className="flex flex-col sm:flex-row gap-3">
      <Button onClick={onCreateClick} className="gap-2">
        <Plus className="w-4 h-4" />
        Create Budget
      </Button>
      <Button onClick={onSearchClick} variant="outline" className="gap-2">
        <Search className="w-4 h-4" />
        Search Budget
      </Button>
    </div>
  );
}
