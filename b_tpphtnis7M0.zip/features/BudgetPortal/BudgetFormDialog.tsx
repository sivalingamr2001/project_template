import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useState } from 'react';
import { Budget } from '../types';

interface BudgetFormDialogProps {
  isOpen: boolean;
  budget?: Budget;
  onClose: () => void;
  onSave: (budget: Budget) => void;
}

export function BudgetFormDialog({
  isOpen,
  budget,
  onClose,
  onSave,
}: BudgetFormDialogProps) {
  const [formData, setFormData] = useState<Partial<Budget>>(
    budget || {
      projectName: '',
      projectCode: '',
      productName: '',
      totalBudget: 0,
      actualSpent: 0,
      status: 'ON TRACK' as const,
    }
  );

  const handleChange = (field: keyof Budget, value: unknown) => {
    setFormData({ ...formData, [field]: value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.projectName && formData.projectCode && formData.productName) {
      onSave(formData as Budget);
      onClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>{budget ? 'Edit Budget' : 'Create Budget'}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="projectName">Project Name</Label>
            <Input
              id="projectName"
              value={formData.projectName || ''}
              onChange={(e) => handleChange('projectName', e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="projectCode">Project Code</Label>
            <Input
              id="projectCode"
              value={formData.projectCode || ''}
              onChange={(e) => handleChange('projectCode', e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="productName">Product Name</Label>
            <Input
              id="productName"
              value={formData.productName || ''}
              onChange={(e) => handleChange('productName', e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="totalBudget">Total Budget</Label>
            <Input
              id="totalBudget"
              type="number"
              value={formData.totalBudget || 0}
              onChange={(e) => handleChange('totalBudget', parseInt(e.target.value))}
            />
          </div>

          <div className="flex gap-2 pt-4">
            <Button type="submit" className="flex-1">
              Save
            </Button>
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              Cancel
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
