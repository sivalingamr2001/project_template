import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Budget } from '../types';
import { useState } from 'react';

interface BudgetDetailDrawerProps {
  budget: Budget | null;
  isOpen: boolean;
  onClose: () => void;
  onSave?: (budget: Budget) => void;
}

export function BudgetDetailDrawer({
  budget,
  isOpen,
  onClose,
  onSave,
}: BudgetDetailDrawerProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<Budget | null>(budget);

  if (!budget) return null;

  const handleChange = (field: keyof Budget, value: unknown) => {
    if (formData) {
      setFormData({ ...formData, [field]: value });
    }
  };

  const handleSave = () => {
    if (formData && onSave) {
      onSave(formData);
      setIsEditing(false);
    }
  };

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-md overflow-y-auto">
        <SheetHeader>
          <SheetTitle>Budget Details</SheetTitle>
        </SheetHeader>

        <div className="space-y-6 mt-6">
          {/* Project Info */}
          <div className="space-y-4 border-b pb-4">
            <h3 className="font-semibold text-sm">Project Information</h3>
            
            <div className="space-y-2">
              <Label className="text-xs">Project Code</Label>
              <Input
                value={formData?.projectCode || ''}
                disabled={!isEditing}
                onChange={(e) => handleChange('projectCode', e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label className="text-xs">Project Name</Label>
              <Input
                value={formData?.projectName || ''}
                disabled={!isEditing}
                onChange={(e) => handleChange('projectName', e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label className="text-xs">Product Name</Label>
              <Input
                value={formData?.productName || ''}
                disabled={!isEditing}
                onChange={(e) => handleChange('productName', e.target.value)}
              />
            </div>
          </div>

          {/* Budget Summary */}
          <div className="space-y-4 border-b pb-4">
            <h3 className="font-semibold text-sm">Budget Summary</h3>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-xs text-muted-foreground mb-1">Total Budget</p>
                <p className="text-lg font-bold">${formData?.totalBudget.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">Actual Spent</p>
                <p className="text-lg font-bold">${formData?.actualSpent.toLocaleString()}</p>
              </div>
            </div>

            <div>
              <p className="text-xs text-muted-foreground mb-1">Remaining</p>
              <p className="text-lg font-bold">
                ${((formData?.totalBudget || 0) - (formData?.actualSpent || 0)).toLocaleString()}
              </p>
            </div>
          </div>

          {/* Status & Phase */}
          <div className="space-y-4">
            <div>
              <Label className="text-xs mb-2 block">Status</Label>
              <Badge className="w-fit">{formData?.status}</Badge>
            </div>

            <div>
              <Label className="text-xs mb-2 block">Phase</Label>
              <p className="text-sm">{formData?.phase}</p>
            </div>

            <div>
              <Label className="text-xs mb-2 block">Department</Label>
              <p className="text-sm">{formData?.department}</p>
            </div>

            <div>
              <Label className="text-xs mb-2 block">Last Updated</Label>
              <p className="text-sm">{formData?.lastUpdated}</p>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-2 pt-4">
            {!isEditing ? (
              <Button
                onClick={() => setIsEditing(true)}
                className="flex-1"
              >
                Edit
              </Button>
            ) : (
              <>
                <Button
                  onClick={handleSave}
                  className="flex-1"
                >
                  Save
                </Button>
                <Button
                  onClick={() => {
                    setIsEditing(false);
                    setFormData(budget);
                  }}
                  variant="outline"
                  className="flex-1"
                >
                  Cancel
                </Button>
              </>
            )}
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
