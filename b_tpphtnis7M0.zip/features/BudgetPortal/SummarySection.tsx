import { SUMMARY_CARDS } from '@/lib/constants';
import { SummaryCard } from './SummaryCard';

export function SummarySection() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {SUMMARY_CARDS.map((card) => (
        <SummaryCard
          key={card.id}
          label={card.label}
          value={card.value}
          icon={card.icon}
          color={card.color}
        />
      ))}
    </div>
  );
}
