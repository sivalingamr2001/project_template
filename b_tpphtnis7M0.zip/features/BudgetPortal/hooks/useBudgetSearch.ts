import { useState, useMemo } from 'react';
import { Budget } from '../types';

interface UseBudgetSearchProps {
  budgets: Budget[];
}

export function useBudgetSearch({ budgets }: UseBudgetSearchProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBudget, setSelectedBudget] = useState<Budget | null>(null);

  const filteredBudgets = useMemo(() => {
    if (!searchQuery) return budgets;
    
    const query = searchQuery.toLowerCase();
    return budgets.filter(
      (budget) =>
        budget.projectName.toLowerCase().includes(query) ||
        budget.projectCode.toLowerCase().includes(query) ||
        budget.productName.toLowerCase().includes(query)
    );
  }, [searchQuery, budgets]);

  const handleSelectBudget = (budget: Budget) => {
    setSelectedBudget(budget);
  };

  const handleClearSelection = () => {
    setSelectedBudget(null);
  };

  return {
    searchQuery,
    setSearchQuery,
    filteredBudgets,
    selectedBudget,
    handleSelectBudget,
    handleClearSelection,
  };
}
