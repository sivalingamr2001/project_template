import { useState } from 'react';
import { Budget } from '../types';

export function useBudgetForm() {
  const [isOpen, setIsOpen] = useState(false);
  const [editingBudget, setEditingBudget] = useState<Budget | null>(null);

  const handleOpenCreate = () => {
    setEditingBudget(null);
    setIsOpen(true);
  };

  const handleOpenEdit = (budget: Budget) => {
    setEditingBudget(budget);
    setIsOpen(true);
  };

  const handleClose = () => {
    setIsOpen(false);
    setEditingBudget(null);
  };

  const handleSave = (budget: Budget) => {
    setIsOpen(false);
    setEditingBudget(null);
  };

  return {
    isOpen,
    editingBudget,
    handleOpenCreate,
    handleOpenEdit,
    handleClose,
    handleSave,
  };
}
