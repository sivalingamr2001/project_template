export interface Budget {
  id: string;
  projectCode: string;
  projectName: string;
  productName: string;
  status: 'ON TRACK' | 'AT RISK' | 'COMPLETED';
  totalBudget: number;
  actualSpent: number;
  phase: string;
  department: string;
  lastUpdated: string;
}

export interface LineItem {
  name: string;
  planned: number;
  actual: number;
}

export interface BudgetCategory {
  category: string;
  items: LineItem[];
}

export interface BudgetDetail {
  id: string;
  projectCode: string;
  projectName: string;
  productName: string;
  phase: string;
  department: string;
  status: string;
  lastUpdated: string;
  categories: BudgetCategory[];
}
