'use client';

import { useState } from 'react';
import { SummarySection } from './SummarySection';
import { ActionButtons } from './ActionButtons';
import { SearchBar } from './SearchBar';
import { BudgetTable } from './BudgetTable';
import { BudgetDetailDrawer } from './BudgetDetailDrawer';
import { BudgetFormDialog } from './BudgetFormDialog';
import { useBudgetSearch } from './hooks/useBudgetSearch';
import { useBudgetForm } from './hooks/useBudgetForm';
import { mockBudgetData } from '@/lib/mockData';
import { Budget } from './types';

interface BudgetPortalDashboardProps {
  onViewBudget?: (budgetId: string) => void;
}

export function BudgetPortalDashboard({ onViewBudget }: BudgetPortalDashboardProps) {
  const [budgets, setBudgets] = useState<Budget[]>(mockBudgetData);
  const [showSearch, setShowSearch] = useState(false);

  const budgetSearch = useBudgetSearch({ budgets });
  const budgetForm = useBudgetForm();

  const handleCreateBudget = () => {
    budgetForm.handleOpenCreate();
  };

  const handleSaveBudget = (budget: Budget) => {
    if (budgetForm.editingBudget?.id) {
      setBudgets(
        budgets.map((b) => (b.id === budget.id ? budget : b))
      );
    } else {
      setBudgets([...budgets, { ...budget, id: `budget-${Date.now()}` }]);
    }
    budgetForm.handleClose();
  };

  const handleViewBudget = (budget: Budget) => {
    budgetSearch.handleSelectBudget(budget);
    onViewBudget?.(budget.id);
  };

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <SummarySection />

      {/* Action Buttons */}
      <ActionButtons
        onCreateClick={handleCreateBudget}
        onSearchClick={() => setShowSearch(!showSearch)}
      />

      {/* Search View */}
      {showSearch && (
        <div className="space-y-4">
          <SearchBar
            query={budgetSearch.searchQuery}
            onChange={budgetSearch.setSearchQuery}
          />
          <BudgetTable
            budgets={budgetSearch.filteredBudgets}
            onView={handleViewBudget}
          />
        </div>
      )}

      {/* Main Table (when not searching) */}
      {!showSearch && (
        <BudgetTable
          budgets={budgets}
          onView={handleViewBudget}
        />
      )}

      {/* Detail Drawer */}
      <BudgetDetailDrawer
        budget={budgetSearch.selectedBudget}
        isOpen={!!budgetSearch.selectedBudget}
        onClose={budgetSearch.handleClearSelection}
        onSave={handleSaveBudget}
      />

      {/* Create/Edit Form Dialog */}
      <BudgetFormDialog
        isOpen={budgetForm.isOpen}
        budget={budgetForm.editingBudget || undefined}
        onClose={budgetForm.handleClose}
        onSave={handleSaveBudget}
      />
    </div>
  );
}
