import { Card } from '@/components/ui/card';
import { Budget } from '../types';

interface SearchViewProps {
  isVisible: boolean;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  filteredBudgets: Budget[];
  onSelectBudget: (budget: Budget) => void;
  children: React.ReactNode;
}

export function SearchView({
  isVisible,
  searchQuery,
  onSearchChange,
  children,
}: SearchViewProps) {
  if (!isVisible) return null;

  return (
    <Card className="p-6 space-y-4 border-0 shadow-sm">
      <div>
        <h3 className="text-lg font-semibold mb-4">Search Budgets</h3>
        {children}
      </div>
    </Card>
  );
}
