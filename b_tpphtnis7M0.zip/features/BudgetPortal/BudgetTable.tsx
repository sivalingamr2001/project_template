import { Card } from '@/components/ui/card';
import { Budget } from '../types';
import { BudgetTableRow } from './BudgetTableRow';

interface BudgetTableProps {
  budgets: Budget[];
  onView: (budget: Budget) => void;
}

export function BudgetTable({ budgets, onView }: BudgetTableProps) {
  if (budgets.length === 0) {
    return (
      <Card className="p-8 text-center">
        <p className="text-muted-foreground">No budgets found. Create one to get started.</p>
      </Card>
    );
  }

  return (
    <Card className="overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-muted/50 border-b">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-semibold">Project Code</th>
              <th className="px-4 py-3 text-left text-sm font-semibold">Project Name</th>
              <th className="px-4 py-3 text-left text-sm font-semibold">Product Name</th>
              <th className="px-4 py-3 text-left text-sm font-semibold">Budget Amount</th>
              <th className="px-4 py-3 text-left text-sm font-semibold">Status</th>
              <th className="px-4 py-3 text-left text-sm font-semibold">Actions</th>
            </tr>
          </thead>
          <tbody>
            {budgets.map((budget) => (
              <BudgetTableRow key={budget.id} budget={budget} onView={onView} />
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}
