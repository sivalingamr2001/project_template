import { useMemo } from 'react';
import type { BudgetPlan } from '@/features/PlanEntry/types';
import type { PerformanceReport } from './types';

export function usePerformanceReport(plan: BudgetPlan | null): PerformanceReport | null {
  return useMemo(() => {
    if (!plan) return null;

    const totalVariance = plan.totalActual - plan.totalEstimated;
    const variancePercentage = (totalVariance / plan.totalEstimated) * 100;

    const categoryCosts = plan.lineItems.map((item) => ({
      category: item.category,
      estimated: item.estimatedCost,
      actual: item.actualCost || 0,
      variance: (item.actualCost || 0) - item.estimatedCost,
    }));

    return {
      budgetUtilization: (plan.totalActual / plan.totalEstimated) * 100,
      totalVariance,
      variancePercentage,
      categoryCosts,
    };
  }, [plan]);
}
