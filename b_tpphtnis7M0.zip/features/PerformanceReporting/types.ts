export interface PerformanceReport {
  budgetUtilization: number;
  totalVariance: number;
  variancePercentage: number;
  categoryCosts: {
    category: string;
    estimated: number;
    actual: number;
    variance: number;
  }[];
}
