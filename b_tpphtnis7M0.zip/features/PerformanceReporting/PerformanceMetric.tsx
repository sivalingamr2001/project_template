import { Card } from '@/components/ui/card';

interface PerformanceMetricProps {
  label: string;
  value: string | number;
  unit?: string;
  trend?: 'up' | 'down' | 'neutral';
  helpText?: string;
}

export function PerformanceMetric({
  label,
  value,
  unit,
  trend,
  helpText,
}: PerformanceMetricProps) {
  const trendColor = {
    up: 'text-destructive',
    down: 'text-accent',
    neutral: 'text-muted-foreground',
  }[trend || 'neutral'];

  return (
    <Card className="p-4">
      <p className="text-sm font-medium text-muted-foreground">{label}</p>
      <div className="mt-3 flex items-baseline gap-2">
        <span className="text-2xl font-bold">{value}</span>
        {unit && <span className="text-sm text-muted-foreground">{unit}</span>}
      </div>
      {helpText && (
        <p className={`text-xs mt-2 ${trendColor}`}>{helpText}</p>
      )}
    </Card>
  );
}
