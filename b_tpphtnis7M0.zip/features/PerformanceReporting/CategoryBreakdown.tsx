'use client';

import { Card } from '@/components/ui/card';
import type { PerformanceReport } from './types';

interface CategoryBreakdownProps {
  report: PerformanceReport | null;
}

export function CategoryBreakdown({ report }: CategoryBreakdownProps) {
  if (!report || report.categoryCosts.length === 0) {
    return (
      <Card className="p-8 text-center text-muted-foreground">
        <p>No category data available</p>
      </Card>
    );
  }

  return (
    <Card className="p-6">
      <h3 className="font-semibold mb-4">Category Breakdown</h3>
      <div className="space-y-3">
        {report.categoryCosts.map((cat) => (
          <div key={cat.category} className="flex items-center justify-between p-3 bg-card rounded border border-border">
            <div>
              <p className="font-medium text-sm">{cat.category}</p>
              <p className="text-xs text-muted-foreground">Est: ${cat.estimated.toLocaleString()}</p>
            </div>
            <div className="text-right">
              <p className={`font-semibold ${cat.variance > 0 ? 'text-destructive' : 'text-accent'}`}>
                ${cat.actual.toLocaleString()}
              </p>
              <p className="text-xs text-muted-foreground">{((cat.variance / cat.estimated) * 100).toFixed(0)}%</p>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
