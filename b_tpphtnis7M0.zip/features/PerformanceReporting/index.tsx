'use client';

import { PerformanceGrid } from './PerformanceGrid';
import { CategoryBreakdown } from './CategoryBreakdown';
import type { PerformanceReport } from './types';

interface PerformanceReportingProps {
  report: PerformanceReport | null;
}

export default function PerformanceReporting({
  report,
}: PerformanceReportingProps) {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-balance">Performance Report</h2>
        <p className="text-sm text-muted-foreground mt-1">
          Budget analysis and variance tracking
        </p>
      </div>
      <PerformanceGrid report={report} />
      <CategoryBreakdown report={report} />
    </div>
  );
}
