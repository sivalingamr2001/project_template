'use client';

import { PerformanceMetric } from './PerformanceMetric';
import type { PerformanceReport } from './types';

interface PerformanceGridProps {
  report: PerformanceReport | null;
}

export function PerformanceGrid({ report }: PerformanceGridProps) {
  if (!report) {
    return (
      <div className="text-center p-8 text-muted-foreground">
        <p>No performance data available</p>
      </div>
    );
  }

  const isOverBudget = report.totalVariance > 0;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      <PerformanceMetric
        label="Budget Utilization"
        value={report.budgetUtilization.toFixed(1)}
        unit="%"
        trend={isOverBudget ? 'up' : 'down'}
        helpText={isOverBudget ? 'Over budget' : 'Under budget'}
      />
      <PerformanceMetric
        label="Total Variance"
        value={`$${report.totalVariance.toLocaleString()}`}
        trend={isOverBudget ? 'up' : 'down'}
        helpText={`${report.variancePercentage.toFixed(1)}% variance`}
      />
      <PerformanceMetric
        label="Category Count"
        value={report.categoryCosts.length}
        trend="neutral"
      />
      <PerformanceMetric
        label="Largest Variance"
        value={`$${Math.max(...report.categoryCosts.map((c) => Math.abs(c.variance))).toLocaleString()}`}
        trend={report.categoryCosts.some((c) => c.variance > 0) ? 'up' : 'down'}
      />
    </div>
  );
}
