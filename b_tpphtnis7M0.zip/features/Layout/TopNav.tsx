import Link from 'next/link';
import { Button } from '@/components/ui/button';

interface TopNavProps {
  currentPage: string;
}

export function TopNav({ currentPage }: TopNavProps) {
  return (
    <div className="border-b border-border bg-background sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/">
            <Button variant="ghost" className="gap-2">
              ← Janatics India Pvt. Ltd.
            </Button>
          </Link>
          <span className="text-sm text-muted-foreground">R&D Budget Management Portal</span>
        </div>
        <div className="flex items-center gap-4">
          <Link href="/">
            <Button
              variant={currentPage === 'search' ? 'default' : 'ghost'}
              size="sm"
            >
              Project Search
            </Button>
          </Link>
          <Link href="#plan-entry">
            <Button
              variant={currentPage === 'plan-entry' ? 'default' : 'ghost'}
              size="sm"
            >
              Plan Entry
            </Button>
          </Link>
          <Link href="#performance">
            <Button
              variant={currentPage === 'performance' ? 'ghost' : 'ghost'}
              size="sm"
            >
              Performance Report
            </Button>
          </Link>
          <Button variant="ghost" size="sm">
            Logout →
          </Button>
        </div>
      </div>
    </div>
  );
}
