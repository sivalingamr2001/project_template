import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface NavigationTabsProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export function NavigationTabs({
  activeTab,
  onTabChange,
}: NavigationTabsProps) {
  return (
    <Tabs value={activeTab} onValueChange={onTabChange} className="w-full">
      <TabsList className="w-full justify-start bg-secondary/10 border-b border-border rounded-none">
        <TabsTrigger value="selection" className="data-[state=active]:border-b-2 data-[state=active]:border-accent">
          Projects
        </TabsTrigger>
        <TabsTrigger value="planning" className="data-[state=active]:border-b-2 data-[state=active]:border-accent">
          Budget Plan
        </TabsTrigger>
        <TabsTrigger value="reporting" className="data-[state=active]:border-b-2 data-[state=active]:border-accent">
          Performance
        </TabsTrigger>
      </TabsList>

      <div className="mt-6">
        <TabsContent value={activeTab} className="mt-0">
          {/* Content rendered by parent */}
        </TabsContent>
      </div>
    </Tabs>
  );
}
