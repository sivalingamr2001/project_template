interface ContentContainerProps {
  children: React.ReactNode;
}

export function ContentContainer({ children }: ContentContainerProps) {
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {children}
    </div>
  );
}
