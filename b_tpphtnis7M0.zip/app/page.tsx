'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Header } from '@/features/Layout/Header';
import { ContentContainer } from '@/features/Layout/ContentContainer';
import { BudgetPortalDashboard } from '@/features/BudgetPortal';
import { mockBudgetData } from '@/lib/mockData';

export default function DashboardPage() {
  const router = useRouter();
  const [selectedBudgetId, setSelectedBudgetId] = useState<string | null>(null);

  const handleViewBudget = (budgetId: string) => {
    setSelectedBudgetId(budgetId);
    router.push(`/plan-entry/${budgetId}`);
  };

  return (
    <main className="min-h-screen bg-background">
      <Header
        title="Budget Portal"
        subtitle="Manage project budgets with real-time variance tracking"
      />
      <ContentContainer>
        <BudgetPortalDashboard onViewBudget={handleViewBudget} />
      </ContentContainer>
    </main>
  );
}
