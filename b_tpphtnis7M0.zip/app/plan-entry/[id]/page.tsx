'use client';

import { useRouter, useParams } from 'next/navigation';
import { PlanEntryDetail } from '@/features/PlanEntryDetail';
import { TopNav } from '@/features/Layout/TopNav';
import { mockBudgetData } from '@/lib/mockData';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';

export default function PlanEntryPage() {
  const router = useRouter();
  const params = useParams();
  const budgetId = params.id as string;

  const budget = mockBudgetData.find((b) => b.id === budgetId);

  if (!budget) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Budget not found</p>
          <Button onClick={() => router.back()}>Go Back</Button>
        </div>
      </div>
    );
  }

  return (
    <div>
      <TopNav currentPage="plan-entry" />
      <div className="border-b border-border bg-background px-6 py-3">
        <Button
          variant="ghost"
          onClick={() => router.back()}
          className="gap-2 h-8"
          size="sm"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Portal
        </Button>
      </div>
      <PlanEntryDetail
        budget={budget}
        onBack={() => router.back()}
      />
    </div>
  );
}
